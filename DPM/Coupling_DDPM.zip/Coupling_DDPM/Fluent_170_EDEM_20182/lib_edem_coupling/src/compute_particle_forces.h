#ifndef COMPUTE_PARTICLE_FORCES_H
# define COMPUTE_PARTICLE_FORCES_H 1


void compute_forces_on_particles(EDEM_Coupling edem_coupling, cxboolean fluid_source_terms);

#endif /* COMPUTE_PARTICLE_FORCES_H */
