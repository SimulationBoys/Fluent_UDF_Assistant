# Do not run as a script but source instead to
# set the local environment by running:
# source ./tools/set_edem_env_vars.sh

export EDEM_INSTALL_DIR=/opt/DEMSolutions/EDEM_2.7

# For compiling Adaptor
export EDEM_INCLUDE_PATH=${EDEM_INSTALL_DIR}/src/Api/Coupling/:${EDEM_INSTALL_DIR}/src/Api/Core/

# For compiling UDF
export EDEM_ADAPTOR_OBJECT_DIR=$PWD/edem_cfd_adaptor_build/lnamd64
export EDEM_LIBRARY_PATH=${EDEM_INSTALL_DIR}/lib

# For run time loading
# LD_LIBRARY_PATH must have locations of the EDEM shared objects:
# libEDEMCouplingClientV2_2_0.so  libQtGui.so.4  libQtGui.so.4.5.0

if [[ -z LD_LIBRARY_PATH ]]
then
    export LD_LIBRARY_PATH=${EDEM_LIBRARY_PATH}
else
    export LD_LIBRARY_PATH=${EDEM_LIBRARY_PATH}:${LD_LIBRARY_PATH}
fi

unset EDEM_INSTALL_DIR