#!/usr/bin/env python

#=====================================================
# Written by Richard Wood (DEM Solutions December 2016)
#=====================================================

from __future__ import print_function

import os, sys

def main():
    # Get the current working directory
    cwd = os.getcwd()
    
    # Set up CSOURCES and HSOURCES for makefile
    srcpath = cwd + "\\lib_edem_coupling\\src\\"
    text= "CSOURCES="
    CSOURCES = contents_list(srcpath, ".c", text)
    text= "HSOURCES="
    HSOURCES = contents_list(srcpath, ".h", text)
    
    # Get the six (3d, 3ddp..) directories and store as a variable
    version_dirs = cwd + "\\lib_edem_coupling\\win64\\"
    versions = [x for x in os.listdir(version_dirs) if os.path.isdir(os.path.join(version_dirs,x))]

    # Open all six variants of user_nt.udf and write to them
    for version in versions:
        file_path = version_dirs + version + "\\" 
        bar("makefile_nt.udf", "makefile", file_path)
        
        with open(file_path + "user_nt_original.udf","r") as userFile:
            with open(file_path + "user_nt.udf","w") as edemFile:
                foo(userFile, edemFile, version, CSOURCES, HSOURCES)
    


# Function to create CSOURCES and HSOURCES variables based on folder contents
def contents_list(folder, file_ext, variable):
    for file in os.listdir(folder):
        if file.endswith(file_ext):
            variable = variable + " $(SRC)" + file
    return variable
    
# Function to replace lines of text in the user_nt.udf file
def foo(userFile, edemFile, version, csources, hsources):
    for line in userFile:
    
        # Add the four source files
        if line.startswith("CSOURCES = "):

           line = csources + "\n"
        # Add the six header files
        if line.startswith("HSOURCES = "):

           line = hsources + "\n"
        
        # Edit version based on folder
        if line.startswith("VERSION = "):

            line = "VERSION = " + version + "\n"

        # Change Parallel node to pcmpi for the two node folders  (3d_node & 3ddp_node)
        if line.startswith("PARALLEL_NODE = "):

            line = "PARALLEL_NODE = none" + "\n"
            
            if "_node" in version:
                line = "PARALLEL_NODE = pcmpi" + "\n"

        edemFile.write(line)

    # Add a line to turn off GPU support (not currently available)  
    edemFile.write("GPU_SUPPORT = off")


# Function to rename files
def bar(filename_original, filename_new, directory):
    for file in os.listdir(directory):
        if os.path.isfile(os.path.join(directory,file)):
            if file == filename_original:
                os.rename(os.path.join(directory,file), os.path.join(directory,filename_new))

if __name__ == "__main__":
    main()
    
    
    
    
    
    
    
    
    