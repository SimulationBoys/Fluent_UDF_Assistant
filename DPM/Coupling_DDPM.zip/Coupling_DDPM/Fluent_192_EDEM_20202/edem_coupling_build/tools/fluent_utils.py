#! /usr/bin/env python

import sys
import os
import re
import subprocess
import getopt

def updateVersion((version,major,minor),(ver,maj,min)):
	
    if maj == None:
	    maj = 0
	    
    if min == None:
	    min = 0

    (ver,maj,min)= map(int, (ver,maj,min))

    if ver >= version: # May be the same with increased maj
      if ver > version:
        version = ver
        major = 0
        minor = 0

      if maj >= major: # May be the same with increased min
        if maj > major:
            major = maj
            minor = 0
 
        if min > minor:
            minor = min

    return (version,major,minor)
	

def flbase_ver(program="fluent",basename=""):
	
    fl_env = {}
    
    if os.environ.has_key("PATH"):
        fl_env["PATH"] = os.environ["PATH"]
    
    if os.environ.has_key("FLUENT_INC"):
        fl_env["FLUENT_INC"] = os.environ["FLUENT_INC"]

    if basename:
        basename = basename.strip().rstrip(os.sep)
        fl_env["FLUENT_INC"] = basename

    if fl_env.has_key("FLUENT_INC"):
        run_prog = fl_env["FLUENT_INC"]+os.sep+"bin"+os.sep+program+" -r"
    else:
        run_prog = program+" -r"
        
    read_proc = subprocess.Popen(run_prog, stdout=subprocess.PIPE, shell = True, env = fl_env)

    lines = read_proc.communicate()[0].split(os.linesep)
	
    full_version = (0,0,0)

    for line in lines:

	if basename:
		match = re.search(r"([1-9][0-9]*)\.([0-9]+)(\.([0-9]+))?",line)
		if match:
			groups = match.groups()
			full_version = updateVersion(full_version,(groups[0],groups[1],groups[3]))
	else:
		words = line.split()
		for word in words:
		    if os.path.isdir(word):
		        basename = word
                
    program += str(full_version[0])
    if full_version[1] >= 0:
        program += "."+str(full_version[1])
    if full_version[2] >= 0:
        program += "."+str(full_version[2])
        
    return (basename,program)

def flbase(program="fluent", basename="", full_name = False):

    base, version = flbase_ver(program, basename)
    
    out = base
    if full_name:
	out = base + os.sep+version

    return out
    
def flvers(program="fluent", basename="", full_name = False):

    base,version = flbase_ver(program, basename)

    if full_name:
        version = base + os.sep + version

    return version

def fluent_release(program="fluent",fluent_dir="",full_name=False):

    if fluent_dir:
        fl_dir = fluent_dir
    else:
        if os.environ.has_key("FLUENT_INC"):
             fl_dir = os.environ["FLUENT_INC"]
        else:
            raise Exception("fluent_release: No directory specified")


    fl_files = (d for d in os.listdir(fl_dir) if os.path.isdir(fl_dir+os.sep+d))

    fl_re = re.compile(program+"(\d+)(?:\.(\d+))?(?:\.(\d+))?")
    latest_release = [0,0,0]
    latest_release_name = ""

    for fl in fl_files:

        m = fl_re.match(fl)
        if m:
            release = map(int,m.groups(-1)) # Default to -1 to make lower than full name

            if release > latest_release:
                latest_release = release
                latest_release_name = fl

    
    if full_name:
       return fl_dir+os.sep+latest_release_name
    else:
       return latest_release_name
    
  
import platform

def fluent_arch():

    system = platform.system().lower()
    machine = platform.machine().lower()

    if system.startswith("linux"):

       if machine == "x86_64":
           return "lnamd64"
       elif machine == "ia64":
           return "lnia64"
       else:
           return "lnx86"

    if system.startswith("irix64"):

       if machine == "irix":
           return "irix65"
       else:
           return "irix5"

    if system.startswith("sunos"):

       if machine in ("sun4u","sparc64"):
           return "ultra"
       elif machine == "sun4":
           return "sun4"
       else:
           return "solaris"

    if system.startswith("windows") or system.startswith("cygwin"):

       if machine == "amd64":
           return "win64"
       if machine == "alpha":
           return "ntalpha"
       else:
           return "ntx86"

    raise Error("Unknown architecture for "+system+" "+machine)

def udf_names(source_files):

    udf_line = re.compile("(DEFINE_([_A-Z]+))\s*(\(([_A-Za-z][_A-Za-z0-9]*)(?:\s*\,\s*[_A-Za-z][_A-Za-z0-9]*)*\))[{\s]*")

    udfs = []
    for sf in source_files:

         with open(sf,"r") as f:
             for l in f:
                 m = udf_line.match(l.strip())
                 if m:
                     define,type,args,name = m.groups()
                     args = ", ".join(("".join(args.split())).split(",")) # Make args singly spaced
                     udfs.append((define,args,type,name))

    return udfs
	

if __name__ == "__main__":
	
    progname = os.path.basename(sys.argv[0])
    
    full_name = False
    basename = ""

    opts,args = getopt.getopt(sys.argv[1:],"b:lv",["basename=","long"])

    for o,a in opts:
        if o in ("-l","-v","--long"): full_name = True # -v is old flag for full version
        if o in ("-b","--basename"): basename = a

    if args:
        program = args[0]
    else:
        program = "fluent"

    
    if progname == "flbase":
        print flbase(program, basename, full_name)
	    
    if progname == "flvers":
        print flvers(program, basename, full_name)
	
    if progname == "flarch":
        print fluent_arch()

    if progname == "fludfnames":
        for define,args,type,name in udf_names(sys.argv[1:]):
            print  define,args,type,name
	    
    if progname == "fluent_release":
        print fluent_release(program, basename, full_name)	


