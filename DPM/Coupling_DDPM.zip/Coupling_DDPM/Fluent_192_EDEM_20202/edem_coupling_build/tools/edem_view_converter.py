#! /usr/bin/env python
import  xml.etree.ElementTree as ElementTree
import argparse

def string_to_symbol(string):
    symbol = "-".join(string.split())
    return symbol.lower()

def convert_edem_view_file_to_fluent(view_root, fluent_view_file):
    import math

    fluent_view_file.write("(38 ((\n")
    fluent_view_file.write("(view-list (\n")

    for view in view_root:
        projection = ("perspective","orthographic")[int(view.attrib["projection"])]
        name = string_to_symbol(view.attrib["name"])
        fovy = 2.0*math.tan(math.radians(float(view.attrib["fovy"]))/2.0) # Twice half angle
        fluent_view_file.write("(" + name +" (")
        for camera in view:
            position = (0,0,1)
            target = (0,0,0)
            up_vector = (0,1,0)
            for data in camera:
                if data.tag == "position":
                    position = (float(data.attrib["x"]),float(data.attrib["y"]),float(data.attrib["z"]))
                if data.tag == "target":
                    target = (float(data.attrib["x"]),float(data.attrib["y"]),float(data.attrib["z"]))
                if data.tag == "up_vector":
                    up_vector = (float(data.attrib["x"]),float(data.attrib["y"]),float(data.attrib["z"]))

            dist = math.sqrt(sum((x-y)*(x-y) for x,y in zip(position,target)))

            fluent_view_file.write("({0[0]} {0[1]} {0[2]}) ".format(position))
            fluent_view_file.write("({0[0]} {0[1]} {0[2]}) ".format(target))
            fluent_view_file.write("({0[0]} {0[1]} {0[2]}) ".format(up_vector))

            fluent_view_file.write("{0} {0} ".format(fovy*dist))
            fluent_view_file.write('"{0}"'.format(projection))
            fluent_view_file.write(") ")
            fluent_view_file.write("#(1. 0. 0. 0. 0. 1. 0. 0. 0. 0. 1. 0. 0. 0. 0. 1.)")# 4x4 Transformation matrix
            fluent_view_file.write(")\n")

    fluent_view_file.write(")))))\n")

            

argparser = argparse.ArgumentParser()

argparser.add_argument("edem_view_file", help="EDEM view file containing views")
argparser.add_argument("fluent_view_file", nargs="?", help="Fluent view file to be written")

args = argparser.parse_args()

edem_file = args.edem_view_file

view_tree = ElementTree.parse(edem_file)

view_root = view_tree.getroot()

if args.fluent_view_file:
    with open(args.fluent_view_file, "w") as fluent_view_file:
        convert_edem_view_file_to_fluent(view_root, fluent_view_file)
else:
    import sys
    convert_edem_view_file_to_fluent(view_root, sys.stdout)
