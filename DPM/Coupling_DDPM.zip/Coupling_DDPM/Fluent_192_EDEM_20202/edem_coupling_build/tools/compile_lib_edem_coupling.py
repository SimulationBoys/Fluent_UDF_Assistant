#!/usr/bin/env python

#=====================================================
# Written by Adam Anderson (ANSYS UK February 2017)
#=====================================================

from __future__ import print_function

import os, sys, re
import subprocess
import StringIO


def build_udf(udf_lib="libudf", build_dir="", fluent_dir="", os_dir="win64"):
    
    if not build_dir:
        build_dir = os.getcwd()

    if not fluent_dir:
        fluent_dir = os.getenv("FLUENT_INC").strip('"') # getenv returns value with ""

    fl_dir_re = re.compile("fluent\d+\.\d+\.\d+")

    version_dirs = [d for d in os.listdir(fluent_dir) if fl_dir_re.match(d)]

    if not version_dirs:
        print("No Fluent versions found in {0}".format(fluent_dir))
        return False

    fluent_udf_path = os.path.join(fluent_dir, version_dirs[0],"src","udf")

    srcpath = os.path.join(build_dir, udf_lib, "src")

    source_files = get_files_of_type(srcpath, (".c", ".cpp"))
    header_files = get_files_of_type(srcpath, ".h")
    
    udf_names_file_contents = udf_names_file(srcpath)
    ud_io1_file_contents = ud_io1_file(udf_names_file_contents)
    
    # Get the (3d, 3ddp..) directories and store as a variable
    version_dir = os.path.join(build_dir, udf_lib, os_dir)
    try:
        versions = [x for x in os.listdir(version_dir) if os.path.isdir(os.path.join(version_dir,x))]
    except:
        versions = []

    if not versions:
        versions = ["3d","3d_host","3d_node","3ddp","3ddp_host","3ddp_node"] # Build all versions


    # Write makefile, user_names.c and ud_io1.h to all version dirs and run nmake in each dir.

    for version in versions:
        version_path = os.path.join(version_dir, version)

        if not os.path.exists(version_path):
            os.makedirs(version_path)

        with open(os.path.join(fluent_udf_path, "makefile_nt.udf"),"r") as fluentFile:
            with open(os.path.join(version_path, "makefile"),"w") as localFile:
                makefile_nt_convert(fluentFile, localFile, source_files, header_files, version)

        with open(os.path.join(version_path, "udf_names.c"),"w") as localFile:
            localFile.write(udf_names_file_contents)

        with open(os.path.join(version_path, "ud_io1.h"),"w") as localFile:
            localFile.write(ud_io1_file_contents)

        with open(os.path.join(version_path, "udf_compilation_errors.txt"),"w") as errFile:
            make_proc = subprocess.Popen(("nmake"), stdout=sys.stdout, stderr=errFile, cwd=version_path)
            make_proc.wait()
        

def get_files_of_type(containing_dir, file_exts):
    try: 
       exts = file_exts.split() # Can specify extensions in one string with spaces ".c .f .h"
    except:
       exts = [f.strip() for f in file_exts]# or in a list or tuple (".c", ".f", .h")
                                       
    return [f for f in os.listdir(containing_dir) if os.path.splitext(f)[-1] in exts]


def udf_names_file(src_dir):

    files = [os.path.join(src_dir,f) for f in get_files_of_type(src_dir, (".c",".cpp"))]

    if not files:
        return ""

    udf_data = []

    udf_data_re = re.compile("\s*(DEFINE_([_A-Z0-9]+)\s*\(\s*(\w+)(\s*,\s*(\w+))*\s*\))")

    for file in files:
        with open(file,"r") as f:
             for line in f:
                 match = udf_data_re.match(line)
                 if match:
                     udf_data.append(match.groups())

    udf_names_c = """/**************************************/
/* This file generated automatically. */
/* Do not modify.                     */
/**************************************/

#include "udf.h"
#include "prop.h"
#include "dpm.h"
#include "version.h"
"""

    for udfd in udf_data:
        udf_names_c += """
extern {0};""".format(udfd[0]) # Enter full definition line
    
    udf_names_c += """

__declspec(dllexport) UDF_Data udf_data[] = {
"""
    declarations = []
    for udfd in udf_data:
        declarations.append("  {"+'"{1}", (void (*)(void)){1}, UDF_TYPE_{0}'.format(udfd[1], udfd[2])+"}")
    
    udf_names_c += (",\n").join(declarations)
    
    udf_names_c += """
};
"""
    
    udf_names_c += """
__declspec(dllexport) int n_udf_data = {0};
""".format(len(udf_data))

    udf_names_c += """
__declspec(dllexport) void UDF_Inquire_Release(int *major, int *minor, int *revision)
{ 
  *major = RampantReleaseMajor;
  *minor = RampantReleaseMinor;
  *revision = RampantReleaseRevision;
}
"""             

    return udf_names_c

def ud_io1_file(udf_names_c):

    rw_file_found = False

    udf_rw_re = re.compile("\s*extern\s+DEFINE_RW_FILE\s*\(")
    
    for line in udf_names_c.splitlines():
        match = udf_rw_re.match(line)
        if match:
            rw_file_found = True
                     
    ud_io1_h = """/**************************************/
/* This file generated automatically. */
/* Do not modify.                     */
/*                                    */
"""

    if rw_file_found:
        ud_io1_h += """/*    User Defined Data IO Found      */
/**************************************/
"""
    else:
        ud_io1_h += """/*   No User Defined Data IO Found    */
/**************************************/

#define USE_FLUENT_IO_API 0
"""
    return ud_io1_h


def makefile_nt_convert_edem(orig_makefile, new_makefile, source_files, header_files, version, par_node="pcmpi"):

    edem_adaptor_object_dir = os.getenv("EDEM_ADAPTOR_OBJECT_DIR").strip('"') # getenv returns value with ""
    edem_library_path = os.getenv("EDEM_LIBRARY_PATH")

    # Define coupling library version based on input (defaults to 2017 if no user input)
    
    edem_version = os.getenv("EDEM_VERSION")

    if not edem_version:
        edem_version = "2018"

    version_libs = {
        "2.6": "libEDEMCouplingClientV2_2_0.lib",
        "2.7":"libEDEMCouplingClientV2_3_0.lib",
        "2017.0":"libEDEMCouplingClientV3_0_0.lib",
        "2017.1":"libEDEMCouplingClientV3_1_0.lib",
        "2017.2":"EDEMCouplingClient3.lib",
        "2020":"EDEMCouplingClient4.lib",
        "2018":"EDEMCouplingClient4.lib"
        }
    
    try:
        edem_library_name = version_libs[edem_version]
    except KeyError:
        print("\nUnknown EDEM Version '{0}'\n".format(edem_version))
        print("  Must be one of {0} \n".format(", ".join(version_libs.keys())))
        sys.exit(1)  


    edem_objects = os.listdir(edem_adaptor_object_dir)
    edem_objects = ['"'+edem_adaptor_object_dir+"\\"+obj+'"' for obj in get_files_of_type(edem_adaptor_object_dir, ".obj")]

    if not edem_objects:
        print("\nNo EDEM Object files found in {0}\n".format(edem_adaptor_object_dir))
        sys.exit(1)

    # Add the following to lines based on what they start with
    for line in orig_makefile:

        # Clean up any empty lines which maybe with "suspect" tabs.
        if not line.strip():
            line = "\n"

        if line.startswith("!INCLUDE user_nt.udf"):
            # Don't include a separate file, just write it straight into the makefile
            
            line = "CSOURCES = " + " ".join("$(SRC)"+f for f in source_files) + "\n\n"
            
            if header_files:
                line += "HSOURCES = " + " ".join("$(SRC)"+f for f in header_files) + "\n\n"
            
            line += "VERSION = "+ version + "\n\n"

            if version.endswith("_node"):
                line += "PARALLEL_NODE = "+ par_node + "\n\n"
            else:
                line += "PARALLEL_NODE =\n\n"

            if version.endswith("_node"):
                line += "USER_OBJECTS = \n\n"
            else:
                line += "USER_OBJECTS = " + " ".join(edem_objects) + "\n\n"
            
            line += "GPU_SUPPORT = off\n\n"
                
        # This ensures that the makefile for the "_node" libraries use the un-altered makefile from Fluent
        #   except for the part that makes udf_names.c

        if line.startswith("!IF ") and "FLUENT_INC_LOCAL_RESERVED" in line:
            line = '!IF ("$(FLUENT_INC_LOCAL_RESERVED)" != "")\n'

        # Don't make ud_io.h in makefile as made by script.
        if "ud_io1.h" in line:
            line = ""
        
        if not version.endswith("_node"):
            # Only link EDEM libs in the host and serial versions
            
            if line.startswith("LIBS = "):
            # Add EDEM library 
                line = line.rstrip() + ' /Libpath:"' + edem_library_path+'" '+edem_library_name + "\n"


        if line.startswith("$(TARGET):"):
        # Make target not dependent on user_nt.udf 
                line = "$(TARGET): makefile $(UDF_OBJECT) $(SRC_OBJECT)\n"

        if line.startswith("$(UDFDATA):"):
        # Stop udf_names.c being remade as this script makes it
                line = "$(UDFDATA):\n"
        
        # Save line additions to file
        new_makefile.write(line)

if __name__ == "__main__":

    makefile_nt_convert = makefile_nt_convert_edem
    build_udf("lib_edem_coupling")
    
    
    
    
    
    
    
    
    
