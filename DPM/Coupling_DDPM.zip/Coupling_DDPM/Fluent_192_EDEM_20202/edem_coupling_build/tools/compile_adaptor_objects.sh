set EDEM_INSTALL_DIR="/opt/DEMSolutions/EDEM_2.7"

mkdir -p lnamd64

g++ -o lnamd64/AdaptorInterface.os -c -Wall -O -fPIC -DDEMLINUX -I/usr/include -I/opt/DEMSolutions/EDEM_2.7/src/Api/Coupling -I/opt/DEMSolutions/EDEM_2.7/src/Api/Core -Ilnamd64 -Isrc src/AdaptorInterface.cpp
g++ -o lnamd64/CAdaptorQuaternion.os -c -Wall -O -fPIC -DDEMLINUX -I/usr/include -I/opt/DEMSolutions/EDEM_2.7/src/Api/Coupling -I/opt/DEMSolutions/EDEM_2.7/src/Api/Core -Ilnamd64 -Isrc src/CAdaptorQuaternion.cpp
g++ -o lnamd64/CCellAndThreadData.os -c -Wall -O -fPIC -DDEMLINUX -I/usr/include -I/opt/DEMSolutions/EDEM_2.7/src/Api/Coupling -I/opt/DEMSolutions/EDEM_2.7/src/Api/Core -Ilnamd64 -Isrc src/CCellAndThreadData.cpp
g++ -o lnamd64/CFluentParticleData.os -c -Wall -O -fPIC -DDEMLINUX -I/usr/include -I/opt/DEMSolutions/EDEM_2.7/src/Api/Coupling -I/opt/DEMSolutions/EDEM_2.7/src/Api/Core -Ilnamd64 -Isrc src/CFluentParticleData.cpp
g++ -o lnamd64/CParticleData.os -c -Wall -O -fPIC -DDEMLINUX -I/usr/include -I/opt/DEMSolutions/EDEM_2.7/src/Api/Coupling -I/opt/DEMSolutions/EDEM_2.7/src/Api/Core -Ilnamd64 -Isrc src/CParticleData.cpp     
