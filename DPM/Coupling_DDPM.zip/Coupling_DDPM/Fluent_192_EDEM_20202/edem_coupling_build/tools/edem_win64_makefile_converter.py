#!/usr/bin/env python

#=======================================================
# Written by Adam Anderson (ANSYS UK Ltd) May 2016
# Modified by Richard Wood (DEM Solutions) December 2016
#=======================================================

from __future__ import print_function

import os, sys

# Store current working directory as a variable
cwd = os.getcwd()
# Get the six (3d, 3ddp..) directories and store as a variable
version_dirs = cwd + "\\lib_edem_coupling\\win64\\"
versions = [x for x in os.listdir(version_dirs) if os.path.isdir(os.path.join(version_dirs,x))]

# Open all six (3d,3ddp,...) variants of makefile_nt.udf and write to them
for version in versions:
    
    # Define the file path for ...\win64\3d\ etc
    file_path = version_dirs + version
    
    # Change the working directory to this file path (saves having to CD)
    os.chdir(file_path)
    
    # Define coupling library version based on input (defaults to 2017 if no user input)
    try:
        edem_version = sys.argv[1]
    except:
        edem_version = "2017"

    if edem_version == "2.6":
        edem_library_name = "libEDEMCouplingClientV2_2_0.lib"

    if edem_version == "2.7":
        edem_library_name = "libEDEMCouplingClientV2_3_0.lib"

    if edem_version == "2017":
        edem_library_name = "libEDEMCouplingClientV3_0_0.lib"

    if edem_version == "2018":
    	edem_library_name = "EDEMCouplingClient4.lib"

    # Define the edem library path
    try:
        edem_library_path = os.environ["EDEM_LIBRARY_PATH"]
    except KeyError as e:
        print("\nMust set environment variable EDEM_LIBRARY_PATH to location of EDEM Lib file {0}.\n".format(edem_library_name))
        raise e

    # Define where the edem adaptor objects are created
    try:
        edem_adaptor_object_dir = os.environ["EDEM_ADAPTOR_OBJECT_DIR"]
    except KeyError as e:
        print("\nMust set environment variable EDEM_ADAPTOR_OBJECT_DIR to location of EDEM Object files.\n")
        raise e

    # Open makefile (which is the original makefile_nt.udf renamed) and save the output as makefile_edem
    makefile = open("makefile","r")
    edem_makefile = open("makefile_edem","w")
    

    edem_objects = os.listdir(edem_adaptor_object_dir)

    edem_objects = ['"'+edem_adaptor_object_dir+"\\"+obj+'"' for obj in edem_objects if obj.endswith(".obj")]

    if not edem_objects:
        print("\nNo EDEM Object files found in {0}\n".format(edem_adaptor_object_dir))
        sys.exit(1)

    # Add the following to lines based on what they start with
    for line in makefile:
    
        # This ensures that the makefile for the "_node" libraries use the un-altered makefile from Fluent
        if not file_path.endswith("_node"):
                               
            if line.startswith("LIBS = "):
        # Add EDEM library 
                line = line.rstrip()+ ' /Libpath:"' + edem_library_path+'" '+edem_library_name+"\n"

                
            if line.startswith("OBJECTS = "):
        # Now add EDEM objects 

                edem_line = "EDEM_OBJECTS = " + " ".join(edem_objects) + "\n"
                edem_makefile.write(edem_line)

                line = line.rstrip()+ " $(EDEM_OBJECTS)" + "\n"


            if line.startswith("$(UDFDATA):"):
        # Stop udf_names.c being remade because makefile has changed

                mpos = line.find("makefile")
                if mpos > 0:
                    line = line[:mpos] + line[mpos+len("makefile"):]

        # Save line additions to file
        edem_makefile.write(line)

    # Close open files
    makefile.close()
    edem_makefile.close()

