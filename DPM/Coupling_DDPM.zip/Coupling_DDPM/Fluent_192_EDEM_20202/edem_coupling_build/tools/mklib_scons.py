#!/usr/bin/env python

from __future__ import print_function

import os
import re
import sys
import argparse
import shutil
import glob
import subprocess

try:
  import ConsoleColors
  console_colors = ConsoleColors.ConsoleColors()
except:
  console_colors = None


version_dir = re.compile("[23]d(dp)?(_node|_host)?$")

my_cwd = os.path.basename(os.getcwd())

# Check to see if you are running in a sub-directory of a UDF library

if my_cwd == "src" or my_cwd == "lib" or my_cwd.startswith("lib") or version_dir.match(my_cwd):
  if console_colors:
    print(console_colors["red"],end="")
  print('\nCurrently in a directory called "{0}".'.format(my_cwd))
  print("Do you wish to continue? [No]: ",end="")
  if console_colors:
    print(console_colors["normal"],end="")
  if (not "yes".startswith(sys.stdin.readline().lower())):
    sys.exit(-3)


libudf_subdirs = [l for l in glob.glob("[23]d*") if os.path.isdir(l) and version_dir.match(l)]

if os.path.exists("src") and os.path.isdir("src"):
  libudf_subdirs.append("src")

if libudf_subdirs:
  if console_colors:
    print(console_colors["red"],end="")
  print('\nCurrently in "{0}" which has a sub-directory "{1}".'.format(my_cwd, libudf_subdirs[0]))
  print("Do you wish to continue? [No]: ",end="")
  if console_colors:
    print(console_colors["normal"],end="")
  if (not "yes".startswith(sys.stdin.readline().lower())):
    sys.exit(-3)


def get_SCons_files(path):

    sconstruct_file = ""
    sconscript_file = ""

    for d in path.split(":"):
       d = os.path.expanduser(d)
       d = os.path.expandvars(d)
       scon_file = os.path.join(d,"SConstruct")

       if not sconstruct_file and os.path.exists(scon_file):
           sconstruct_file = scon_file

       scon_file = os.path.join(d,"SConscript")
       if not sconscript_file and os.path.exists(scon_file):
           sconscript_file = scon_file

    return (sconstruct_file, sconscript_file)

def filter_scons_output(pipe, verbose = False):

    (stdout,stderr) = scons_pipe.communicate()


    for l in stdout.splitlines():

        if l.startswith("UDFs") or l.strip().startswith("DEFINE_"):
            yield l

#        if "libudf." in l:
#            yield l

        elif l.strip().startswith("Creating "):
            if console_colors:
                l = console_colors["blue"] + l + console_colors["normal"]

            yield l

        elif l.startswith("scons:"):
            if console_colors:
                if "terminated" in l:
                    l = console_colors["red_bg"] + console_colors["yellow"] + l + console_colors["normal"]
                else:
                    l = console_colors["green"] + l + console_colors["normal"]

            yield l

        elif verbose:
            yield l



    for l in stderr.splitlines():


       if l.startswith("src"):
           l = l[4:]

           if console_colors:
               if "error" in l:
                   l = console_colors["red_bg"] + console_colors["yellow"] + l + console_colors["normal"]
               elif "warning" in l:
                   l = console_colors["yellow_bg"] + l + console_colors["normal"]

           yield l

       elif verbose:
           yield l


try:
    scons_src_path = os.environ["MKLIB_SCONS_PATH"]
except KeyError:
    scons_src_path = os.path.join("~",".mklib_d")

def current_lib_versions(libudf):

    current_versions = []

    for (dirPath, dirNames, files) in os.walk(libudf, True):
      dirname = os.path.basename(dirPath)

      if version_dir.match(dirname):
        current_versions.append(dirname)

    return current_versions


parser = argparse.ArgumentParser(description="Compile UDF libraries")


parser.add_argument("udf_lib", metavar="libudf", nargs="?", help="UDF Library names")
parser.add_argument("-p", "--parallel", "--para", action="store_true")
parser.add_argument("-s", "--serial", action="store_true") # Dummy arg default overridden by --parallel --only
parser.add_argument("--2d", "-2", dest="two_dimensional", action="store_true")
parser.add_argument("--3d", "-3", dest="three_dimensional", action="store_true") # Dummy arg default overridden by --2d --only
parser.add_argument("--double", "--dp", "-d", dest="double_precision", action="store_true")
parser.add_argument("--all", "-a", dest="all_versions", action="store_true")
parser.add_argument("--only", action="store_true")
parser.add_argument("--verbose", "-v", action="store_true")
parser.add_argument("--scheme", action="store_true")
parser.add_argument("-I","--include_path", dest="include_path", default=[], action="append")
parser.add_argument("-o","--user_object", dest="user_objects", default=[], action="append")


args, scons_args = parser.parse_known_args()  # All other args go to scons


if args.udf_lib:
  libudf = args.udf_lib
else:
  local_libs = [l for l in glob.glob("lib*") if os.path.isdir(l)]
  if local_libs:
    if len(local_libs) > 1 :
      print("\nThere appears to be more than one local library :")
      print("Please specify which to build:")
      i = 1
      for l in local_libs:
        print("{0}: {1}".format(i,l))
        i += 1
      print("0: None of the above")
      i = int(sys.stdin.readline())
      if not i:
        sys.exit(0)
      else:
        try:
          libudf = local_libs[i-1]
        except IndexError:
          print("{0} is not in the list, exiting...".format(i))
          sys.exit(1)
    else:
      libudf = local_libs[0]
  else:
    libudf = "libudf"

dim_opts = ["2d","3d"]
precision_opts = ["","dp"]
serial_parallel_opts = ["","_host","_node"]


current_versions = []

if not args.all_versions:

    if not args.only:
      current_versions = current_lib_versions(libudf)

    dim_opts = []

    if args.two_dimensional:
        dim_opts.append("2d")

    if args.three_dimensional:
        dim_opts.append("3d")

    if not dim_opts and not current_versions: # 3d is default if neither choice set and no current versions exist
      dim_opts = ["3d"]

    if not args.double_precision:
        precision_opts = [""]

    if args.double_precision and args.only:
        precision_opts = ["dp"]

    if not args.parallel:
        serial_parallel_opts = [""]

    if args.parallel and args.only:
        serial_parallel_opts = ["_host","_node"]


Fluent_versions = [dim+precision+para for dim in dim_opts for precision in precision_opts for para in serial_parallel_opts]


if current_versions:
    for version in current_versions:
      if version not in Fluent_versions:
        Fluent_versions.append(version)

# Boolean settings
use_local_scheme_files = args.scheme
verbose = args.verbose

include_path = ":".join(args.include_path)

if include_path:
  include_path = ":".join([os.path.abspath(p) for p in include_path.split(":")]) # Make all path elements absolute
  scons_args.append('USER_INCLUDE_PATH="{0}"'.format(include_path))


user_objects = ":".join(args.user_objects)

if user_objects:
  user_objects = ":".join([os.path.abspath(p) for p in user_objects.split(":")]) # Make all object references absolute
  scons_args.append('USER_OBJECTS="{0}"'.format(user_objects))


libudfsrc = os.path.join(libudf,"src")

if not os.path.exists(libudf):
    os.mkdir(libudf)

if not os.path.exists(libudfsrc):
    os.mkdir(libudfsrc)

SConstruct, SConscript = get_SCons_files(scons_src_path)


if SConstruct:
    shutil.copyfile(SConstruct, os.path.join(libudf,"SConstruct"))
else:
    print("SConstruct file not found in "+scons_src_path)

if SConscript:
    shutil.copyfile(SConscript, os.path.join(libudfsrc,"SConscript"))
else:
    print("SConscript file not found in "+scons_src_path)


# Move any source files in current directory to libudf/src

source_files  = glob.glob("*.c")
source_files += glob.glob("*.c++")
source_files += glob.glob("*.cpp")
source_files += glob.glob("*.h")
source_files += glob.glob("*.h++")
source_files += glob.glob("*.hpp")

for file in source_files:
    if os.path.isfile(file):
        if os.path.islink(file):
            os.symlink(os.path.realpath(file), os.path.join(libudfsrc,file))
            os.unlink(file)
        else:
            os.rename(file, os.path.join(libudfsrc,file))

# If it exists, put addon.scm in libudf/lib

scheme_files = glob.glob("addon.scm")

if scheme_files:

  if use_local_scheme_files: 
    scheme_files += glob.glob("*.scm")

  libudflib = os.path.join(libudf,"lib")
  if not os.path.exists(libudflib):
      os.mkdir(libudflib)

  for file in scheme_files:
    if os.path.isfile(file):
        if os.path.islink(file):
            os.symlink(os.path.realpath(file), os.path.join(libudflib,file))
            os.unlink(file)
        else:
            os.rename(file, os.path.join(libudflib,file))


for version in Fluent_versions:
   scons_command = ["scons", "versions="+version] + scons_args

   print(os.linesep+"Building "+libudf+" for "+version)


   scons_pipe = subprocess.Popen(scons_command, bufsize=1, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=libudf)

   for line in filter_scons_output(scons_pipe, verbose):
       print(line)
