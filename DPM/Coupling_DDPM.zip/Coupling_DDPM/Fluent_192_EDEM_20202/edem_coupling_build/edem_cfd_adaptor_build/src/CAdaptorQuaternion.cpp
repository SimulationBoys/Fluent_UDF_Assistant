// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum

#include "CAdaptorQuaternion.h"
#include "IEDEMCoupling.h"

using namespace NApiEDEM;

const double CAdaptorQuaternion::DOUBLE_UNDERFLOW = 1e-25;

CAdaptorQuaternion::CAdaptorQuaternion()
: m_nX(0.0), m_nY(0.0), m_nZ(0.0), m_nW(1.0)
{
    ; //deliberately left empty
}

CAdaptorQuaternion::CAdaptorQuaternion(double w, double x, double y, double z)
: m_nX(x), m_nY(y), m_nZ(z), m_nW(w)
{
    ; //deliberately left empty
}

CAdaptorQuaternion::CAdaptorQuaternion(const CAdaptorQuaternion& q)
{
    m_nW = q.m_nW;
    m_nX = q.m_nX;
    m_nY = q.m_nY;
    m_nZ = q.m_nZ;
}

const CAdaptorQuaternion& CAdaptorQuaternion::operator = (const CAdaptorQuaternion& q)
{
    m_nW = q.m_nW;
    m_nX = q.m_nX;
    m_nY = q.m_nY;
    m_nZ = q.m_nZ;
    return *this;
}

CAdaptorQuaternion CAdaptorQuaternion::operator * (const CAdaptorQuaternion& q) const
{
    return CAdaptorQuaternion( m_nW*q.m_nW - m_nX*q.m_nX - m_nY*q.m_nY - m_nZ*q.m_nZ,
                        m_nW*q.m_nX + m_nX*q.m_nW + m_nY*q.m_nZ - m_nZ*q.m_nY,
                        m_nW*q.m_nY + m_nY*q.m_nW + m_nZ*q.m_nX - m_nX*q.m_nZ,
                        m_nW*q.m_nZ + m_nZ*q.m_nW + m_nX*q.m_nY - m_nY*q.m_nX);
}

const CAdaptorQuaternion& CAdaptorQuaternion::operator *= (const CAdaptorQuaternion& q)
{
    double w_val = m_nW*q.m_nW - m_nX*q.m_nX - m_nY*q.m_nY - m_nZ*q.m_nZ;
    double x_val = m_nW*q.m_nX + m_nX*q.m_nW + m_nY*q.m_nZ - m_nZ*q.m_nY;
    double y_val = m_nW*q.m_nY + m_nY*q.m_nW + m_nZ*q.m_nX - m_nX*q.m_nZ;
    double z_val = m_nW*q.m_nZ + m_nZ*q.m_nW + m_nX*q.m_nY - m_nY*q.m_nX;
 
    m_nW = w_val;
    m_nX = x_val;
    m_nY = y_val;
    m_nZ = z_val;

    return *this;
}

CAdaptorQuaternion CAdaptorQuaternion::scale(double s) const
{
    return CAdaptorQuaternion(m_nW*s, m_nX*s, m_nY*s, m_nZ*s);
}

CAdaptorQuaternion CAdaptorQuaternion::inverse() const
{
    return conjugate().scale(1/magnitudeSquared());
}

CAdaptorQuaternion CAdaptorQuaternion::conjugate() const
{
    return CAdaptorQuaternion(m_nW, -m_nX, -m_nY, -m_nZ);
}

const CAdaptorQuaternion& CAdaptorQuaternion::normalise()
{
    double mag = magnitudeSquared();

    if (!isZero(mag)) //only normalise if length isn't zero.
    {
        double dinv = invsqrt(mag);
        m_nW *= dinv;
        m_nX *= dinv;
        m_nY *= dinv;
        m_nZ *= dinv;
    }

    return *this;
}

C3dValue CAdaptorQuaternion::rotate(const C3dValue &vector) const
{
    CAdaptorQuaternion  qv(0.0, vector.x(), vector.y(), vector.z());
    CAdaptorQuaternion  me(*this);
    CAdaptorQuaternion  qm = me * qv * me.inverse();

    return C3dValue(qm.m_nX, qm.m_nY, qm.m_nZ);
}
