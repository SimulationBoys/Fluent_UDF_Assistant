// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum

#ifndef C_PARTICLE_DATA_H
#define C_PARTICLE_DATA_H

#include <map>
#include "CDiscreteElement.h"

class CParticleData
{
public:

    /**
     * The first entry in the pair is the number of elements that
     * comprise the custom property. The second entry is a pointer
     * to the start of the array
     */
    typedef std::pair<int, double*> tCustomPropData;
    /* The key is the property index */
    typedef std::map<int, tCustomPropData> tCustomPropMap;
    typedef tCustomPropMap::iterator tCustomPropMapIt;


    /** Default constructor to be used if an empty instance is required */
    CParticleData();

    /** Overloaded constructor to be used if particle data is to be added immediately */
    CParticleData(int numParticles, NApiCfd::CDiscreteElement* dataArray);

    /** Destructor ensures all particle data and customproperties are delete appropriately */
    ~CParticleData();

    /**
     * Returns pointer to a particle of index 
     * @param index - The index of the particle to return
     * @return A pointer to the particle
     */
    NApiCfd::CDiscreteElement* getParticle(int index);

    /**
     * Get a pointer the a custom property entry based on the particle index
     * Returns a null pointer if nothing is found
     * @param propertyIndex - The index representing the custom property
     * @param particleIndex - The index of the particle to return
     * @return Return a pointer to the custom property
     */
    double* getCustomProperty(int propertyIndex, int particleIndex);

    /**
     * Update the particle data
     * @param numParticles - The number of particles being held in the array
     * @param dataArray - The array that will be updated
     * @return Return whether update was successful
     */
    virtual bool updateParticleData(int numParticles, NApiCfd::CDiscreteElement* dataArray);

    /**
     * Adds a custom property to be managed with the particle data. Returns true
     * if the property index does not exist and is registered successfully. Returns 
     * false if the property index already exists and is not registered
     * @param customPropIndex - The index representing the custom property
     * @param numPropElements - The number of elements constituting the custom property
     * @return Return whether the operation was successful
     */
    bool addCustomProperty(int customPropIndex, int numPropElements);

    /**
     * Clears any particle data that may currently be being held in the datamap
     */
    void clearParticleData();

    /**
     * Update the custom property data of an already register property. Returns true
     * if the property index is found and the data array pointer is stored successfully.
     * Returns false if the property index is not found
     * @param numParticles - The number of particles in the simulation
     * @param propertyIndex - The index representing the custom property
     * @param dataArray - Pointer to the custom property data
     * @return Returns whether operation was successful
     */
    bool updateCustomProperty(int numParticles, int propertyIndex, double* dataArray);

    /**
     * Check whether a custom property has been registered
     * @param propertyIndex - The index represetning the custom property
     * @return Returns whether the property was found
     */
    bool hasCustomProperty(int propertyIndex);

    /**
     * Returns the number of particles in the whole simulation
     * @return Return the number of particles
     */
    int getNumParticles() { return m_numParticles; };

    /**
     * Returns the number of custom properties in the simulation
     * @return Return the number of custom properties
     */
    int getNumCustomProps() { return m_numCustomProps; };

    /**
     * Returns the number of elements a custom property has.
     * If the property is not found the number of elements is registered
     * as zero
     * @param index - The index of the custom property
     * @return Returns the number of elements
     */
    int getPropertyElements(int index);

protected:

    /* Number of particles */
    int m_numParticles;
    /* Number of custom properties that exist */
    int m_numCustomProps;
    /* Pointer to an array with m_numParticles elements */
    NApiCfd::CDiscreteElement* m_particleData;
    /* A vector holding pointers to each custom property array */
    tCustomPropMap m_customProperties;
};

#endif /* C_PARTICLE_DATA_H */
