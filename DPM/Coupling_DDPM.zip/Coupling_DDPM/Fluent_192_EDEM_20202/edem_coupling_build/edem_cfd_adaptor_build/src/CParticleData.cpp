// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum


#include "CParticleData.h"

using namespace std;
using namespace NApiCfd;

CParticleData::CParticleData()
{
    m_particleData = 0;
    m_numCustomProps = 0;
}

CParticleData::CParticleData(int numParticles, CDiscreteElement* dataArray)
{
    m_numParticles = numParticles;
    m_particleData = dataArray;
    m_numCustomProps = 0;
}

CParticleData::~CParticleData()
{
    // Clear the particle data array
    if(m_particleData)
    {
        delete[] m_particleData;
    }

    // If there are any custom properties clear them
    if(!m_customProperties.empty())
    {
        tCustomPropMapIt it;

        for(it = m_customProperties.begin(); it != m_customProperties.end(); ++it)
        {
            if(it->second.second)
            {
                delete[] it->second.second;
                it->second.second = 0;
            }
        }
    }
}

CDiscreteElement* CParticleData::getParticle(int particleIndex)
{
    return &m_particleData[particleIndex];
}

double* CParticleData::getCustomProperty(int propertyIndex, int particleIndex)
{
    double* result = 0;

    if(particleIndex < m_numParticles)
    {
        tCustomPropMapIt it = m_customProperties.find(propertyIndex);

        // Check if the map has found that custom property
        if(it != m_customProperties.end())
        {
            // Do property index x number of property elements to get the the correct
            // entry
            int numElements = it->second.first;
            
            result = it->second.second + (particleIndex * numElements);
        }
    }

    //if the custom property has not been found return a null pointer
    return result;
}

bool CParticleData::updateParticleData(int numParticles, CDiscreteElement* dataArray)
{
    // If there is existing data then delete it before assigning new data
    if(m_particleData)
    {
        delete[] m_particleData;
    }

    m_numParticles = numParticles;
    m_particleData = dataArray;

    return true;
}

bool CParticleData::addCustomProperty(int customPropIndex, int numPropElements)
{
    bool success = false;
    
    //first have a look to see if the property has been added already
    if(numPropElements > 0 && m_customProperties.find(customPropIndex) == m_customProperties.end())
    {
        // Add the number of propElements and a NULL pointer do data
        tCustomPropData data = tCustomPropData(numPropElements, (double*)NULL);
        pair <int, tCustomPropData> mapEntry = pair <int, tCustomPropData> (customPropIndex, data);
        
        m_customProperties.insert(mapEntry);

        m_numCustomProps += 1;
        success = true;
    }
    
    return success;
}

bool CParticleData::updateCustomProperty(int numParticles, int propertyIndex, double* dataArray)
{
    bool success = false;

    if( numParticles == m_numParticles)
    {
        // first check that the propertyIndex is has been registered
        // property index should always be at least 1 less than the size of the vector
        // as there is data held at element 0 of the vector
        tCustomPropMapIt it;
        it = m_customProperties.find(propertyIndex);
        
        //If the property index can't be found then the property has not been registered
        if(it != m_customProperties.end())
        {

            // copy the memory into the particle data to be managed
            //int numElems = it->second.first;
            //double* tmp = new double[numElems * numParticles];
            //memcpy(tmp, dataArray, numElems*numParticles*sizeof(double));

            // delete the old data if there is any
            if(it->second.second)
            {
                delete[] it->second.second;
                it->second.second = 0;
            }
            
            int numElems = it->second.first;

            /* Now reallocate memory to take the new custom property */
            it->second.second = new double[numElems * numParticles];
            memcpy(it->second.second, dataArray, numParticles * numElems * sizeof(double));
            success = true;
        }
    }
    
    return success;
}

void CParticleData::clearParticleData()
{
    if(m_particleData)
    {
        delete[] m_particleData;
        m_particleData = 0;
    }

    // If there are any custom properties clear them
    if(!m_customProperties.empty())
    {
        tCustomPropMapIt it;

        for(it = m_customProperties.begin(); it != m_customProperties.end(); ++it)
        {
            if(it->second.second)
            {
                delete[] it->second.second;
                it->second.second = 0;
            }
        }
        m_customProperties.clear();
    }

    m_numParticles = 0;
    m_numCustomProps = 0;
}

bool CParticleData::hasCustomProperty(int propertyIndex)
{
    // first check that the propertyIndex is has been registered
    // property index should always be at least 1 less than the size of the vector
    // as there is data held at element 0 of the vector
    tCustomPropMapIt it;
    it = m_customProperties.find(propertyIndex);
    
    //If the property index can't be found then the property has not been registered
    return it != m_customProperties.end();
}

int CParticleData::getPropertyElements(int propertyIndex)
{
    int propElements = 0;
    
    tCustomPropMapIt it;
    it = m_customProperties.find(propertyIndex);

    if(it != m_customProperties.end())
    {
        propElements = it->second.first;
    }

    return propElements;
}
