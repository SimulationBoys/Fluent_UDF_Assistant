// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum

#ifndef _CFLUENT_PARTICLE_DATA_H_
#define _CFLUENT_PARTICLE_DATA_H_

#include <map>

#include "CParticleData.h"
#include "udfParticle.h"

class CCellAndThreadData;

class CFluentParticleData : public CParticleData
{
public:
    
    /** The first entry indicates the particle type, the second the particle id */
    typedef std::pair<int, int> tParticleIdentifier;
    /** Using the identifier as a key, create a pair with the CCellAndThreadData */
    typedef std::pair<tParticleIdentifier, CCellAndThreadData> tParticleEntry;
    typedef std::map<tParticleIdentifier, CCellAndThreadData> tParticleMap;
    typedef tParticleMap::iterator tParticleMapIt;

    /** Default constructor */
    CFluentParticleData();

    /** Overloaded constructor to be used if particle data is to be added immediately */
    CFluentParticleData(int numParticles, NApiCfd::CDiscreteElement* dataArray);

    /** Default destructor */
    ~CFluentParticleData();

    /**
     * Updates the particle data map with Discrete element IDs,
     * This saves all the cell and thread IDs from existing particles and
     * creates new ones for the new particles in the system
     * @param numParticles - The number of particles in the DiscreteElement array
     * @param data - The data array containing the particle data
     * @return Returns a success boolean to determine the success of the operation
     */
    virtual bool updateParticleData(int numParticles, NApiCfd::CDiscreteElement* data);

    /**
     * Returns a particle from the map a null pointer is returned
     * if the particle in not found
     * @param type - The particle type as an int index
     * @param id - The actual particle ID as an int index
     * @return Returns a pointer the particle data
     */
    NApiCfd::CDiscreteElement* getParticleById(int type, int id);

    /**
     * Sets the cell and thread indexes for a particle, when they need to be updated
     * @param index - The particle index
     * @param cell - The cell index
     * @param thread - the thread index
     * @return Returns whether the operation was successful
     */
    bool setCellAndThread(int index, const cell_t& cell, void* thread);


private:
    
    /**
     * Private method called to update the particle map when new data is added
     * @param numParticles - The number of particles to be added
     * @param data - Pointer to the data being updated
     */
    void updateParticleMap(int numParticles, NApiCfd::CDiscreteElement* data);
    
    /**
     * A simple map matching the a pair of particle type and ID to 
     * the struct DiscreteElement containing the particle data
     */
    tParticleMap* m_particleMap;
};

#endif //_CFLUENT_PARTICLE_DATA_H_
