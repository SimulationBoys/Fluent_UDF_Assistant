// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum

#include "CCellAndThreadData.h"
#include "CFluentParticleData.h"

using namespace std;

CFluentParticleData::CFluentParticleData()
: CParticleData()
{
    m_particleMap = new tParticleMap();
}

CFluentParticleData::CFluentParticleData(int numParticles, NApiCfd::CDiscreteElement* dataArray)
: CParticleData(numParticles, dataArray)
{
    m_particleMap = new tParticleMap();
    
    /* update the particle map with the new data */
    updateParticleMap(numParticles, dataArray);
}

CFluentParticleData::~CFluentParticleData()
{
    /* For saftey clear the map before destruction */
    if(!m_particleMap->empty())
    {
        m_particleMap->clear();
    }
    delete m_particleMap;
}

bool CFluentParticleData::updateParticleData(int numParticles, NApiCfd::CDiscreteElement* data)
{
    /* If there is existing data then delete it before assigning new data */
    if(m_particleData)
    {
        delete[] m_particleData;
    }

    m_numParticles = numParticles;
    m_particleData = data;

    /* update the cell and thread info */
    updateParticleMap(numParticles, data);

    return true;
}

NApiCfd::CDiscreteElement* CFluentParticleData::getParticleById(int type, int id)
{
    tParticleMap::iterator it;
    tParticleIdentifier particleIdent (type, id);
    NApiCfd::CDiscreteElement* elem = 0;

    it = m_particleMap->find(particleIdent);
   
    /* If the returned data is at the end of the map then the
     * type/ id has not been found so return the pointer as a null */
    if( it != m_particleMap->end() )
    {
        elem = (it->second.getParticle());
    }

    return elem;
}

bool CFluentParticleData::setCellAndThread(int index, const cell_t& cell, void* thread)
{
    bool success = false;
    
    NApiCfd::CDiscreteElement* part = getParticle(index);

    tParticleMap::iterator it;
    tParticleIdentifier particleIdent (part->getTypeIndex(), part->getElemID());
    NApiCfd::CDiscreteElement* elem = 0;

    it = m_particleMap->find(particleIdent);
   
    /* If the returned data is at the end of the map then the
     * type/ id has not been found so return the pointer as a null */
    if( it != m_particleMap->end() )
    {
        elem = it->second.getParticle();
        
        /* delete the old entry so it can be updated */
        m_particleMap->erase(it);

        CCellAndThreadData existingCellThread = CCellAndThreadData(elem, cell, thread);
        pair <tParticleIdentifier, CCellAndThreadData> existIdentCellPair (particleIdent, existingCellThread);
            
        m_particleMap->insert(existIdentCellPair);

        success = true;
    }

    return success;
}

void CFluentParticleData::updateParticleMap(int numParticles, NApiCfd::CDiscreteElement* data)
{
    tParticleMap* newDataMap = new tParticleMap();
   
    for(int i = 0; i < numParticles; ++i)
    {
        /* first look for the particle in the existing map */
        int particleType = m_particleData[i].getTypeIndex();
        int particleId = m_particleData[i].getElemID();

        tParticleIdentifier ident (particleType, particleId);

        tParticleMapIt it = m_particleMap->find(ident);
        
        /* is there a matching entry? */
        if(it != m_particleMap->end())
        {
            /* Need to retreive the cell and thread data from the old entry */
            cell_t cell = it->second.getCell();
            void* thread = it->second.getThread();

            /* an object containing the new particle pointer, cell and thread data */
            CCellAndThreadData existingCellThread = CCellAndThreadData(&data[i], cell, thread);
            pair <tParticleIdentifier, CCellAndThreadData> existIdentCellPair (ident, existingCellThread);
            
            newDataMap->insert(existIdentCellPair);

            /* Now erase the entry from the map so that it is not necessary to iterate over it again */
            m_particleMap->erase(it);
        }
        else
        {
            /* add an entry to the map for a new particle */
            CCellAndThreadData newCellAndThread = CCellAndThreadData(&data[i]);
            pair <tParticleIdentifier, CCellAndThreadData> newIdentCellPair (ident, newCellAndThread);
            
            newDataMap->insert(newIdentCellPair);
        }

    }
    /* Delete any remaining data in the old data map */
    m_particleMap->clear();
    delete m_particleMap;

    /* and set the pointer to the new data map for continued use */
    m_particleMap = newDataMap;
}
