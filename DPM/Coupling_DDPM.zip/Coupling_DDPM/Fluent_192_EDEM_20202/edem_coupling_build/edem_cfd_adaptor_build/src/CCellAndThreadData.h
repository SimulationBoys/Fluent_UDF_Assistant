// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum

#ifndef _CCELL_AND_THREAD_DATA_H_
#define _CCELL_AND_THREAD_DATA_H_

#include "CDiscreteElement.h"
#include "udfParticle.h"

class CCellAndThreadData
{
public:

    CCellAndThreadData();
    
    /**
     * Constructor. The values -1 and 0 represent the indexes for a null cell and null thread
     * as defined by the EDEM UDF therefore if these have no initial value initialise to null
     * @param cellIndex = -1  - The cell index the particle is in
     * @param threadIndex = 0 - The cell thread the particle is handled by
     * @param particle - The pointer to the particle that the cell and thread data is linked to
     */
    CCellAndThreadData(NApiCfd::CDiscreteElement* particle, cell_t cellIndex = -1, void* threadIndex = 0);
    
    /**
     * Returns the cell index the particle belongs to
     * @return Return the cell reference
     */
    cell_t getCell() {return m_cellIndex;};

    /**
     * Returns the thread the particle belongs to
     * @return Return the cell thread
     */
    void* getThread() {return m_cellThread;};

    /**
     * Returns the pointer to the particle this data is associated with
     * @return Returns the particle pointer
     */
    NApiCfd::CDiscreteElement* getParticle() {return m_particleData;};

private:

    cell_t m_cellIndex;

    void* m_cellThread;

    NApiCfd::CDiscreteElement* m_particleData;
};

#endif //_CCELL_AND_THREAD_DATA_H_
