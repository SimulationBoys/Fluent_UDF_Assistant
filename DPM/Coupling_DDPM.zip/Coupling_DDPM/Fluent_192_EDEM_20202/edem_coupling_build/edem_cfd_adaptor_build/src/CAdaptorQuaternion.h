// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum

#ifndef _CADAPTOR_QUATERNION_H_
#define _CADAPTOR_QUATERNION_H_

#include <cmath>
#include "vectorMaths.h"


class CAdaptorQuaternion
{
public:
    static const double DOUBLE_UNDERFLOW;
    
    /** Default constructor */
    CAdaptorQuaternion();

    /** Constructor with initial values */
    CAdaptorQuaternion(double w, double x, double y, double z);

    /** Copy constructor */
    CAdaptorQuaternion(const CAdaptorQuaternion& q);

    /** Equals operator */
    const CAdaptorQuaternion& operator = (const CAdaptorQuaternion& q);

    /** Multiplication operator */
    CAdaptorQuaternion operator * (const CAdaptorQuaternion& q) const;

    const CAdaptorQuaternion& operator *= (const CAdaptorQuaternion& q);
    
    /** Scales the quaternion */
    CAdaptorQuaternion scale(double s) const;

    /** Produces the inverse quaternion */
    CAdaptorQuaternion inverse() const;

    /** Produces the conjugate of the quaternion */
    CAdaptorQuaternion conjugate() const;

    /** Normailises the quaternion */
    const CAdaptorQuaternion& normalise();

    /** Rotates a vector based on the quaternion */
    NApiEDEM::C3dValue rotate(const NApiEDEM::C3dValue &vector) const;

    double magnitudeSquared() const { return m_nW*m_nW + m_nX*m_nX + m_nY*m_nY + m_nZ*m_nZ; };
    
    double magnitude()        const { return sqrt(magnitudeSquared()); };

    template <class T>
    inline bool isZero(const T t, const T nLimit = DOUBLE_UNDERFLOW)
    {
        return (t <= nLimit && t >= (-nLimit));
    }

    /* Use the Newton Raphson method inverse sqrt method */
    inline double invsqrt(double x)
    {   
        int newtonRaphsonIterations = 4; 
        double xhalf = 0.5f*x;
        long long i = *(long long*)&x; /* get bits for floating value */

        i = 0x5fe6ec85e7de30daLL - (i>>1); /* gives initial guess y0 */

        x = *(double*)&i; /* convert bits back to float */

        for ( int i = 0; i < newtonRaphsonIterations; ++i)
        {
            x = x*(1.5f-xhalf*x*x); /* Newton step, repeating increases accuracy */
        }

        return x;
    }

private:
 
    double	m_nW, m_nX, m_nY, m_nZ;
};

#endif /* _CADAPTOR_QUATERNION_H_ */

