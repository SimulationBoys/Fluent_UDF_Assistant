// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 2.0
// Copyright 2014 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Check for the latest news at
//
// http://www.dem-solutions.com/forum


#include <string>

#include "AdaptorInterface.h"
#include "IEDEMCoupling.h"
#include "CDiscreteElement.h"
#include "CFluentParticleData.h"
#include "vectorMaths.h"
#include "CAdaptorQuaternion.h"
#include "udfParticle.h"


using namespace std;
using namespace NApiCfd;



/* An instance of the CFD coupling with which to interact */
NApiEDEM::IEDEMCoupling g_CfdCoupling = NApiEDEM::IEDEMCoupling();


/* The particle prototype data that will be used with the coupling */
int g_numPrototypes = 0;
CElementPrototype *g_prototypeData = 0;

/* The particle data that will be used with the coupling */
CFluentParticleData g_particleData = CFluentParticleData();


// ADAP_INT void ADAPTOR_initialiseEDEMCoupling(int *success)
// {
    // /* C++ interface takes a boolean reference */
    // bool boolSuccess;

	// g_CfdCoupling.disableGuiWarnings(true);
    // boolSuccess = g_CfdCoupling.initialiseCoupling();

    // *success = boolSuccess ? 1 : 0;
// }

// ADAP_INT void ADAPTOR_connectEDEMCoupling(int *success)
// {
    // /* C++ interface takes a boolean reference */
    // bool boolSuccess;

	// g_CfdCoupling.disableGuiWarnings(true);
    // boolSuccess = g_CfdCoupling.connectCoupling();

    // *success = boolSuccess ? 1 : 0;
// }

ADAP_INT void ADAPTOR_init_connectEDEMCoupling(int *success)
{
    /* C++ interface takes a boolean reference */
    bool boolSuccess = false;

	g_CfdCoupling.disableGuiWarnings(true);

	if(g_CfdCoupling.initialiseCoupling())
      {
        boolSuccess = g_CfdCoupling.connectCoupling();
      }

    *success = boolSuccess ? 1 : 0;
}
 
/**  Connecting function has default value parameters 
         * Connects the coupling to EDEM
         * @param showGui - Determines whether to pop up a warning Gui for connection
         *                  Requires GUI support to choose true.
         * @param ipAddress - The network address of the computer to connect to. Default
                              parameter is the localhost IP
         * @return success - Determines whether the connection was successful

        bool connectCoupling(bool showGui = false, char ipAddress[15] = "127.000.000.001"); */

ADAP_INT void ADAPTOR_init_connectEDEMCoupling_Address(int *success, char ipAddress[15])
{
    /* C++ interface takes a boolean reference */
    bool boolSuccess = false;

	g_CfdCoupling.disableGuiWarnings(true);

	if(g_CfdCoupling.initialiseCoupling())
	{
      boolSuccess = g_CfdCoupling.connectCoupling(false, ipAddress);
	}

    *success = boolSuccess ? 1 : 0;
}


ADAP_INT void ADAPTOR_disconnectEDEMCoupling(int *success)
{
    /* C++ interface takes a boolean reference */
    bool boolSuccess = false;

	g_CfdCoupling.disableGuiWarnings(true);

    boolSuccess = g_CfdCoupling.disconnectCoupling();

    *success = boolSuccess ? 1 : 0;
}
 

/*
ADAP_INT void ADAPTOR_newMeshFile(const char* filename,
                                  const double* gravity,
                                  const char* meshFilename,
                                  int* success)
{
    bool boolSuccess = g_CfdCoupling.newGeometry(filename, meshFilename); 

    if(boolSuccess)
    {
        NApiEDEM::C3dValue grav(gravity[0], gravity[1], gravity[2]);
        boolSuccess = g_CfdCoupling.setGravity(grav);
    }

    *success = boolSuccess ? 1 : 0;
}
*/

ADAP_INT void ADAPTOR_showCreator(int* success)
{
    bool boolSuccess = g_CfdCoupling.showCreator();

    *success = boolSuccess? 1 : 0;
}


ADAP_INT void ADAPTOR_showSimulator(int *success)
{
    bool boolSuccess = g_CfdCoupling.showSimulator();

    *success = boolSuccess? 1 : 0;
}


ADAP_INT void ADAPTOR_showAnalyst(int *success)
{
    bool boolSuccess = g_CfdCoupling.showAnalyst();

    *success = boolSuccess? 1 : 0;
}


ADAP_INT void ADAPTOR_stopSimulation(int *success)
{
    bool boolSuccess = g_CfdCoupling.stopSimulation();

    *success = boolSuccess? 1 : 0;
}


// ADAP_INT void ADAPTOR_performAnalysisStep(double cfdTimeStep, int* bSuccess)
// {
    // bool boolSuccess;
    // double edemTimeStep;

	// boolSuccess = g_CfdCoupling.getEDEMTimeStep(edemTimeStep);

    // if(boolSuccess)
      // {
        // int nEdemTimeStepsToSimulate;

        // /* Number of EDEM Time Steps is rounded to closest integer */
        // nEdemTimeStepsToSimulate = (int)((cfdTimeStep/edemTimeStep)+0.5); 
        // boolSuccess = g_CfdCoupling.simulate(nEdemTimeStepsToSimulate);
      // }

    // *bSuccess = boolSuccess ? 1 : 0;
// }

ADAP_INT void ADAPTOR_performNumAnalysisSteps(int nEdemTimeStepsToSimulate, int* bSuccess)
{
  bool boolSuccess;

  boolSuccess = g_CfdCoupling.simulate(nEdemTimeStepsToSimulate);

  *bSuccess = boolSuccess ? 1 : 0;
}

ADAP_INT void ADAPTOR_performAnalysisToTime(double cfdTime, int* bSuccess)
{
    bool boolSuccess;
    double edemTimeStep, edemTime;

	boolSuccess = g_CfdCoupling.getEDEMTimeStep(edemTimeStep) &&
                  g_CfdCoupling.getEDEMTime(edemTime);

    if(boolSuccess)
      {
        int nEdemTimeStepsToSimulate;
        double edemEndTime;

        /* Number of EDEM Time Steps is rounded to closest integer */
        nEdemTimeStepsToSimulate = (int)(((cfdTime-edemTime)/edemTimeStep)+0.5);

        /* Set edemEndTime to be one timestep beyond the finish time so that EDEM in command line mode doesn't stop */
        edemEndTime = edemTime + (nEdemTimeStepsToSimulate+1)*edemTimeStep;

        boolSuccess = g_CfdCoupling.simulate(nEdemTimeStepsToSimulate, edemEndTime);
      }

    *bSuccess = boolSuccess ? 1 : 0;
}


ADAP_INT void ADAPTOR_getEDEMTime(double *time, int *success)
{
    bool boolSuccess = g_CfdCoupling.getEDEMTime(*time);

    *success = boolSuccess ? 1 : 0;
}


ADAP_INT void ADAPTOR_setEDEMTime(double theTime,
							      int* success)
{
    bool boolSuccess = g_CfdCoupling.setEDEMTime(theTime);

    *success = boolSuccess ? 1 : 0;
}


ADAP_INT void ADAPTOR_selectDeck(char* filename,
                                 int* success)
{
    bool boolSuccess = g_CfdCoupling.selectDeck(filename);

    *success = boolSuccess ? 1 : 0;
}


ADAP_INT void ADAPTOR_rotateVector(double* vec, double* orientation)
{
    NApiEDEM::C3dValue v(vec[0], vec[1], vec[2]);
	CAdaptorQuaternion q(orientation[0], orientation[1], orientation[2], orientation[3]);

    v = q.rotate(v);

	vec[0] = v.x();
	vec[1] = v.y();
	vec[2] = v.z();
}

/* The particle prototype data that will be used with the coupling */


ADAP_INT int ADAPTOR_getParticlePrototypeData()
{
  int numTypes;

  numTypes = g_CfdCoupling.getNumParticleTypes();

  if (numTypes != g_numPrototypes)
    {
      if(g_prototypeData)
        delete[] g_prototypeData;

      if (numTypes)
        {
          g_prototypeData = new CElementPrototype[numTypes];
          g_CfdCoupling.getParticlePrototypeData(g_prototypeData);
        }
      else
        g_prototypeData = 0;

      g_numPrototypes = numTypes;
    }

  return numTypes;
}

ADAP_INT int ADAPTOR_getParticlePrototype(int index, ParticlePrototype *pp)
{
  if((index < g_numPrototypes) && (index >= 0) && g_prototypeData)
    {
      int nPrototypeID, nSurfaces;
      C3dValue moi;

      strncpy(pp->sPrototypeName, g_prototypeData[index].getParticleName(), MAX_DE_TYPENAME_SZ-1);
      pp->sPrototypeName[MAX_DE_TYPENAME_SZ-1]='\0';

      nPrototypeID = g_prototypeData[index].getParticleID();
      pp->nPrototypeID = nPrototypeID;

      nSurfaces = g_prototypeData[index].getSurfacesTotal();
      pp->nSurfaces = nSurfaces;
      pp->nMass = g_prototypeData[index].getMass();
      pp->nVolume = g_prototypeData[index].getVolume();

      moi = g_prototypeData[index].getMomentOfInertia();
      pp->vMomentOfInertia[0] = moi.x();
      pp->vMomentOfInertia[1] = moi.y();
      pp->vMomentOfInertia[2] = moi.z();

      /* Get the Prototype's Spheres */
      if(nSurfaces > 0)
        {
          int iSurf;
          NApiCfd::CParticleSphere *sphereData;
          C3dValue position;

          sphereData = new NApiCfd::CParticleSphere[nSurfaces];

          g_CfdCoupling.getPrototypeSpheres(nPrototypeID, sphereData);
  
          if(pp->pSphereData)
            delete[] pp->pSphereData;

          pp->pSphereData = new ParticleSphere[nSurfaces];
 
          for (iSurf=0;iSurf<nSurfaces;iSurf++)
            {
              strncpy(pp->pSphereData[iSurf].sSphereName, sphereData[iSurf].getSurfaceName(), MAX_DE_TYPENAME_SZ-1);
              pp->pSphereData[iSurf].sSphereName[MAX_DE_TYPENAME_SZ-1]='\0';

              pp->pSphereData[iSurf].nSphereID = sphereData[iSurf].getSurfaceID();
              pp->pSphereData[iSurf].nRadius = sphereData[iSurf].getRadius();
              pp->pSphereData[iSurf].bUsesContactRadius = sphereData[iSurf].usesContactRadius() ? 1 : 0;
              pp->pSphereData[iSurf].nContactRadius = sphereData[iSurf].getContactRadius();

              position = sphereData[iSurf].getPosition();
              pp->pSphereData[iSurf].vPosition[0] = position.x();
              pp->pSphereData[iSurf].vPosition[1] = position.y();
              pp->pSphereData[iSurf].vPosition[2] = position.z();
            }

          delete[] sphereData;
        }
      else
        {
          if(pp->pSphereData)
            delete[] pp->pSphereData;

          pp->pSphereData = 0;
        }

      return 1;
    }

  return 0;
}


ADAP_INT void ADAPTOR_clearParticlePrototypeData()
{
  if(g_prototypeData)
    delete[] g_prototypeData;

  g_prototypeData = 0;
  g_numPrototypes = 0;
}


ADAP_INT int ADAPTOR_getParticleData()
{
    bool boolSuccess = false;

    int numParticles = g_CfdCoupling.getNumParticles();
    
    // We need to allocate space for the particle data here and then copy the sent message across
    // to avoid issues with incompatible dlls (built with different compilers) accessing memory between
    // each other

    // This allocated memory will be deleted by the updateParticleData method so no need to do it here
    CDiscreteElement* particleData = new CDiscreteElement[numParticles];

    if(g_CfdCoupling.getParticleData(particleData))
    {    
        g_particleData.updateParticleData(numParticles, particleData);

        boolSuccess = true;
    }   
    
    return boolSuccess ? 1 : 0;
}


ADAP_INT void ADAPTOR_clearParticleData()
{
    g_particleData.clearParticleData();
}


ADAP_INT void ADAPTOR_getParticle(int index, DiscreteElement* particle)
{
    CDiscreteElement* tempParticle = g_particleData.getParticle(index);
    
    particle->elemID = tempParticle->getElemID();
    particle->typeIndex = tempParticle->getTypeIndex();
    strncpy(particle->sType,tempParticle->getType(), MAX_DE_TYPENAME_SZ-1);
    particle->sType[MAX_DE_TYPENAME_SZ-1]='\0';
    particle->vPos[0] = tempParticle->getPosition().x();
    particle->vPos[1] = tempParticle->getPosition().y();
    particle->vPos[2] = tempParticle->getPosition().z();
    particle->vVelocity[0] = tempParticle->getVelocity().x();
    particle->vVelocity[1] = tempParticle->getVelocity().y();
    particle->vVelocity[2] = tempParticle->getVelocity().z();
    particle->vAngVelocity[0] = tempParticle->getAngVelocity().x();
    particle->vAngVelocity[1] = tempParticle->getAngVelocity().y();
    particle->vAngVelocity[2] = tempParticle->getAngVelocity().z();
    particle->nVolume = tempParticle->getVolume();
    particle->nScale =  tempParticle->getScale();

    double* orient = tempParticle->getOrientation();
    particle->vOrientation[0] = orient[0];
    particle->vOrientation[1] = orient[1];
    particle->vOrientation[2] = orient[2];
    particle->vOrientation[3] = orient[3];
}


ADAP_INT void ADAPTOR_updateCellAndThread(int index, cell_t cell, void* thread)
{
    g_particleData.setCellAndThread(index, cell, thread);
}


ADAP_INT int ADAPTOR_getNumParticleTypes()
{
    int numTypes = g_CfdCoupling.getNumParticleTypes();
    return numTypes;
}


ADAP_INT int ADAPTOR_getNumParticles(int type)
{
    int numPart = g_CfdCoupling.getNumParticles(type);
    return numPart;
}


ADAP_INT int ADAPTOR_getTotalNumParticles()
{
    int numPart = g_CfdCoupling.getNumParticles();
    return numPart;
}


ADAP_INT void ADAPTOR_getNumParticlesPerType(int numParticleTypes, int* numParticlesPerType)
{
    for(int i = 0; i < numParticleTypes; i++)
    {
        numParticlesPerType[i] = ADAPTOR_getNumParticles(i);
    }
}


ADAP_INT int ADAPTOR_getParticleTypeSamplePoints(tDimensionValue* fluentSamplePoints,
                                                 int samples,
                                                 int type)
{
    int success = 0;

    /* pass the fluentSamplePoints array to the cfdCoupling interface and the data will be copied to it */ 
    bool boolSuccess = g_CfdCoupling.getParticleTypeSamplePoints(reinterpret_cast<double*>(fluentSamplePoints), samples, type);
    
    success = boolSuccess ? 1 : 0;

    return success;
}


ADAP_INT int ADAPTOR_setDragForceAndTorque(int numParticles, double* force, double* torque)
{
    int success = 0;
    
    bool boolSuccess = g_CfdCoupling.setForceAndTorque(numParticles, force, torque);
    
    success = boolSuccess ? 1 : 0;

    return success;
}


ADAP_INT int ADAPTOR_registerCustomProperty(char* name,
						                    int numberElements,
						                    int dataType,
						                    int unitType,
						                    double initialValue,
						                    int *index)
{
    bool boolSuccess = g_CfdCoupling.registerCustomProperty(name, numberElements, unitType,
                                                            initialValue, *index, dataType);

    /* Also register it in the adaptor's particle data */
    if( boolSuccess)
    {
        boolSuccess = g_particleData.addCustomProperty(*index, numberElements);
    }

    int success = boolSuccess ? 1 : 0;
    return success;
}


ADAP_INT int ADAPTOR_updateValuesForProperty(int numParticles, int propertyIndex)
{
    bool boolSuccess = true;
    if(numParticles > 0 && g_particleData.hasCustomProperty(propertyIndex))
    {
        /* change the value of the success boolean to check for correct updating of custom property */
        boolSuccess = false;
        
        int numElements = g_particleData.getPropertyElements(propertyIndex);

        /* initialise a pointer to collect the custom property data. It must be deleted here
         * when the data is no longer required*/
        double* tmp = new double[numParticles * numElements];
                
        if(g_CfdCoupling.getValueForProperty(numParticles, propertyIndex, numElements, tmp))
        {
            boolSuccess = g_particleData.updateCustomProperty(numParticles, propertyIndex, tmp);
        }

        delete[] tmp;
    }
    
    int success = boolSuccess ? 1 : 0;
    return success;
}


ADAP_INT int ADAPTOR_setValuesForProperty(int numParticles, int propertyIndex, double* data)
{
    bool boolSuccess = true;
    if(numParticles > 0 && g_particleData.hasCustomProperty(propertyIndex))
    {
        /* change the value of the success boolean to check for correct updating of custom property */
        boolSuccess = false;

        int numElements = g_particleData.getPropertyElements(propertyIndex);

        if(g_CfdCoupling.setValueForProperty(numParticles, propertyIndex, numElements, data))
        {
            boolSuccess = g_particleData.updateCustomProperty(numParticles, propertyIndex, data);
        }
    }

    int success = boolSuccess ? 1 : 0;
    return success;
}


ADAP_INT double* ADAPTOR_getProperty(int customPropIndex, int particleIndex)
{
    return g_particleData.getCustomProperty(customPropIndex, particleIndex);
}

ADAP_INT double ADAPTOR_getScalarProperty(int customPropIndex, int particleIndex)
{
    return *(g_particleData.getCustomProperty(customPropIndex, particleIndex));
}

