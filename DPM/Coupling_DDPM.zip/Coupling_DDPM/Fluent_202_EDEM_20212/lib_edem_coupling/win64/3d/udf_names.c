/**************************************/
/* This file generated automatically. */
/* Do not modify.                     */
/**************************************/

#include "udf.h"
#include "prop.h"
#include "dpm.h"
#include "version.h"

extern DEFINE_ON_DEMAND(register_edem_dpm_components);
extern DEFINE_DPM_DRAG(drag_ganser, Re, tp);
extern DEFINE_DPM_DRAG(drag_template, Re, tp);
extern DEFINE_DPM_SCALAR_UPDATE(dem_properties_template, c, ct, init, tp);
extern DEFINE_ADJUST(adjust_edem_solution, d);
extern DEFINE_EXECUTE_AT_END(update_edem_at_end);
extern DEFINE_EXECUTE_AT_EXIT(disconnect_edem_coupling_at_exit);
extern DEFINE_EXECUTE_ON_LOADING(bind_edem_subrs, libname);

__declspec(dllexport) UDF_Data udf_data[] = {
  {"register_edem_dpm_components", (void (*)(void))register_edem_dpm_components, UDF_TYPE_ON_DEMAND},
  {"drag_ganser", (void (*)(void))drag_ganser, UDF_TYPE_DPM_DRAG},
  {"drag_template", (void (*)(void))drag_template, UDF_TYPE_DPM_DRAG},
  {"dem_properties_template", (void (*)(void))dem_properties_template, UDF_TYPE_DPM_SCALAR_UPDATE},
  {"adjust_edem_solution", (void (*)(void))adjust_edem_solution, UDF_TYPE_ADJUST},
  {"update_edem_at_end", (void (*)(void))update_edem_at_end, UDF_TYPE_EXECUTE_AT_END},
  {"disconnect_edem_coupling_at_exit", (void (*)(void))disconnect_edem_coupling_at_exit, UDF_TYPE_EXECUTE_AT_EXIT},
  {"bind_edem_subrs", (void (*)(void))bind_edem_subrs, UDF_TYPE_EXECUTE_ON_LOADING}
};

__declspec(dllexport) int n_udf_data = 8;

__declspec(dllexport) void UDF_Inquire_Release(int *major, int *minor, int *revision)
{
  *major = RampantReleaseMajor;
  *minor = RampantReleaseMinor;
  *revision = RampantReleaseRevision;
}
