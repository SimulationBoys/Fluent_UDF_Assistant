#include "udf.h"
#include "edem_coupling.h"
#include "compute_particle_heat_flux.h"
#include "version.h"

#define PP_PROJECTED_AREA(P)(0.25*M_PI*SQR(PP_DIAM(P)))
#define TP_PROJECTED_AREA(P) PP_PROJECTED_AREA(P)

#if !RP_HOST
static void
compute_next_velocity(real dt, real a[3], real b, real V0[3], real Vn[3])
{
  real beta_fact = 1./(1. + b*dt);
  int i;

  for (i=0; i<3; ++i)
    Vn[i] = (V0[i] + dt *a[i]) * beta_fact;
}
#endif

void compute_particle_forces_using_Fluent(Tracked_Particle *tp, Injection *I, cxboolean fluid_source_terms)
{
#if !RP_HOST
  Particle *pp;

  loop (pp, I->p)
    {
      real N3V_VEC(acc);         /* explicit part of particle acceleration */
      real N3V_VEC(dvdt) = {0.}; /* velocity derivative, not used */
      real beta;                 /* drag factor */
      real vmf_inv;              /* virtual mass factor */
      real next_vel[6];          /* first 3 components contain new velocity, last 3 components carry old velocity */
      cxboolean update_randoms = FALSE; /* do not update particle random numbers for Brownian motion inside ParticleAcceleration */
      cxboolean cphase_interaction = TRUE; /* fill relevant fluid source terms inside HeatMassUpdate. */
      particle_state_t p_old;    /* needed to restore unintended changes in HeatMassUpdate */


      /* Fill tracked particle with information in pp and interpolate cphase_state */

#if (RampantReleaseMajor <= 17)
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, FALSE);
#endif

#if (RampantReleaseMajor == 18)
# if (RampantReleaseMinor >= 1)
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, TRUE);
# else
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, FALSE, TRUE);
# endif
#endif

#if (RampantReleaseMajor >= 19)
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, TRUE);
#endif


      TP_DT(tp) = pp->next_time_step;
      TP_TIME(tp) += TP_DT(tp);
      
      if (DEM_DRAG_FLUENT_P(edem_coupling))
        {
          real p_dem_mass;

          /* Now do a virtual step into the particle's direction for the given flow time step */
          ParticleAcceleration(tp, acc, dvdt, &beta, &vmf_inv, update_randoms);
          compute_next_velocity(TP_DT(tp), acc,  beta, TP_VEL(tp), next_vel);

          /* acc is carrying explicit part of particle acceleration, 
           * let us add implicit part and subtract gravity included in body forces
           * to provide fluid related acceleration to EDEM as a force */
          N3V_VS(acc,-=,PP_VEL(pp),*,beta);
          /*           N3V_V (acc, -=, tp->source.bf_acc); */
          N3V_V (acc,-=,solver_par.G);

          p_dem_mass = PP_N(pp) * PP_MASS(pp);

          /* Now compute the particle force from the acceleration */
          ND_VS(PP_DEM_FORCE_X(pp),PP_DEM_FORCE_Y(pp),PP_DEM_FORCE_Z(pp),=,acc,*,p_dem_mass);

          /* Update velocity of tracked particle to be considered in AddSources */
          N3V_V(TP_VEL(tp),=,next_vel);
        }

      /* Save state before calling HeatMassUpdate */
      memcpy((char *) &(p_old), (char *) &(tp->state), sizeof(particle_state_t));

      /* Need to call HeatMassUpdate always since some DPM source terms are treated inside */
      HeatMassUpdate(tp, cphase_interaction);

      /* Consider Fluent heat transfer here since we have tp already set */
      if (DEM_HEAT_COUPLED_P(edem_coupling) && DEM_HEAT_TRANSFER_FLUENT_P(edem_coupling))
        {
          Material *m;
          /* HeatMassUpdate provides the new temperature and we can balance between old temperature P_T0 and new temperature P_T. */

          PP_DEM_HEAT_FLUX(pp) = PP_N(pp) * (TP_MASS(tp) * tp->Cp * (TP_T(tp) - TP_T0(tp))/solver_par.flow_time_step);
          if (edem_coupling.radiative_heat_option && dpm_par.radiation_p)
            PP_DEM_HEAT_FLUX(pp) -= PP_N(pp) * (tp->source.emiss * STEFAN_BOLTZMANN_CONSTANT);

          m = I->material;

          if (m->type == MATERIAL_PARTICLE_MIXTURE)
            {
              int ic;

              mixture_component_loop_i(m,ic)
                {
                  PP_COMPONENT_I(pp,ic) = TP_COMPONENT_I(tp,ic);
                }

              /* This works but particle size may need to be rescaled after mass change */
              /* TODO Add scaling factor based on mass change to mass is preserved on EDEM and mass fractions are correct */

              /* TEST Simple mass fraction rescaling to make volatiles mass lost correct in EDEM
                 EITHER replace this with full version for all evaporating species and then correct solid species mass fractions to match
                 OR scale particle to match total mass change.

              PP_COMPONENT_I(pp,0) = (TP_MASS(tp)/PP_MASS(pp))*TP_COMPONENT_I(tp,0); // TEST water liquid component rescaled by mass
              PP_COMPONENT_I(pp,1) = 1.0 - PP_COMPONENT_I(pp,0); // TEST wood = remainder
              */
            }
        }
      else
        {
          /* Restore the old state of the particle */
          memcpy((char *) &(tp->state), (char *) &(p_old), sizeof(particle_state_t));
        }

      /* Now we can deposit all source terms in Fluent's standard DPM way */
      if (fluid_source_terms)
        AddSources(tp);

      /* Ignore torque for the time being */ 

      // NOTE Torques will not just be multiplied by PP_N(pp) but will need to be multiplied PP_N()^2 to get correct rotations (MoI = K.R^2).
      ND_S(PP_DEM_TORQUE_X(pp),PP_DEM_TORQUE_Y(pp),PP_DEM_TORQUE_Z(pp),=,0.0);
    }
#endif /* !RP_HOST */
}


void compute_particle_forces_step_by_step(Tracked_Particle *tp, Injection *I, cxboolean fluid_source_terms)
{
#if !RP_HOST
  Particle *pp;
  real buoyancyForce[ND_ND];
  real dragForce[ND_ND];
  real relVel[ND_ND], relVelMag;
  Thread *ct, *vt;
  cell_t c;
  real factor;
  real Re, Cd;

  loop (pp, I->p)
    {
      c = PP_CELL(pp);
      vt = ct = PP_CELL_THREAD(pp);
      /* for euler/euler && DDPM we need the thread holding the velocity */
      if (mp_mfluid)
        vt = DPM_THREAD(ct, NULL);

#if (RampantReleaseMajor <= 17)
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, FALSE);
#endif

#if (RampantReleaseMajor == 18)
# if (RampantReleaseMinor >= 1)
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, TRUE);
# else
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, FALSE, TRUE);
# endif
#endif

#if (RampantReleaseMajor >= 19)
      init_tracked_particle(tp, pp, dpm_par.unsteady_tracking, FALSE, TRUE);
#endif


      /* Buoyancy force */
      if (M_gravity_p)
        {
          factor = - PP_N(pp) * C_R(c,vt) * DPM_VOLUME(PP_DIAM(pp)); /* Volume has been stored via diameter assuming spherical particles */
          NV_VS(buoyancyForce,=,M_gravity,*,factor);
        }
      else
        NV_S(buoyancyForce,=,0.0);

      ND_V(PP_DEM_FORCE_X(pp),PP_DEM_FORCE_Y(pp),PP_DEM_FORCE_Z(pp),=,buoyancyForce);

      /* Drag Force */

      NV_D(relVel,=,C_U(c,vt),C_V(c,vt),C_W(c,vt));
      NV_V(relVel,-=,PP_VEL(pp));

      relVelMag = NV_MAG(relVel);

      Re = (C_R(c,vt) * relVelMag * PP_DIAM(pp)) / C_MU_L(c,vt);

      if(Re <= 0.55)
        Cd = 24.0 / Re;
      else if(Re <= 987.0)
        Cd = 24.0 * (1.0 + 0.15 * pow(Re,0.687)) / Re;
      else
        Cd = 0.44;

      factor = PP_N(pp) * (0.5 * Cd * C_R(c,vt) * relVelMag * PP_PROJECTED_AREA(pp));

      NV_VS(dragForce,=,relVel,*,factor);

      ND_V(PP_DEM_FORCE_X(pp),PP_DEM_FORCE_Y(pp),PP_DEM_FORCE_Z(pp),+=,dragForce);

      /* Ignoring torque for the time being */
      /* Scaling by P_N may need to be SQR(PP_N) */
      ND_S(PP_DEM_TORQUE_X(pp),PP_DEM_TORQUE_Y(pp),PP_DEM_TORQUE_Z(pp),=,0.0);
    }
#endif /* !RP_HOST */
}

void compute_forces_on_particles(EDEM_Coupling edem_coupling, cxboolean fluid_source_terms)
{
#if !RP_HOST
  int i_proto;
  Injection *Ip;
#endif

  if (edem_coupling.num_particle_prototypes <= 0)
    {  
      Message0("\nWARNING: Particle data has not been read from EDEM yet.\n\n");
      return;
    }

  if(NULLP(edem_coupling.injections) || NULLP(edem_coupling.injection_names))
    {  
      Message0("\nWARNING: Injections for EDEM particles have not been set up.\n\n");
      return;
    }

#if !RP_HOST

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
    {
      Ip = edem_coupling.injections[i_proto];

      if(NNULLP(Ip->p))
        {
          Tracked_Particle tp_init = {0};
          Tracked_Particle *tp = &tp_init;

          alloc_tracked_particle_memory(tp);
          alloc_tp_pvars(tp, Ip);

          if (DEM_DRAG_FLUENT_P(edem_coupling) || DEM_HEAT_TRANSFER_FLUENT_P(edem_coupling))
            compute_particle_forces_using_Fluent(tp, Ip, fluid_source_terms);

          else
            compute_particle_forces_step_by_step(tp, Ip, fluid_source_terms);

          free_tp_pvars(tp);
          free_tracked_particle_memory(tp);
        }
    }

#endif /* !RP_HOST */
}
