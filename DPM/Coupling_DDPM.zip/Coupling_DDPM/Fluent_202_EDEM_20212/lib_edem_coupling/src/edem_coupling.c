#include "udf.h"
#include "AdaptorInterface.h"
#include "edem_coupling.h"
#include "scheme_functions.h"
#include "dpm_parallel.h"
#include "locate_particles.h"
#include "particle_prototype.h"
#include "custom_properties_user_reals.h"
#include "custom_properties_dpm_components.h"
#include "compute_particle_forces.h"
#include "compute_particle_heat_flux.h"
#include "compute_particle_properties.h"
#include "compute_particle_dpm_components.h"
#include "seem2c.h"
#include "dpm_dist.h"
#include "quaternion_macros.h"

#define LOCAL_IP_ADDRESS "127.0.0.1"

EDEM_Coupling edem_coupling;

#define NULL_PROPERTY_INDEX -1

#define DEFAULT_PARTICLE_TEMP 300.0


/* EDEM expects an array of heat flux pairs : (Particle_to_Particle, Fluid_To_Particle) */
enum
  {
    PARTICLE_TO_PARTICLE = 0,
    FLUID_TO_PARTICLE,
    N_HEAT_FLUX_ELEMENTS
  };

#if RP_NODE //  PRF_GBOR1 new name for PRF_GLOR1 since Fluent 2021
# ifndef PRF_GBOR1
#  define PRF_GBOR1 PRF_GLOR1
# endif
#endif

#if !RP_NODE
static int get_injection_id_from_list(Injection *I, Injection *ilist)
{
  int ii=0;
  Injection *II;

  loop(II, ilist)
    {
      if (II==I)
        return ii;
      ii++;
    }

  if (I == Get_pdft_injection())
    return -1;

  return -2;
}
#endif


void init_edem_coupling_injections()
{
  edem_coupling.num_particles = EDEM_COUPLING_NUM_PARTICLES_INIT;

  if (edem_coupling.num_particle_prototypes && NNULLP(edem_coupling.injection_names))
    {
      int i_proto;
      Injection *I;

      for (i_proto=0;i_proto<edem_coupling.num_particle_prototypes;++i_proto)
        {
          if(NNULLP(edem_coupling.injection_names[i_proto]))
            {
              I = Pick_Injection(edem_coupling.injection_names[i_proto]);

              if(NNULLP(I))
                {
                  delete_injection(I);
                  CX_Free(edem_coupling.injection_names[i_proto]);
                }
            }
        }
    }

  CX_Free(edem_coupling.injections);
  edem_coupling.injections = NULL;

  CX_Free(edem_coupling.injection_names);
  edem_coupling.injection_names = NULL;

  CX_Free(edem_coupling.injection_ids);
  edem_coupling.injection_ids = NULL;
}



char *get_particle_prototype_name(int i_proto)
{
  if((i_proto < 0) || (i_proto >= edem_coupling.num_particle_prototypes))
    return (char *)NULL;

  return (edem_coupling.particle_prototypes + i_proto)->sPrototypeName;
}

int check_edem_coupling_injections()
{
  int injections_found;
#if PARALLEL
  int injections_found_nodes;
#endif

  injections_found = 0;

  if (NNULLP(edem_coupling.injections) && NNULLP(edem_coupling.injection_names) && NNULLP(edem_coupling.injection_ids))
    {
      int i_proto;

      for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
        {
          /* We need to pick the injections all the time since it might have been deleted in the meantime by accident */
          edem_coupling.injections[i_proto] = Pick_Injection(edem_coupling.injection_names[i_proto]);
 
          if(NNULLP(edem_coupling.injections[i_proto]))
            {
              ++injections_found;
#if !RP_NODE
              edem_coupling.injection_ids[i_proto] = get_injection_id_from_list(edem_coupling.injections[i_proto], Get_dpm_injections());
#endif
              free_injection_particles(edem_coupling.injections[i_proto]);
            }
        }
    }

#if PARALLEL
# if RP_NODE
  injections_found_nodes = PRF_GILOW1(injections_found);
# endif

  node_to_host_int_1(injections_found_nodes);

#if RP_HOST
  if ((injections_found_nodes != injections_found)||(injections_found != edem_coupling.num_particle_prototypes))
    injections_found = 0;
#endif
  host_to_node_int_1(injections_found);

  if(injections_found)
    host_to_node_int(edem_coupling.injection_ids, edem_coupling.num_particle_prototypes);
#endif

  return injections_found;
}

int create_edem_coupling_injections()
{
  int i_proto;
  int num_particle_types;

#if !RP_NODE
  char *edem_injection_name;
#endif

  num_particle_types = edem_coupling.num_particle_prototypes;

  if (num_particle_types <= 0)
    return 0;

  init_edem_coupling_injections(); /* Initialise edem coupling injection data before rebuilding it */

  /* Create injections */

  edem_coupling.injections = CX_Malloc(num_particle_types * sizeof(Injection *));
  edem_coupling.injection_ids = CX_Malloc(num_particle_types * sizeof(int));
  edem_coupling.injection_names = CX_Malloc(num_particle_types * sizeof(char *));


#if !RP_NODE
  edem_injection_name = (char *)RP_Get_String("edem/injection-name");
#endif

  for(i_proto=0;i_proto<num_particle_types;i_proto++)
    {
      edem_coupling.injection_names[i_proto] = CX_Malloc(DPM_NAME_LENGTH * sizeof(char));

#if !RP_NODE
      if(num_particle_types > 1)
        {
          char *particletypename;
          char schemeparticletypename[MAX_DE_TYPENAME_SZ];

          particletypename = get_particle_prototype_name(i_proto);

          if(NNULLP(particletypename))
            {
              strncpy_scm(schemeparticletypename, particletypename, MAX_DE_TYPENAME_SZ);
              snprintf(edem_coupling.injection_names[i_proto], DPM_NAME_LENGTH, "%s-%s", edem_injection_name, schemeparticletypename);
            }
          else
            snprintf(edem_coupling.injection_names[i_proto], DPM_NAME_LENGTH, "%s-%d", edem_injection_name, i_proto);
        }
      else  /* Base name used without ending "-0" to match old naming */
        snprintf(edem_coupling.injection_names[i_proto], DPM_NAME_LENGTH, "%s", edem_injection_name);
#endif

      host_to_node_string(edem_coupling.injection_names[i_proto], DPM_NAME_LENGTH);
    }

  return check_edem_coupling_injections();
}

void free_edem_coupling_particle_prototypes()
{
  if(NNULLP(edem_coupling.particle_prototypes))
    {
      int i_proto;
      ParticlePrototype *pp;

      for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
        {   
          pp = edem_coupling.particle_prototypes + i_proto;

          free_ParticlePrototype(pp);
        }

      CX_Free(edem_coupling.particle_prototypes);

      edem_coupling.num_particle_prototypes = 0;
      edem_coupling.particle_prototypes = NULL;
    }
}

int create_edem_coupling_particle_prototypes(int num_particle_types)
{
  int i_proto;
  ParticlePrototype *pp;

#if !RP_NODE
  int n_cross_sections;
  int n_cross_section_samples;
  int n_surface_area_samples;
#endif

  /* Create Particle Prototypes from scratch */

  free_edem_coupling_particle_prototypes();

  edem_coupling.particle_prototypes = CX_Malloc(num_particle_types*sizeof(ParticlePrototype));
  edem_coupling.num_particle_prototypes = num_particle_types;

#if !RP_NODE
  n_cross_sections = RP_Get_Integer("edem/n-cross-sections");
  n_cross_section_samples = RP_Get_Integer("edem/n-cross-section-samples");
  n_surface_area_samples = RP_Get_Integer("edem/n-surface-area-samples");
#endif

  for(i_proto=0;i_proto<num_particle_types;i_proto++)
    {   
      pp = edem_coupling.particle_prototypes + i_proto; 
      init_ParticlePrototype(pp); /* Initialise values to 0 & pointers to NULL to avoid seg fault in ADAPTOR_getParticlePrototype */

#if !RP_NODE
      ADAPTOR_getParticlePrototype(i_proto, pp);

      // TEST  Message("%d particles of type '%s' (%d)\n", ADAPTOR_getNumParticles(i_proto), pp->sPrototypeName, i_proto);

      setParticlePrototypeSurfaceArea(pp, n_surface_area_samples);
      setParticlePrototypeSphericity(pp);

      setParticlePrototypeCrossSectionAreas(pp, n_cross_sections, n_cross_section_samples);
#endif

#if PARALLEL
      host_to_node_particle_prototype(pp);
#endif
    }

  return num_particle_types;
}


#if !RP_NODE
cxboolean register_heat_properties()
{
  /* Properties to register for the heat transfer: temperature and heat flux */

  int tempNumElements = 1;	                        /* Define number of elements to the custom property */
  int tempDataType = CM_PROP_DATA_TYPE_DOUBLE;	    /* Define the data type as a double using EDEMs index system */
  int tempUnitType = CM_PROP_UNIT_TYPE_TEMPERATURE; /* Define the unit type as temperature using EDEMs index system */
  double initialTemp = DEFAULT_PARTICLE_TEMP;	    /* Define the starting temperature */

  /*
   * Heat flux is a special custom property. It has 2 elements:
   * The first element is used by EDEM particle contacts for heat flux.
   * The second element is used by the CFD package for fluid to particle
   * heat flux. Even though the first entry will not be used here we are
   * declaring the property here and therefore must declare both entries for
   * EDEM to work correctly
   */

  int heatFluxNumElements = 2;                        /* Define number of elements to the custom property */
  int heatFluxDataType = CM_PROP_DATA_TYPE_DOUBLE;    /* Define the data type as a double using EDEMs index system */
  int heatFluxUnitType = CM_PROP_UNIT_TYPE_HEAT_FLUX; /* Define the unit type as heat flux using EDEMs index system */
  double initialHeatFlux = 0.0;                       /* Define the starting heat flux */


  cxboolean heat_registered;
  int temperature_property_index;
  int heat_flux_property_index;

  /* Register temperature AND heat flux */

  heat_registered = ADAPTOR_registerCustomProperty("Temperature", tempNumElements, tempDataType, tempUnitType, initialTemp, &temperature_property_index);

  if(heat_registered)
    heat_registered = ADAPTOR_registerCustomProperty("Heat Flux", heatFluxNumElements, heatFluxDataType, heatFluxUnitType, initialHeatFlux, &heat_flux_property_index);

  edem_coupling.heat_registered = heat_registered;
  
  if(heat_registered)
    {
      edem_coupling.use_Fluent_heat_transfer = TRUE;
      edem_coupling.temperature_property_index = temperature_property_index;
      edem_coupling.heat_flux_property_index = heat_flux_property_index;
    }

  return heat_registered;
}

#endif // !RP_NODE


void set_particle_mass_density(Particle *pp)
{
  Tracked_Particle tp_init = {0};  // Use a single Tracked_Particle to hold each Particle's data

  alloc_tracked_particle_memory(&tp_init);
  alloc_tp_pvars(&tp_init, PP_INJECTION(pp));

  copy_p_to_tp(&tp_init, pp);

  PP_RHO(pp) = DPM_Get_Density(&tp_init, PP_T(pp));
  PP_MASS(pp) = PP_RHO(pp) * DPM_VOLUME(PP_DIAM(pp));

  free_tp_pvars(&tp_init);
  free_tracked_particle_memory(&tp_init);
}

int add_EDEM_particle_to_Injection(Injection *I, int inj_id, DiscreteElement *particle,
                                   int particle_index, double temperature,
                                   int num_custom_properties, double *particle_properties,
                                   int num_dpm_components, double *particle_components,
                                   double scale_up_factor)
{
  Particle *p_new;
  int i_prop, i_comp, ic;


  p_new = new_particle(I, FALSE);

  if(NULLP(p_new))
    return -1;

  PP_ID(p_new) = get_next_part_id();

  PP_INJECTION(p_new) = I;
  p_new->I_id = inj_id;

  /* Set all properties on particle that are available. 
     the particle ID cannot be easily set but the stream index can be set to i_part */

  PP_DEM_PARTICLE_INDEX(p_new) = particle_index;
 
  NV_V(PP_POS(p_new),=,particle->vPos);           /* Position */
  NV_V(PP_VEL(p_new),=,particle->vVelocity);      /* Velocity */
  /*  NV_V(PP_OMEGA(p_new),=,particle->vAngVelocity);  Angular Velocity */

  // TEST  Message("\n edem_coupling.dpm_component_names %p\n",edem_coupling.dpm_component_names);

  /* Note that currently (2019) mass is hardwired in EDEM. */
  /* Some mechanism to change the mass and volume depending on components may be added on the EDEM side. */

  /* DPM material components */
  for (i_comp=0;i_comp<num_dpm_components;i_comp++)
    {
      // TEST  Message("\nedem_coupling.dpm_component_names[%d] %s\n ",i_comp, edem_coupling.dpm_component_names[i_comp]);

      ic = get_particle_component_index_from_name(I, edem_coupling.dpm_component_names[i_comp]);

      // TEST  if(ic != DPM_NULL_SPECIES_INDEX) 
      // TEST    Message("edem_coupling.dpm_component_names[%d] %s ic = %d\n ",i_comp,edem_coupling.dpm_component_names[i_comp],ic);

      // If the particle has this component, set it from the EDEM particle's value
      if(ic != DPM_NULL_SPECIES_INDEX)
        PP_COMPONENT_I(p_new, ic) = (real)particle_components[i_comp];
    }

  PP_LMF(p_new) = 0.0; /* PP_LMF is liquid mass fraction used in droplet and wet combustion DPM models. */

  PP_T(p_new) = (real)temperature;

  /* Spherical particles assumed in Fluent. Scaled down from DEM particle scaling */

  PP_DIAM(p_new) = cbrt(6.0*particle->nVolume/M_PI)/scale_up_factor;

  set_particle_mass_density(p_new); // Must be called after temperature, material properties, components and diameter have been set.


  /* Fill remaining information needed for particle flight & HeatMassUpdate calcs. */

  p_new->n_steps = 0;

  PP_N(p_new) = (real)CUB(scale_up_factor); /* This is scaled so total mass of scaled-up particles in EDEM is added to Fluent */
  p_new->next_time_step = solver_par.flow_time_step;

  PP_TIME(p_new) = solver_par.flow_time;
  memcpy((char *) &(p_new->init_state),
         (char *) &(p_new->state), sizeof(particle_state_t));
  
  PP_FLOW_RATE(p_new) = PP_N(p_new) * PP_MASS(p_new) / solver_par.flow_time_step;
  p_new->time_of_birth = 0.0;
  
  PP_ON_WALL(p_new) = FALSE;
  PP_FILM_FACE(p_new) = NULL_FACE;
  PP_FILM_THREAD_ID(p_new) = NULL_INDEX;


  /* User real based values */

  Init_DPM_Scalars(p_new);

  if (dpm_par.n_user_reals > 0)
    Init_Unsteady_User(p_new);


  PP_DEM_SCALE(p_new) = particle->nScale/scale_up_factor;
  QN_Q(PP_DEM_ORIENT(p_new),=,particle->vOrientation);


  /* Custom properties */
  for (i_prop=0;i_prop<num_custom_properties;i_prop++)
    PP_DEM_CUSTOM_PROPERTY_I(p_new, i_prop) = (real)particle_properties[i_prop];


  if (dpm_par.n_cbk > 0)
    Init_DPM_cbk(p_new);

  /* Need to have this allocated for cas/dat file writing of particle information */
  if (NULLP(p_new->unsteady_coupled)) 
    Init_Unsteady_Coupled(p_new);

  alloc_pvars(p_new);

  append_particle_to_list(p_new, &(I->p), I);

  I->n_particles++;

  return PP_ID(p_new);
}


int get_edem_coupling_particles(int num_particles)
{
  int num_located_particles;
  int i_proto;

#if !RP_HOST
  int num_particles_injection;
#endif

#if !RP_NODE
  int i_part;
  int i_prop;
  DiscreteElement edem_particle;
  double particle_temperature;
  double *particle_properties;
  double *particle_components;
  double particle_component_sum;

  /* Get the particle data for all particles. */

  Message("\nGetting particle data from EDEM...\n");

  ADAPTOR_getParticleData(); /* All particle data transferred into a hidden CFluentParticleData object */


  if(DEM_HEAT_COUPLED_P(edem_coupling) && !DEM_HEAT_REGISTERED_P(edem_coupling))
    {
      if (register_heat_properties())
        Message("  Heat flux properties registered with EDEM.\n");
      else
        Message("\n  WARNING: Unable to register heat flux properties.\n");
    }

  if(DEM_HEAT_COUPLED_P(edem_coupling) && DEM_HEAT_REGISTERED_P(edem_coupling))
    ADAPTOR_updateValuesForProperty(num_particles, edem_coupling.temperature_property_index);
   
#endif // !RP_NODE


  // Register all values that need a custom property on an EDEM particle to be defined.

  register_custom_properties();
  register_dpm_components();


#if !RP_NODE
  if(edem_coupling.num_custom_properties > 0)
    {
      for (i_prop=0;i_prop<edem_coupling.num_custom_properties;i_prop++)
        ADAPTOR_updateValuesForProperty(num_particles, edem_coupling.property_indices[i_prop]);

      particle_properties = CX_Malloc(edem_coupling.num_custom_properties * sizeof(double));
    }
  else
    particle_properties = NULL;



  if(DEM_DPM_COMPONENTS_P(edem_coupling))
    {
      for (i_prop=0;i_prop<edem_coupling.num_dpm_components;i_prop++)
        ADAPTOR_updateValuesForProperty(num_particles, edem_coupling.dpm_component_indices[i_prop]);

      particle_components = CX_Malloc(edem_coupling.num_dpm_components * sizeof(double));
    }
  else
    particle_components = NULL;


  for(i_part=0;i_part<num_particles;i_part++)
    {
      ADAPTOR_getParticle(i_part, &edem_particle);

      if(DEM_HEAT_COUPLED_P(edem_coupling) && DEM_HEAT_REGISTERED_P(edem_coupling))
        particle_temperature = ADAPTOR_getScalarProperty(edem_coupling.temperature_property_index, i_part);
      else
        particle_temperature = DEFAULT_PARTICLE_TEMP;

     /* Set custom properties on the particles */

      if (NNULLP(particle_properties))
        for (i_prop=0;i_prop<edem_coupling.num_custom_properties;i_prop++)
          particle_properties[i_prop] = ADAPTOR_getScalarProperty(edem_coupling.property_indices[i_prop], i_part);


      if (NNULLP(particle_components))
        {
          particle_component_sum = 0.0;

          for (i_prop=0;i_prop<edem_coupling.num_dpm_components;i_prop++)
            {
              particle_components[i_prop] = ADAPTOR_getScalarProperty(edem_coupling.dpm_component_indices[i_prop], i_part);

              if(particle_components[i_prop] > 0.0) // Components must be positive
                particle_component_sum += particle_components[i_prop];
              else
                particle_components[i_prop] = 0.0;
            }


          /* Ensure components sum to 1.0 */
          if(particle_component_sum > DPM_SMALL)
            {
              for (i_prop=0;i_prop<edem_coupling.num_dpm_components;i_prop++)
                {
                  particle_components[i_prop] /= particle_component_sum;
                }
            }
          else
            {
              // EDEM Particle's properties have just been initialised to 0.0
              // So set them to the Fluent Injection setup values

              Injection *I;
              int ic, i_comp;


              I = edem_coupling.injections[edem_particle.typeIndex];

              // Message("TEST  I[%d] = %p\n", edem_particle.typeIndex, edem_coupling.injections[edem_particle.typeIndex]);

              for (i_comp=0;i_comp<edem_coupling.num_dpm_components;i_comp++)
                {
                  ic = get_particle_component_index_from_name(I, edem_coupling.dpm_component_names[i_comp]);

                  // Message("TEST  ic = %d  I->component.massfr = %p\n", ic,  I->component.massfr);

                  if(ic != DPM_NULL_SPECIES_INDEX)
                    particle_components[i_comp] = I->component.massfr[ic];
                  else
                    particle_components[i_comp] = 0.0;
                }
            }
        }

      //  Message("TEST  Particle added to I[%d] = %s\n", edem_particle.typeIndex, edem_coupling.injections[edem_particle.typeIndex]->name);

      add_EDEM_particle_to_Injection(edem_coupling.injections[edem_particle.typeIndex],
                                     edem_coupling.injection_ids[edem_particle.typeIndex],
                                     &edem_particle, i_part, particle_temperature,
                                     edem_coupling.num_custom_properties, particle_properties,
                                     edem_coupling.num_dpm_components, particle_components,
                                     edem_coupling.scale_up_factor);
    }

  CX_Free(particle_properties);


#endif /* !RP_NODE */

  num_located_particles = 0;

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
    {
#if !RP_NODE
      reset_injection_nparticles_and_tail(edem_coupling.injections[i_proto]);
#endif /* !RP_NODE */

      Host_to_Node_Injection_Particles(edem_coupling.injections[i_proto]);

#if !RP_HOST
      num_particles_injection = PRF_GISUM1(edem_coupling.injections[i_proto]->n_particles);
      num_located_particles += num_particles_injection;

      Message0("  %d particles in injection '%s'.\n", num_particles_injection, edem_coupling.injection_names[i_proto]);
#endif
    }

  node_to_host_int_1(num_located_particles);

  return num_particles - num_located_particles; /* Number of particles that couldn't be located */
}

void init_edem_coupling()
{
  edem_coupling.coupled = 0;
  edem_coupling.time = 0.0;

  init_edem_coupling_injections();

  edem_coupling.drag_law_option = 0;
  edem_coupling.use_Fluent_drag = TRUE;
  edem_coupling.scale_up_factor = 1.0;

  edem_coupling.convective_heat_option = 0;
  edem_coupling.radiative_heat_option = 0;
  edem_coupling.emissivity = 1.0;
  edem_coupling.use_Fluent_heat_transfer = TRUE;

  edem_coupling.heat_registered = FALSE;
  edem_coupling.temperature_property_index = NULL_PROPERTY_INDEX;
  edem_coupling.heat_flux_property_index = NULL_PROPERTY_INDEX;

  edem_coupling.num_custom_properties = 0;
  edem_coupling.property_indices = NULL;
  edem_coupling.property_names = NULL;

  edem_coupling.num_dpm_components = 0;
  edem_coupling.dpm_component_indices = NULL;
  edem_coupling.dpm_component_names = NULL;
}

void update_edem_coupling_settings(cxboolean update_on_node)
{
#if !RP_NODE
  edem_coupling.convective_heat_option = RP_Get_Integer("edem/convective-heat-option");
  edem_coupling.radiative_heat_option = RP_Get_Integer("edem/radiative-heat-option");
  edem_coupling.scale_up_factor = RP_Get_Double("edem/scale-up-factor");
  edem_coupling.use_Fluent_drag = RP_Get_Boolean("edem/use-fluent-drag?");
  edem_coupling.use_Fluent_heat_transfer = RP_Get_Boolean("edem/use-fluent-heat-transfer?");
#endif

#if PARALLEL
  if(update_on_node)
    {
      host_to_node_int_2(edem_coupling.convective_heat_option, edem_coupling.radiative_heat_option);
      host_to_node_boolean_1(edem_coupling.use_Fluent_drag);
      host_to_node_boolean_1(edem_coupling.use_Fluent_heat_transfer);
      host_to_node_double_1(edem_coupling.scale_up_factor);
    }
#endif
}

int get_n_req_dpm_user_reals()
{
  update_edem_coupling_settings(FALSE); /* Don't update on Nodes as called from Scheme */

  if(DEM_HEAT_COUPLED_P(edem_coupling) || edem_coupling.num_custom_properties)
    return DEM_N_P_REALS + edem_coupling.num_custom_properties; // Assume heat likely to be used if custom properties used
  else
    return DEM_N_P_REALS_NO_HEAT_FLUX;
}



//DEFINE_ON_DEMAND(connect_edem_coupling)
void connect_edem_coupling()
{
  int coupling_success;
  int success;

  double time;

#if !RP_NODE
  char *edem_host_ip_address;
#endif /* !RP_NODE */

  init_edem_coupling();

  if(!rp_unsteady)
    {
      Message0("\n\nWARNING: Cannot connect to EDEM from the steady Fluent solver.\n");

      edem_coupling.coupled = 0;
      return;
    }


#if !RP_NODE

  Message("\n\nInitialising EDEM-Fluent Coupling. Please wait...\n");

  if (RP_Get_Boolean("edem/remote-host?"))
    {
      edem_host_ip_address = (char *)RP_Get_String("edem/host-ip-address");

      if(strlen(edem_host_ip_address) == 0)
        edem_host_ip_address = LOCAL_IP_ADDRESS;
    }
  else
    edem_host_ip_address = LOCAL_IP_ADDRESS;

      
  ADAPTOR_init_connectEDEMCoupling_Address(&coupling_success, edem_host_ip_address);

  if(coupling_success)
    {
      Message("  Connected to EDEM Process");
      if(strncmp(edem_host_ip_address, LOCAL_IP_ADDRESS, 5)) /* Does not start with "127.0" */
        Message(" on host %s", edem_host_ip_address);

      Message(".\n");
    }
  else
    {
      Message("\n  ERROR: Cannot connect to EDEM.\n");
      Message("           Check that EDEM Coupling Server has been started\n\n");

      ADAPTOR_disconnectEDEMCoupling(&success);
    }


#endif /* !RP_NODE */

  host_to_node_int_1(coupling_success);

  edem_coupling.coupled = coupling_success;

  if(!coupling_success) return;



#if !RP_NODE

  ADAPTOR_getEDEMTime(&time, &success);

  if(success)
    {
      Message("  Current Fluent time is %e\n", RP_Get_Real("flow-time"));
      Message("  Current EDEM time is %e\n", time);
    }
  else
      Message("\n\n  ERROR: Cannot get EDEM time.\n\n");

#endif /* !RP_NODE */

  host_to_node_int_1(success);
  host_to_node_double_1(time);

  if(success)
    {
      edem_coupling.time = time;
      RP_Set_Real("edem/time", time);
    }
}


//DEFINE_ON_DEMAND(get_solution_from_edem)
void get_solution_from_edem()
{
  int num_particles;
  int num_particle_types;
  int num_lost_particles;


  Message0("\nGetting EDEM solution data...\n");

  if(!edem_coupling.coupled)
    {
      Message0("\n\n  WARNING: EDEM not connected to Fluent. Getting data failed\n\n");
      return;
    }


  DPM_Init_Oct_Tree_Search();

#if !RP_NODE

  num_particle_types = ADAPTOR_getParticlePrototypeData();

  num_particles = ADAPTOR_getTotalNumParticles();

#endif

#if PARALLEL
  host_to_node_int_2(num_particle_types, num_particles);
#endif

  if(num_particle_types <= 0)
    {
      Message0("\n\nWARNING: No particle types found.\n");
      return;
    }


  if(num_particles > 0)
    {
      Message0("%d particle type%s sent.\n", num_particle_types, (num_particle_types==1)?"":"s");

      /* EDEM has particles so check injections as they may have been deleted between calls. */
      if(edem_coupling.num_particle_prototypes != num_particle_types)
          create_edem_coupling_particle_prototypes(num_particle_types);

      if(check_edem_coupling_injections() != num_particle_types)
        {
          init_edem_coupling_injections();
          create_edem_coupling_injections();

          if(check_edem_coupling_injections() != num_particle_types) /* Creation of injections failed */
            {
              Message0("\n  WARNING: %d Injections for EDEM particles not set up.\n\n", num_particle_types);

              init_edem_coupling_injections();
              return;
            }
        }

      Message0("  Getting %d particles from EDEM solution.\n", num_particles);
      edem_coupling.num_particles = num_particles;
    }
  else
    {
      Message0("  No particles found in EDEM solution.\n");
      edem_coupling.num_particles = 0;

      return;
    }


  /* Get other EDEM Coupling settings */
  update_edem_coupling_settings(TRUE);

  num_lost_particles = get_edem_coupling_particles(num_particles);

  if(num_lost_particles)
    Message0("  %d particles could not be located in Fluent.\n", num_lost_particles);

  Message0("Done.\n");
}


void send_particle_data_to_edem()
{
  int n_req_dpm_user_reals;
  int i_proto;

#if PARALLEL
  cxboolean node_injection_valid;
  int valid_injection_count;
  int node_injection_n_particles;
#endif

#if !RP_NODE
  double *forces, *torques, *heat_fluxes;
  double **custom_property_data;
  double **dpm_component_data;
  double max_heat_flux, min_heat_flux, tot_heat_flux;
  double *offset_force, *offset_torque, *offset_heat_flux;
  Particle *p;
  int num_particles_check;
#endif /* !RP_NODE */

  Message0("\n  Sending forces to EDEM...\n");

  if(!edem_coupling.coupled)
    {
      Message0("\n\n  WARNING: EDEM not connected to Fluent. Getting data failed\n\n");
      return;
    }


  if(edem_coupling.num_particles <= 0)
    {
      Message0("    No EDEM particles found in Fluent.\n");
      return;
    }
 

  if(NULLP(edem_coupling.injections) || NULLP(edem_coupling.injection_names))
    {
      Message0("\n  WARNING: Injections for EDEM particles have not been set up.\n\n");
      return;
    }


  n_req_dpm_user_reals = get_n_req_dpm_user_reals();

  if(dpm_par.n_user_reals < n_req_dpm_user_reals)
    {
      Message0("\n  WARNING: Need to setup at least %d DPM User Scalars.\n\n", n_req_dpm_user_reals);

      return;
    }


#if PARALLEL
  valid_injection_count = 0;

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;++i_proto)
    {
#if RP_NODE
      node_injection_valid = PRF_GBOR1(NNULLP(edem_coupling.injections[i_proto]->p));
      node_injection_n_particles = PRF_GISUM1(edem_coupling.injections[i_proto]->n_particles);
#endif

      node_to_host_boolean_1(node_injection_valid);
      node_to_host_int_1(node_injection_n_particles);


      if (node_injection_n_particles > 0)
        {
          if (node_injection_valid)
            {
              /* Get the Fluent particles from the compute nodes to the host. */
              Node_to_Host_Injection_Particles(edem_coupling.injections[i_proto]); 
              valid_injection_count++;
            }
          else
            {
              Message0("\n  WARNING: EDEM particles on Injection '%s' are not allocated on the nodes.\n\n", edem_coupling.injection_names[i_proto]);
            }
        }
    }

  if (valid_injection_count == 0)
    {
      Message0("\n  WARNING: No EDEM particles on any Injections found on the nodes.\n\n");
      return;
    }
#endif


#if !RP_NODE
  forces = CX_Malloc(sizeof(double) * edem_coupling.num_particles * ND_ND);
  torques = CX_Malloc(sizeof(double) * edem_coupling.num_particles * ND_ND);

  /* Initialise forces torques as not all particles will be in the injection as some may be outside Fluent mesh */
  memset(forces, 0, sizeof(double) * edem_coupling.num_particles * ND_ND);
  memset(torques, 0, sizeof(double) * edem_coupling.num_particles * ND_ND);

  if(DEM_HEAT_COUPLED_P(edem_coupling))
    {
      heat_fluxes = CX_Malloc(sizeof(double) * edem_coupling.num_particles * N_HEAT_FLUX_ELEMENTS);

      /* Initialise heat fluxes as not all particles will be in the injection as some may be outside Fluent mesh */
      memset(heat_fluxes, 0, sizeof(double) * edem_coupling.num_particles * N_HEAT_FLUX_ELEMENTS);

    }
  else
    heat_fluxes = NULL;

  if(DEM_CUSTOM_PROPERTIES_P(edem_coupling))
    {
      int ip;

      custom_property_data = CX_Malloc(sizeof(double *) * edem_coupling.num_custom_properties);

      for(ip=0;ip<edem_coupling.num_custom_properties;ip++)
        {
          custom_property_data[ip] = CX_Malloc(sizeof(double) * edem_coupling.num_particles);

          /* Initialise property data as not all particles will be in the injection as some may be outside Fluent mesh */
          memset(custom_property_data[ip], 0, sizeof(double) * edem_coupling.num_particles);
        }
    }
  else
    { 
      if(edem_coupling.num_custom_properties > 0)
        {
          Message("\n\n  WARNING: Number of DPM User Scalars needs to be at least %d (%d %d).\n",
                  DEM_N_P_REALS_PROPERTIES(edem_coupling), get_n_req_dpm_user_reals(), dpm_par.n_user_reals);      
          Message("         Number of registered properties = %d.\n\n", edem_coupling.num_custom_properties);
        }
  
      custom_property_data = NULL;
    }


  if(DEM_DPM_COMPONENTS_P(edem_coupling))
    {
      int i_comp;

      dpm_component_data = CX_Malloc(sizeof(double *) * edem_coupling.num_dpm_components);

      for(i_comp=0;i_comp<edem_coupling.num_dpm_components;i_comp++)
        {
          dpm_component_data[i_comp] = CX_Malloc(sizeof(double) * edem_coupling.num_particles);

          /* Initialise component data as not all particles will be in the injection as some may be outside Fluent mesh */
          memset(dpm_component_data[i_comp], 0, sizeof(double) * edem_coupling.num_particles);
        }
    }
  else
    { 
      // No multicomponent injections defined
  
      dpm_component_data = NULL;
    }


  /* Set all forces and torques on particles in injection */

  max_heat_flux = -FLT_MAX; //-DBL_MAX;
  min_heat_flux = FLT_MAX;  //DBL_MAX;
  tot_heat_flux = 0.0;

  num_particles_check = 0;

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;++i_proto)
    {
      Injection *I;


      if ((edem_coupling.injections[i_proto]->n_particles > 0) && NNULLP(edem_coupling.injections[i_proto]->p))
        {
          I = edem_coupling.injections[i_proto];

          loop (p, I->p)
            {
              ++num_particles_check;

              offset_force = forces + (ND_ND * PP_DEM_PARTICLE_INDEX(p));
              NV_D(offset_force,=,PP_DEM_FORCE_X(p),PP_DEM_FORCE_Y(p),PP_DEM_FORCE_Z(p));

              offset_torque = torques + (ND_ND * PP_DEM_PARTICLE_INDEX(p));
              NV_D(offset_torque,=,PP_DEM_TORQUE_X(p),PP_DEM_TORQUE_Y(p),PP_DEM_TORQUE_Z(p));

              if(DEM_HEAT_COUPLED_P(edem_coupling))
                {
                  offset_heat_flux = heat_fluxes + (N_HEAT_FLUX_ELEMENTS * PP_DEM_PARTICLE_INDEX(p));
                  offset_heat_flux[FLUID_TO_PARTICLE] = PP_DEM_HEAT_FLUX(p); /* Only fluid to particle term set */
                  max_heat_flux = MAX(max_heat_flux, PP_DEM_HEAT_FLUX(p));
                  min_heat_flux = MIN(min_heat_flux, PP_DEM_HEAT_FLUX(p));
                  tot_heat_flux += PP_DEM_HEAT_FLUX(p);
                }

              if(DEM_CUSTOM_PROPERTIES_P(edem_coupling))
                {
                  int i_prop;

                  for(i_prop=0;i_prop<edem_coupling.num_custom_properties;i_prop++)
                    {
                      // NOTE setting properties from first num_custom_properties DPM scalars on particle but may need
                      // a edem_coupling.fluent_property_indices lookup if scalars used out of sequence.
                      custom_property_data[i_prop][PP_DEM_PARTICLE_INDEX(p)] = PP_DEM_CUSTOM_PROPERTY_I(p,i_prop);
                    }
                }

              if(DEM_DPM_COMPONENTS_P(edem_coupling))
                {
                  int i_comp, ic;

                  for(i_comp=0;i_comp<edem_coupling.num_dpm_components;i_comp++)
                    {
                      ic = get_particle_component_index_from_name(I, edem_coupling.dpm_component_names[i_comp]);

                      if(ic != DPM_NULL_SPECIES_INDEX)
                        dpm_component_data[i_comp][PP_DEM_PARTICLE_INDEX(p)] = PP_COMPONENT_I(p, ic);
                      else
                        dpm_component_data[i_comp][PP_DEM_PARTICLE_INDEX(p)] = 0.0;
                    }
                }
            }
        }
    }
 
  Message("  Setting forces and torques on %d (of %d) EDEM particles... \n", num_particles_check, edem_coupling.num_particles);

  ADAPTOR_setDragForceAndTorque(edem_coupling.num_particles, forces, torques);

  Message("  Done.\n");

  if(DEM_HEAT_COUPLED_P(edem_coupling) && DEM_HEAT_REGISTERED_P(edem_coupling) && (num_particles_check > 0))
    {
      Message("  Setting heat fluxes on %d (of %d) EDEM particles... ", num_particles_check, edem_coupling.num_particles);

      Message("\n    Total Particle Heat flux : %lfW\n", tot_heat_flux);
      Message("    Particle Heat fluxes in range (%lf[W] , %lf[W])\n", min_heat_flux, max_heat_flux);

      ADAPTOR_setValuesForProperty(edem_coupling.num_particles, edem_coupling.heat_flux_property_index, heat_fluxes);

      Message("  Done.\n");
    }

  if(NNULLP(custom_property_data))
    {
      int ip;

      for(ip=0;ip<edem_coupling.num_custom_properties;ip++)
        {
          Message("  Setting property %s (%d) on %d (of %d) EDEM particles... ", edem_coupling.property_names[ip], DEM_PROPERTY_INDEX(edem_coupling,ip), num_particles_check, edem_coupling.num_particles);

          ADAPTOR_setValuesForProperty(edem_coupling.num_particles, DEM_PROPERTY_INDEX(edem_coupling,ip), custom_property_data[ip]);

          Message("Done.\n");
        }
    }

  if(NNULLP(dpm_component_data))
    {
      int ic;

      for(ic=0;ic<edem_coupling.num_dpm_components;ic++)
        {
          Message("  Setting property %s (%d) on %d (of %d) EDEM particles... ", edem_coupling.dpm_component_names[ic], DEM_DPM_COMPONENT_INDEX(edem_coupling,ic), num_particles_check, edem_coupling.num_particles);

          ADAPTOR_setValuesForProperty(edem_coupling.num_particles, DEM_DPM_COMPONENT_INDEX(edem_coupling,ic), dpm_component_data[ic]);

          Message("Done.\n");
        }
    }

  // Free all data arrays

  CX_Free(forces);
  CX_Free(torques);
  

  if(NNULLP(heat_fluxes))
    CX_Free(heat_fluxes);


  if(NNULLP(custom_property_data))
    {
      int ip;

      for(ip=0;ip<edem_coupling.num_custom_properties;ip++)
        {
          CX_Free(custom_property_data[ip]);
        }
      
      CX_Free(custom_property_data);
    }


  if(NNULLP(dpm_component_data))
    {
      int ic;

      for(ic=0;ic<edem_coupling.num_dpm_components;ic++)
        {
          CX_Free(dpm_component_data[ic]);
        }

      CX_Free(dpm_component_data);
    }


#endif /* !RP_NODE */

  Message0("  Done.\n");
}



//DEFINE_ON_DEMAND(update_edem_solution)
void update_edem_solution()
{
  int update_success;
  double time;

#if !RP_NODE
  int time_stagger_option;
#endif

  Message0("\nUpdating EDEM solution ... ");

  if(!edem_coupling.coupled)
    {
      Message0("\n\n  WARNING: EDEM not connected to Fluent. Update failed\n\n");
      return;
    }

  send_particle_data_to_edem();

#if PARALLEL
  Node_Idle_Wait_Host();
#endif

#if !RP_NODE

  time = CURRENT_TIME;

  // EDEM target time can be altered to CURRENT_TIME +- CURRENT_TIMESTEP/2

  time_stagger_option = RP_Get_Integer("edem/time-stagger-option");

  if(time_stagger_option == 1)
    time += 0.5*CURRENT_TIMESTEP;

  if(time_stagger_option == -1)
    time -= 0.5*CURRENT_TIMESTEP;

  if (edem_coupling.time < time)
    {
      ADAPTOR_performAnalysisToTime(time, &update_success);

      /* Set time to actual EDEM time not requested value as they may be slightly different */
      if(update_success == 1)
        ADAPTOR_getEDEMTime(&time, &update_success);
    }
  else
    {
      update_success = 2; /* Fluent in sync or behind EDEM so do nothing */
    }
#endif

#if PARALLEL
  Node_Idle_Wait_Host();
#endif

  host_to_node_int_1(update_success);
  host_to_node_double_1(time);

  if(update_success)
    {
      if(update_success == 1)
        {
          Message0("  EDEM solution updated to time %e.\n", time);
          edem_coupling.time = time;
          RP_Set_Real("edem/time", time);
        }

      if(update_success == 2)
        Message0("  EDEM solution already at or ahead of time %e.\n", time);
    }
  else
    {
      Message0("  EDEM solution NOT updated to time %e.\n", time);
    }

  Message0("  Done.\n");
}


//DEFINE_ON_DEMAND(synchronize_fluent_to_edem_time)
void synchronize_fluent_to_edem_time()
{
  double time;
  int success;

  if(!edem_coupling.coupled)
    {
      Message0("\n\nWARNING: EDEM not connected to Fluent. Cannot Synchronise\n\n");
      return;
    }

#if !RP_NODE

  ADAPTOR_getEDEMTime(&time, &success);

#endif /* !RP_NODE */

  host_to_node_int_1(success);

  if(success)
    {
      host_to_node_double_1(time);

      Message0("\nFluent Synchronised to current EDEM time : %e\n",time);

      edem_coupling.time = time;

      RP_Set_Real("edem/time", time);
      RP_Set_Real("flow-time", time);
    }
  else
    {
      Message0("\n\nERROR: Cannot get EDEM time.\n\n");

      return;
    }
}

//DEFINE_ON_DEMAND(stop_edem_simulation)
void stop_edem_simulation()
{
#if !RP_NODE
  int success;
#endif
  
  if(!edem_coupling.coupled)
    {
      Message0("\n\nWARNING: EDEM not connected to Fluent. Cannot stop simulation.\n\n");
      return;
    }

#if !RP_NODE
  
  Message("\nStopping EDEM Simulation... ");
  
  ADAPTOR_stopSimulation(&success);
  
  if(success)
    Message("Stopped.\n");
  else
    Message("Not Simulating.\n");
#endif /* !RP_NODE */
}


//DEFINE_ON_DEMAND(disconnect_edem_coupling)
void disconnect_edem_coupling()
{
#if !RP_NODE
  int success;
#endif /* !RP_NODE */

  if(!edem_coupling.coupled)
    {
      Message0("\nFluent does not seem to be connected to an EDEM process.\n");

      return;
    }

  if(!rp_unsteady)
    {
      Message0("\n\nWARNING: Cannot be coupled to EDEM from steady Fluent solver.\n");

      edem_coupling.coupled = 0;

      return;
    }

#if !RP_NODE

  Message("\n\nDisconnecting EDEM-Fluent Coupling. Please wait...\n");

  ADAPTOR_stopSimulation(&success);

  ADAPTOR_disconnectEDEMCoupling(&success);

  if(success)
    {
      Message(" EDEM Process Disconnected Successfully.\n");
    }
  else
    {
      Message("\nERROR: Cannot Disconnect from EDEM.\n");
    }

#endif /* !RP_NODE */

  edem_coupling.coupled = 0; /* Set as not coupled regardless of success */
}





DEFINE_ADJUST(adjust_edem_solution, d)
{
  // User might want to add extra setup operations here.
}


DEFINE_EXECUTE_AT_END(update_edem_at_end)
{
  // User might want to add extra cleanup operations here.
}

DEFINE_EXECUTE_AT_EXIT(disconnect_edem_coupling_at_exit)
{
  disconnect_edem_coupling(); // Always disonnect coupling cleanly of exiting Fluent.
}


void activate_edem_injections(Domain *domain, cxboolean track_unsteady)
{
  int i_proto;
  Injection *I;

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
    {
      I = Pick_Injection(edem_coupling.injection_names[i_proto]);

      if (NNULLP(I))
        I->active = TRUE;
    }
}


void deactivate_edem_injections(Domain *domain, cxboolean track_unsteady)
{
  int i_proto;
  Injection *I;

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
    {
      I = Pick_Injection(edem_coupling.injection_names[i_proto]);

      if (NNULLP(I))
        I->active = FALSE;
    }
}

void track_edem_injections(Domain *domain, cxboolean track_unsteady)
{      
  cxboolean need_to_connect;

#if !RP_NODE
  need_to_connect = (!edem_coupling.coupled) && RP_Get_Boolean("edem/connected?");
#endif 

  host_to_node_boolean_1(need_to_connect);

  if(need_to_connect)
    connect_edem_coupling();
 

  if(!edem_coupling.coupled)
    {
      Message0("\n  Not connected to EDEM for particle tracking.\n");
      Message0("  Connect in EDEM Coupling panel.\n\n");
      return;
    }

  Message0("Tracking edem injections... ");

  update_edem_coupling_settings(TRUE);

  /* Get initial set of particles from EDEM only once after initialization */

  if (edem_coupling.num_particles == EDEM_COUPLING_NUM_PARTICLES_INIT)
    get_solution_from_edem();

  if (edem_coupling.num_particles > 0)
    {
      /* Compute forces and heat flux, but don't set source terms */
      Message0("\n Forces computed for EDEM particles WITHOUT sources\n");
      compute_forces_on_particles(edem_coupling, FALSE);

      if(DEM_HEAT_COUPLED_P(edem_coupling) && !DEM_HEAT_TRANSFER_FLUENT_P(edem_coupling))
        compute_heat_flux_to_particles(edem_coupling, FALSE);

      /* compute_properties_on_particles() only needs to be called before update_edem_solution it sets the new values for properties.
         The components are calculated in HeatMassUpdate (called in compute_forces_on_particles) and the sources will be added then. */

      compute_properties_on_particles(edem_coupling, FALSE);
    }

  /* Send particles to EDEM and track them there even if
     there are no particles so EDEM and Fluent kept in sync. */

  update_edem_solution();

  /* Get particles from EDEM and compute source terms for fluid */
  get_solution_from_edem();

  if (edem_coupling.num_particles > 0)
    {
      /* Need to reset distributions. This is deleting information from other injections */

      Update_Dist_Storage();
      Reset_Sampled_Distributions(c_par.cphase_interaction, FALSE, FALSE, DO_CELLS, NULL_CMD);

      Init_Node_Averages(domain, FALSE);  /* if node based averaging is used */

      Message0("\n Forces computed for EDEM particles WITH sources\n");

      /* Now compute the source terms */

      // This is not needed as components are updated in HeatMassUpdate called from compute_forces_on_particles
      // if(DEM_DPM_COMPONENTS_P(edem_coupling))
      //   compute_dpm_components_on_particles(edem_coupling, TRUE);

      compute_forces_on_particles(edem_coupling, TRUE);

      if(DEM_HEAT_COUPLED_P(edem_coupling) && !DEM_HEAT_TRANSFER_FLUENT_P(edem_coupling))
        compute_heat_flux_to_particles(edem_coupling, TRUE);


      /* Now average distributions with information from EDEM particles */
      Average_Distributions(DO_CELLS, NULL_CMD);
      Cleanup_Node_Averages(FALSE);
    }

  deactivate_edem_injections(domain, track_unsteady);

  Message0("Done.\n");

  return;
}


ParticlePrototype *getDPMParticlePrototype(Tracked_Particle *p)
{
  if(NNULLP(edem_coupling.particle_prototypes)&&NNULLP(edem_coupling.injection_ids)&&NNULLP(p))
    {
      int i_proto;

      for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;++i_proto)
        if(edem_coupling.injection_ids[i_proto] == p->pp->I_id)
          return edem_coupling.particle_prototypes + i_proto;
    }

  return (ParticlePrototype *)NULL;
}

double getDPMCrossSection(Tracked_Particle *tp, real *dir)
{
  ParticlePrototype *pp;

  pp = getDPMParticlePrototype(tp);

  if(NNULLP(pp))
    {
      tDimensionValue direction;

      NV_V(direction,=(double),dir); /* direction is a pointer to double not real */

      return SQR(TP_DEM_SCALE(tp)) * getParticlePrototypeCrossSection(pp, direction);
    }

  return 0.0;
}

double getDPMSurfaceArea(Tracked_Particle *tp)
{
  ParticlePrototype *pp;

  pp = getDPMParticlePrototype(tp);

  if(NNULLP(pp))
    {
      return SQR(PP_DEM_SCALE(tp)) * getParticlePrototypeSurfaceArea(pp);
    }

  return 0.0;
}


double getDPMSphericity(Tracked_Particle *tp)
{
  ParticlePrototype *pp;

  pp = getDPMParticlePrototype(tp);

  if(NNULLP(pp))
    {
      return getParticlePrototypeSphericity(pp);
    }

  return 0.0;
}


/*
 * udf_util_data[] defining UDF utility function entries
 *
 * Note: The strings in each element should be typed exactly as shown
 */

#if sys_ntx86  || sys_win64
#  define DLLEXP __declspec(dllexport)
#else
#  define DLLEXP
#endif

DLLEXP UDF_Data udf_util_data[] = {
  {"fl_dpm_pre_solve_update",  (void (*)(void))deactivate_edem_injections, -1},
  {"fl_dpm_post_solve_update", (void (*)(void))track_edem_injections, -1},
};

DLLEXP int n_udf_util_data = sizeof(udf_util_data)/sizeof(UDF_Data);

