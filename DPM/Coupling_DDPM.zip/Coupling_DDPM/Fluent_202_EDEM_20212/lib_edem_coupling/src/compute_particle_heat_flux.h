#ifndef COMPUTE_PARTICLE_HEAT_FLUX_H
# define COMPUTE_PARTICLE_HEAT_FLUX_H 1

#include "version.h"

#define STEFAN_BOLTZMANN_CONSTANT 5.670373e-8

#if (RampantReleaseMajor <= 20)
enum // enumeration in dpm_types.h after 2021
  {
    RANZ_MARSHALL,
    GUNN,
    LI_MASON
  };
#endif

void compute_heat_flux_to_particles(EDEM_Coupling edem_coupling, cxboolean fluid_source_terms);

#endif /* COMPUTE_PARTICLE_HEAT_FLUX_H */
