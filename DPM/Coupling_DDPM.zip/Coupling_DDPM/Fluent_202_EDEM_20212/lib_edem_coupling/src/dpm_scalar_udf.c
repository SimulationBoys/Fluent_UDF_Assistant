#include "udf.h"
#include "edem_coupling.h"

#define HALF_LIFE 1.0

#ifndef M_LN2
# define M_LN2 0.6931471805599453
#endif

DEFINE_DPM_SCALAR_UPDATE(dem_properties_template, c, ct, init, tp)
{
  if(DEM_CUSTOM_PROPERTIES_P(edem_coupling))
    {
      if(init)
        {
          // Not currently called with init = 1
          // P_DEM_CUSTOM_PROPERTY_I(tp,0) = 1000.0;
          // P_DEM_CUSTOM_PROPERTY_I(tp,1) = 500.0;
          // P_DEM_CUSTOM_PROPERTY_I(tp,2) = 100.0;
        }
      else
        {
          double T0;

          T0 = HALF_LIFE/M_LN2;

          // Check indices used
          // Make sure they're < edem_coupling.num_custom_properties

          //  P_DEM_CUSTOM_PROPERTY_I(tp,0) = 1000.0 * P_DEM_FORCE_X(tp);
          //  P_DEM_CUSTOM_PROPERTY_I(tp,1) = 1000.0 * P_VEL(tp)[0];

          /*
          C_CENTROID(cen,c,ct);

          P_DEM_CUSTOM_PROPERTY_I(tp,0) = cen[1];
          P_DEM_CUSTOM_PROPERTY_I(tp,1) = cen[2];

          */

          //  Message("solver_par.flow_time_step %f TP_TIME(tp) %f  TP_TIME0(tp) %f  TP_ACCUMULATED_TIME(tp) %f  TP_DT(tp) %f  TP_TIME_OF_BIRTH(tp) %f   TP_INIT_TIME(tp) %f\n", solver_par.flow_time_step, TP_TIME(tp), TP_TIME0(tp), TP_ACCUMULATED_TIME(tp), TP_DT(tp), TP_TIME_OF_BIRTH(tp), TP_INIT_TIME(tp));

          TP_DEM_CUSTOM_PROPERTY_I(tp,0) *= exp(-solver_par.flow_time_step/T0);
          TP_DEM_CUSTOM_PROPERTY_I(tp,1) *= exp(-solver_par.flow_time_step/(2.0*T0)); // Decays twice as fast
        }
    }
}
