#include "udf.h"
#include "AdaptorInterface.h"
#include "edem_coupling.h"

void free_edem_coupling_dpm_components()
{

  if(NNULLP(edem_coupling.dpm_component_indices))
    CX_Free(edem_coupling.dpm_component_indices);

  if (DEM_DPM_COMPONENTS_P(edem_coupling) && NNULLP(edem_coupling.dpm_component_names))
    {
      int ic;

      for (ic=0;ic<edem_coupling.num_dpm_components;ic++)
        CX_Free(edem_coupling.dpm_component_names[ic]);

      CX_Free(edem_coupling.dpm_component_names);
    }

  edem_coupling.num_dpm_components = 0;
  edem_coupling.dpm_component_indices = NULL;
  edem_coupling.dpm_component_names = NULL;
}


int get_particle_component_index_from_name(Injection *I, char *name)
{
  int i_comp;
  Material *m, *sp;


  if(NNULLP(I))
    {
      m = I->material;

      if (NNULLP(m)) // TEST Should m ever be null?
        {
          if (m->type == MATERIAL_PARTICLE_MIXTURE)
            {
              mixture_component_loop(m,sp,i_comp)
                {
                  if(strncmp(name, sp->name, MATERIAL_NAME_LENGTH) == 0)
                    return i_comp;
                }
            }
        }
    }

  return DPM_NULL_SPECIES_INDEX;
}

int set_edem_coupling_dpm_component_names()
{
#if !RP_NODE
  int i_proto;
  Injection *I;
  Material *m, *sp;
  int n_comps;
  int jc;
  char **component_names;
  int n_dups;

#endif // !RP_NODE
  int ic;

  if (!edem_coupling.coupled)
    return 0;

  free_edem_coupling_dpm_components();

  if (edem_coupling.num_particle_prototypes <= 0)
    return 0;


#if !RP_NODE

  n_comps = 0;

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;++i_proto)
    {
      I = edem_coupling.injections[i_proto];

      if(NNULLP(I))
        {
          m = I->material;

          if (m->type == MATERIAL_PARTICLE_MIXTURE)
            n_comps += P_INJ_N_COMPONENTS(I);
        }
    }

  component_names = CX_Malloc(n_comps * sizeof(char*));

  for(ic=0;ic<n_comps;ic++)
    component_names[ic] = CX_Malloc(MATERIAL_NAME_LENGTH * sizeof(char));

  n_comps = 0; // Will be recounted as name array is filled.

  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;++i_proto)
    {
      I = edem_coupling.injections[i_proto];

      if(NNULLP(I))
        {
          m = I->material;

          if (m->type == MATERIAL_PARTICLE_MIXTURE)
            {
              mixture_component_loop(m,sp,ic)
                {
                  strncpy(component_names[n_comps], sp->name, MATERIAL_NAME_LENGTH);
                  n_comps++;
                }
            }
        }
    }

  // Remove duplicate component names

  n_dups = 0;
  for (ic=0;ic<n_comps-1;ic++)
    for (jc=ic+1;jc<n_comps;jc++)
      {
        if(STREQ(component_names[ic],component_names[jc]))
          {
            CX_Free(component_names[ic]);
            component_names[ic] = NULL;
            n_dups++;
            break;
          }
      }

  edem_coupling.num_dpm_components = n_comps - n_dups;
  edem_coupling.dpm_component_names = CX_Malloc(edem_coupling.num_dpm_components * sizeof(char*));

  for(ic=0;ic<edem_coupling.num_dpm_components;ic++)
    edem_coupling.dpm_component_names[ic] = CX_Malloc(MATERIAL_NAME_LENGTH * sizeof(char));

  jc = 0;
  for (ic=0;ic<n_comps;ic++)
    if(NNULLP(component_names[ic]))
      {
        strncpy(edem_coupling.dpm_component_names[jc],component_names[ic],MATERIAL_NAME_LENGTH);
        jc++;
      }

#endif

  host_to_node_int_1(edem_coupling.num_dpm_components);

  if(DEM_DPM_COMPONENTS_P(edem_coupling))
    {

#if !RP_HOST
      edem_coupling.dpm_component_names = CX_Malloc(edem_coupling.num_dpm_components * sizeof(char*));

      for(ic=0;ic<edem_coupling.num_dpm_components;ic++)
        edem_coupling.dpm_component_names[ic] = CX_Malloc(MATERIAL_NAME_LENGTH * sizeof(char));
#endif // !RP_HOST

      for(ic=0;ic<edem_coupling.num_dpm_components;ic++)
        host_to_node_string(edem_coupling.dpm_component_names[ic], MATERIAL_NAME_LENGTH);
    }

  return edem_coupling.num_dpm_components;
}


int register_dpm_components()
{
#if !RP_NODE

  int propNumElements = 1;                     /* Define number of elements to the DPM component */
  int propDataType = CM_PROP_DATA_TYPE_DOUBLE; /* Define the data type using EDEMs index system */
  int propUnitType = CM_PROP_UNIT_TYPE_NONE;   /* Define the unit type using EDEMs index system */
  double initialValue = 0.0;                   /* Define the default value */

#endif // !RP_NODE


  if (!edem_coupling.coupled)
    return 0;

  edem_coupling.num_dpm_components = set_edem_coupling_dpm_component_names();

  if(! DEM_DPM_COMPONENTS_P(edem_coupling))
    {
#if !RP_NODE
      Message("\nNo DPM components registered.\n");

      if(edem_coupling.coupled)
          Message(" Solution has not been passed from EDEM yet.\n");
      else
        Message(" Not coupled to EDEM.\n");
#endif // !RP_NODE

      return 0;
    }

#if !RP_NODE

  if(NNULLP(edem_coupling.dpm_component_names))
    {
      int prop_registered;
      int property_index;
      int ic;


      Message("\nRegistering %d DPM components...\n", edem_coupling.num_dpm_components);

      edem_coupling.dpm_component_indices = CX_Malloc(edem_coupling.num_dpm_components*sizeof(int));

      for (ic = 0; ic < edem_coupling.num_dpm_components; ic++)
        {
          prop_registered = ADAPTOR_registerCustomProperty(edem_coupling.dpm_component_names[ic], propNumElements, propDataType, propUnitType, initialValue, &property_index);

          edem_coupling.dpm_component_indices[ic] = property_index;

          if(prop_registered)
            {
              Message("  DPM Component %s registered (index %d)\n",
                      edem_coupling.dpm_component_names[ic],
                      edem_coupling.dpm_component_indices[ic]);
            }
          else
            {
              if(edem_coupling.dpm_component_indices[ic] > 0)
                Message("  DPM Component '%s' is already registered (index %d)\n",
                        edem_coupling.dpm_component_names[ic],
                        edem_coupling.dpm_component_indices[ic]);
              else
                Message("  Failed to register DPM Component %s\n", edem_coupling.dpm_component_names[ic]);
            }
        }
      Message("Done.\n");
    }
  else
    Message("\n\nWARNING: Custom DPM components failed to be registered.\n\n");

#endif // !RP_NODE

#if RP_NODE
  edem_coupling.dpm_component_indices = CX_Malloc(edem_coupling.num_dpm_components*sizeof(int));
#endif // RP_NODE

  host_to_node_int(edem_coupling.dpm_component_indices, edem_coupling.num_dpm_components);

  return edem_coupling.num_dpm_components;
}

DEFINE_ON_DEMAND(register_edem_dpm_components)
{
  register_dpm_components();
}

