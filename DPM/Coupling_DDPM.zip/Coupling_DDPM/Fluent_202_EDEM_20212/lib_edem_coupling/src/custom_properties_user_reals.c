#include "udf.h"
#include "AdaptorInterface.h"
#include "edem_coupling.h"


void free_edem_coupling_custom_properties()
{

  if(NNULLP(edem_coupling.property_indices))
    CX_Free(edem_coupling.property_indices);

  if (edem_coupling.num_custom_properties && NNULLP(edem_coupling.property_names))
    {
      int ip;

      for (ip=0;ip<edem_coupling.num_custom_properties;ip++)
        CX_Free(edem_coupling.property_names[ip]);

      CX_Free(edem_coupling.property_names);
    }

  edem_coupling.num_custom_properties = 0;
  edem_coupling.property_indices = NULL;
  edem_coupling.property_names = NULL;
}


int register_custom_properties()
{
  static int num_registered_properties = 0;

#if !RP_NODE
  int propNumElements = 1;                     /* Define number of elements to the custom property */
  int propDataType = CM_PROP_DATA_TYPE_DOUBLE; /* Define the data type using EDEMs index system */
  int propUnitType = CM_PROP_UNIT_TYPE_NONE;   /* Define the unit type using EDEMs index system */
  double initialValue = 0.0;                   /* Define the default value */
#endif // !RP_NODE

  int ip;

#if !RP_NODE

  edem_coupling.num_custom_properties = RP_Get_List_Length("edem/custom-properties"); // Properties set in list of required property names

  edem_coupling.property_indices = CX_Realloc(edem_coupling.property_indices, edem_coupling.num_custom_properties*sizeof(int));

  for(ip=0;ip<num_registered_properties;ip++)
    CX_Free(edem_coupling.property_names[ip]);

  edem_coupling.property_names = CX_Realloc(edem_coupling.property_names, edem_coupling.num_custom_properties*sizeof(char **));

  for(ip=0;ip<edem_coupling.num_custom_properties;ip++)
    edem_coupling.property_names[ip] = CX_Malloc(MAX_NAME_LENGTH*sizeof(char *));
    

  if(edem_coupling.num_custom_properties && NNULLP(edem_coupling.property_names))
    {
      int prop_registered;
      int property_index;
      int ip;

      Message("\nRegistering %d properties...\n", edem_coupling.num_custom_properties);

      for (ip=0;ip<edem_coupling.num_custom_properties;ip++)
        strncpy(edem_coupling.property_names[ip], RP_Get_List_Ref_String("edem/custom-properties", ip), MAX_NAME_LENGTH);

      for (ip = 0; ip < edem_coupling.num_custom_properties; ip++)
        {
          prop_registered = ADAPTOR_registerCustomProperty((char *)edem_coupling.property_names[ip], propNumElements, propDataType, propUnitType, initialValue, &property_index);
          edem_coupling.property_indices[ip] = property_index;

          if (prop_registered)
            Message("  Property %s registered (index %d)\n",
                    edem_coupling.property_names[ip],
                    edem_coupling.property_indices[ip]);
          else
            {
              if (edem_coupling.property_indices[ip] > 0)
                Message("  Property %s already registered (index %d)\n",
                        edem_coupling.property_names[ip],
                        edem_coupling.property_indices[ip]);
              else
                Message("  Failed to register Property %s\n", edem_coupling.property_names[ip]);
            }
        }

      Message("Done.\n");
    }
  else
    {
      if (edem_coupling.num_custom_properties > 0)
        Message("\n\nWARNING: %d Custom properties failed to be registered.\n\n", edem_coupling.num_custom_properties);

      edem_coupling.num_custom_properties = 0;
    }


#endif /* !RP_NODE */

  host_to_node_int_1(edem_coupling.num_custom_properties);

#if RP_NODE

  edem_coupling.property_indices = CX_Realloc(edem_coupling.property_indices, edem_coupling.num_custom_properties*sizeof(int));

  for(ip=0;ip<num_registered_properties;ip++)
    CX_Free(edem_coupling.property_names[ip]);

  edem_coupling.property_names = CX_Realloc(edem_coupling.property_names, edem_coupling.num_custom_properties*sizeof(char **));

  for(ip=0;ip<edem_coupling.num_custom_properties;ip++)
    edem_coupling.property_names[ip] = CX_Malloc(MAX_NAME_LENGTH*sizeof(char *));

#endif // RP_NODE



  host_to_node_int(edem_coupling.property_indices, edem_coupling.num_custom_properties);

  for(ip=0;ip<edem_coupling.num_custom_properties;ip++)
    host_to_node_string(edem_coupling.property_names[ip], MAX_NAME_LENGTH);

  num_registered_properties = edem_coupling.num_custom_properties;

  return num_registered_properties;
}

//DEFINE_ON_DEMAND(register_edem_custom_properties)
//{
//  register_custom_properties();
//}
