#include "udf.h"
#ifndef COMPUTE_DPM_COMPONENTS_PROPERTIES_H
# define COMPUTE_DPM_COMPONENTS_PROPERTIES_H 1

void compute_dpm_components_on_particles(EDEM_Coupling edem_coupling, cxboolean fluid_source_terms);

#endif // COMPUTE_DPM_COMPONENTS_PROPERTIES_H

