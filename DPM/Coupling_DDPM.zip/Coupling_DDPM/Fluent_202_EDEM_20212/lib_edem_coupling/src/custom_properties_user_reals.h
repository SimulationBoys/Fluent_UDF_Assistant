#ifndef CUSTOM_PROPERTIES_USER_REALS_H
# define CUSTOM_PROPERTIES_USER_REALS_H 1

void free_edem_coupling_custom_properties();
int register_custom_properties();

#endif // CUSTOM_PROPERTIES_USER_REALS_H
