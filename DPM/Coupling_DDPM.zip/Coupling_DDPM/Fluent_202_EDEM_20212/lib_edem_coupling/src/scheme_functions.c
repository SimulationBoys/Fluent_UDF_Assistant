#include "edem_coupling.h"
#include "AdaptorInterface.h"
#include "seem2c.h"

char *strncpy_scm(char *dest, char *src, size_t n)
{
  /* Create a scheme symbol like name from a string. Lowercase, no spaces. */

  int i, j;
  int letter_found, space_found;
  char *scan;

  i = 0;
  j = 0;

  letter_found = 0;
  space_found = 0;
  scan = src;

  while (i < n)
    {
      if (*scan == '\0')
        {
          dest[j] = *scan;
          return dest;
        }

      if ((*scan != ' ')&&(*scan != '\n')&&(*scan != '\t')) /* Not whitespace */
        {
          if(letter_found && space_found) /* Only add one '-' for consecutive whitespace blocks and not at start or end */
            {
              dest[j] = '-';
              j++;
            }

          letter_found = 1;
          space_found = 0;
          dest[j] = tolower(*scan);
          j++;
        }
      else
        {
          space_found = 1;
        }

      scan++;
    }

  /* No ending /0 found so set it */

  dest[n-1] = '\0';

  return dest;
}


#if !RP_NODE /* Scheme calls */

static Pointer ledemisconnected()
{
  RETURNP(edem_coupling.coupled);
}

static Pointer ledemnreqdpmuserreals()
{
  RETURN_FIXNUM(get_n_req_dpm_user_reals());
}

static Pointer ledemupdatesettings()
{
  update_edem_coupling_settings(FALSE); /* Don't update on Nodes as called from Scheme */
  RETURNP(TRUE);
}

static Pointer ledemnparticletypes()
{
  if (edem_coupling.coupled)
    RETURN_FIXNUM(ADAPTOR_getNumParticleTypes());
  else
    RETURN_FIXNUM(0);
}

static Pointer ledemnparticletypeslookahead()
{
  if (edem_coupling.coupled)
    {
      int success;
      double orig_time;

      ADAPTOR_getEDEMTime(&orig_time, &success);

      if (success)
        /* Perform 1 step to get particle and other data initialised */
        ADAPTOR_performNumAnalysisSteps(1, &success);

      if (success)
        {
          int num_particle_types;

          num_particle_types = ADAPTOR_getNumParticleTypes();

          ADAPTOR_setEDEMTime(orig_time, &success);/* Reset Time to original value */

          RETURN_FIXNUM(num_particle_types);
        }

      RETURN_FIXNUM(0);
    }
  else
    RETURN_FIXNUM(0);
}


static Pointer ledemnparticles(Pointer index)
{

  if (edem_coupling.coupled)
    {
      int i_proto, num_particle_types;
      int num_particles;

      num_particle_types = ADAPTOR_getNumParticleTypes();

      i_proto = INT_ARG(index, "%edem-num-particles: wta[1](integer)");

      if(i_proto >= num_particle_types)
        RETURN_FIXNUM(0); // Out of range

      if(i_proto >= 0)
        num_particles = ADAPTOR_getNumParticles(i_proto); // Set num_particles just for specified type
      else
        {
          num_particles = 0;
          for(i_proto=0;i_proto<num_particle_types;i_proto++)
            num_particles += ADAPTOR_getNumParticles(i_proto);
        }

      RETURN_FIXNUM(num_particles);
    }
  else
    RETURN_FIXNUM(0);
}


static Pointer ledemperformnumanalysissteps(Pointer index)
{
  if (edem_coupling.coupled)
    {
      int n_steps;
      int success;

      n_steps = INT_ARG(index, "%edem-perform-num-analysis-steps: wta[1](integer)");

      ADAPTOR_performNumAnalysisSteps(n_steps, &success);

      RETURN_FIXNUM(success);
    }
  else
    RETURN_FIXNUM(0);
}

static Pointer ledemparticletypename(Pointer index)
{
  int i_proto, n_pro;
  ParticlePrototype pp;

  i_proto = INT_ARG(index, "edem-particle-type-name: wta[1](integer)");
  n_pro = ADAPTOR_getParticlePrototypeData();

  if ((i_proto < 0)||(i_proto >= n_pro))
    RETURNP(FALSE);

  init_ParticlePrototype(&pp); /* Initialise values to 0 & pointers to NULL to avoid seg fault in ADAPTOR_getParticlePrototype */

  ADAPTOR_getParticlePrototype(i_proto, &pp);

  RETURN_STRING(pp.sPrototypeName);
}
#endif /* !RP_NODE Host Scheme calls */



// Scheme wrappers for previous ON_DEMAND UDFs

static Pointer
lconnectedemcoupling()
{
  PRF_START(("%connect-edem-coupling"));
  connect_edem_coupling();
  PRF_FINISH(TRUE);
  return NIL;
}

static Pointer
ldisconnectedemcoupling()
{
  PRF_START(("%disconnect-edem-coupling"));
  disconnect_edem_coupling();
  PRF_FINISH(TRUE);
  return NIL;
}

static Pointer
lsynchronizefluenttoedemtime()
{
  PRF_START(("%synchronize-fluent-to-edem-time"));
  synchronize_fluent_to_edem_time();
  PRF_FINISH(TRUE);
  return NIL;
}

static Pointer
lupdateedemsolution()
{
  PRF_START(("%update-edem-solution"));
  update_edem_solution();
  PRF_FINISH(TRUE);
  return NIL;
}

static Pointer
lstopedemsimulation()
{
  PRF_START(("%stop-edem-simulation"));
  stop_edem_simulation();
  PRF_FINISH(TRUE);
  return NIL;
}


DEFINE_EXECUTE_ON_LOADING(bind_edem_subrs, libname)
{
#if !RP_NODE /* Host Scheme calls */

  init_subr("%edem-is-connected?",tc_subr_0,(Subr)ledemisconnected);
  init_subr("%edem-update-settings",tc_subr_0,(Subr)ledemupdatesettings);
  init_subr("%edem-n-req-dpm-user-reals",tc_subr_0,(Subr)ledemnreqdpmuserreals);
  init_subr("%edem-n-particle-types",tc_subr_0,(Subr)ledemnparticletypes);
  init_subr("%edem-n-particle-types-look-ahead",tc_subr_0,(Subr)ledemnparticletypeslookahead);
  init_subr("%edem-n-particles",tc_subr_1,(Subr)ledemnparticles);
  init_subr("%edem-perform-num-analysis-steps",tc_subr_1,(Subr)ledemperformnumanalysissteps);
  init_subr("%edem-particle-type-name",tc_subr_1,(Subr)ledemparticletypename);

#endif /* !RP_NODE Host Scheme calls */

  // ON_DEMAND equivalent scheme wrappers

  init_subr("%connect-edem-coupling",tc_subr_0,(Subr)lconnectedemcoupling);
  init_subr("%disconnect-edem-coupling",tc_subr_0,(Subr)ldisconnectedemcoupling);
  init_subr("%synchronize-fluent-to-edem-time",tc_subr_0,(Subr)lsynchronizefluenttoedemtime);
  init_subr("%update-edem-solution",tc_subr_0,(Subr)lupdateedemsolution);
  init_subr("%stop-edem-simulation",tc_subr_0,(Subr)lstopedemsimulation);
}

