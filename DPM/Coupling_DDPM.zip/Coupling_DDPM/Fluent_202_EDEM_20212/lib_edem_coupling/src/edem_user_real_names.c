#include "udf.h"
#include "edem_coupling.h"
#include "scheme_functions.h"


void set_edem_user_real_names()
{
  /* Make sure memory for particle variable names is allocated */
  Init_User_Particle_Vars();

  sprintf(user_particle_vars[DEM_FORCE_X].name, "edem-force-x");
  sprintf(user_particle_vars[DEM_FORCE_X].label, "EDEM Force X");
  strcpy(user_particle_vars[DEM_FORCE_X].units, ""); // strcpy to avoid zero length format compiler warning 
  user_particle_vars[DEM_FORCE_X].vector_name = NULL; // Could add vector name "EDEM Force"
  user_particle_vars[DEM_FORCE_X].vector_component = '\0'; // Could add vector component "X"

  sprintf(user_particle_vars[DEM_FORCE_Y].name, "edem-force-y");
  sprintf(user_particle_vars[DEM_FORCE_Y].label, "EDEM Force Y");
  strcpy(user_particle_vars[DEM_FORCE_Y].units, "");
  user_particle_vars[DEM_FORCE_Y].vector_name = NULL;
  user_particle_vars[DEM_FORCE_Y].vector_component = '\0';

  sprintf(user_particle_vars[DEM_FORCE_Z].name, "edem-force-z");
  sprintf(user_particle_vars[DEM_FORCE_Z].label, "EDEM Force Z");
  strcpy(user_particle_vars[DEM_FORCE_Z].units, "");
  user_particle_vars[DEM_FORCE_Z].vector_name = NULL;
  user_particle_vars[DEM_FORCE_Z].vector_component = '\0';

  sprintf(user_particle_vars[DEM_TORQUE_X].name, "edem-torque-x");
  sprintf(user_particle_vars[DEM_TORQUE_X].label, "EDEM Torque X");
  strcpy(user_particle_vars[DEM_TORQUE_X].units, "");
  user_particle_vars[DEM_TORQUE_X].vector_name = NULL;
  user_particle_vars[DEM_TORQUE_X].vector_component = '\0';

  sprintf(user_particle_vars[DEM_TORQUE_Y].name, "edem-torque-y");
  sprintf(user_particle_vars[DEM_TORQUE_Y].label, "EDEM Torque Y");
  strcpy(user_particle_vars[DEM_TORQUE_Y].units, "");
  user_particle_vars[DEM_TORQUE_Y].vector_name = NULL;
  user_particle_vars[DEM_TORQUE_Y].vector_component = '\0';

  sprintf(user_particle_vars[DEM_TORQUE_Z].name, "edem-torque-z");
  sprintf(user_particle_vars[DEM_TORQUE_Z].label, "EDEM Torque Z");
  strcpy(user_particle_vars[DEM_TORQUE_Z].units, "");
  user_particle_vars[DEM_TORQUE_Z].vector_name = NULL;
  user_particle_vars[DEM_TORQUE_Z].vector_component = '\0';

  sprintf(user_particle_vars[DEM_SCALE].name, "edem-scaling-factor");
  sprintf(user_particle_vars[DEM_SCALE].label, "EDEM Scaling Factor");
  strcpy(user_particle_vars[DEM_SCALE].units, "");
  user_particle_vars[DEM_SCALE].vector_name = NULL;
  user_particle_vars[DEM_SCALE].vector_component = '\0';

  sprintf(user_particle_vars[DEM_ORIENT_R].name, "edem-orientation-real");
  sprintf(user_particle_vars[DEM_ORIENT_R].label, "EDEM Orientation Real");
  strcpy(user_particle_vars[DEM_ORIENT_R].units, "");
  user_particle_vars[DEM_ORIENT_R].vector_name = NULL;
  user_particle_vars[DEM_ORIENT_R].vector_component = '\0';

  sprintf(user_particle_vars[DEM_ORIENT_I].name, "edem-orientation-i");
  sprintf(user_particle_vars[DEM_ORIENT_I].label, "EDEM Orientation I");
  strcpy(user_particle_vars[DEM_ORIENT_I].units, "");
  user_particle_vars[DEM_ORIENT_I].vector_name = NULL;
  user_particle_vars[DEM_ORIENT_I].vector_component = '\0';

  sprintf(user_particle_vars[DEM_ORIENT_J].name, "edem-orientation-j");
  sprintf(user_particle_vars[DEM_ORIENT_J].label, "EDEM Orientation J");
  strcpy(user_particle_vars[DEM_ORIENT_J].units, "");
  user_particle_vars[DEM_ORIENT_J].vector_name = NULL;
  user_particle_vars[DEM_ORIENT_J].vector_component = '\0';

  sprintf(user_particle_vars[DEM_ORIENT_K].name, "edem-orientation-k");
  sprintf(user_particle_vars[DEM_ORIENT_K].label, "EDEM Orientation K");
  strcpy(user_particle_vars[DEM_ORIENT_K].units, "");
  user_particle_vars[DEM_ORIENT_K].vector_name = NULL;
  user_particle_vars[DEM_ORIENT_K].vector_component = '\0';

  sprintf(user_particle_vars[DEM_HEAT_FLUX].name, "edem-heat-flux");
  sprintf(user_particle_vars[DEM_HEAT_FLUX].label, "EDEM Heat Flux");
  strcpy(user_particle_vars[DEM_HEAT_FLUX].units, "");
  user_particle_vars[DEM_HEAT_FLUX].vector_name = NULL;
  user_particle_vars[DEM_HEAT_FLUX].vector_component = '\0';

  if (DEM_CUSTOM_PROPERTIES_P(edem_coupling))
    {
      int i_prop;

      for (i_prop=0;i_prop<edem_coupling.num_custom_properties;i_prop++)
        {
          if(NNULLP(edem_coupling.property_names))
            {
              strncpy_scm(user_particle_vars[DEM_PROPERTY_0+i_prop].name, edem_coupling.property_names[i_prop], MAX_NAME_LENGTH);
              strncpy(user_particle_vars[DEM_PROPERTY_0+i_prop].label, edem_coupling.property_names[i_prop], MAX_NAME_LENGTH);
              strcpy(user_particle_vars[DEM_PROPERTY_0+i_prop].units, "");
              user_particle_vars[DEM_PROPERTY_0+i_prop].vector_name = NULL;
              user_particle_vars[DEM_PROPERTY_0+i_prop].vector_component = '\0';
            }
          else
            {
              sprintf(user_particle_vars[DEM_PROPERTY_0+i_prop].name, "edem-property-%d", i_prop);
              sprintf(user_particle_vars[DEM_PROPERTY_0+i_prop].label, "EDEM Property %d", i_prop);
              strcpy(user_particle_vars[DEM_PROPERTY_0+i_prop].units, "");
              user_particle_vars[DEM_PROPERTY_0+i_prop].vector_name = NULL;
              user_particle_vars[DEM_PROPERTY_0+i_prop].vector_component = '\0';
            }
        }
    }
}


//DEFINE_ON_DEMAND(set_edem_user_real_names_on_demand)
//{
//  set_edem_user_real_names();
//  Message("\n Run:\n (models-changed)\n for name changes to be seen.\n");
//}
