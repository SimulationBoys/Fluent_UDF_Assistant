#include "udf.h"
#include "edem_coupling.h"
#include "compute_particle_properties.h"

void compute_dpm_components_on_particles(EDEM_Coupling edem_coupling, cxboolean fluid_source_terms)
{
#if !RP_HOST
  Injection *Ip;
  Particle *p;
  int i_proto;

  Tracked_Particle tp_init = {0};  // Use a single Tracked_Particle to hold each Particle's data
  Tracked_Particle *tp = &tp_init;
#endif /* !RP_HOST */


  if(!DEM_DPM_COMPONENTS_P(edem_coupling))
    return;

  if(NULLP(edem_coupling.injections) || NULLP(edem_coupling.injection_names))
    {
      Message0("\nWARNING: Injections for EDEM particles have not been set up.\n\n");
      return;
    }

#if !RP_HOST

  alloc_tracked_particle_memory(tp);


  for(i_proto=0;i_proto<edem_coupling.num_particle_prototypes;i_proto++)
    {
      Ip = edem_coupling.injections[i_proto];
      alloc_tp_pvars(tp, Ip);

      loop (p, Ip->p)
        {
          copy_p_to_tp(tp, p); // Data from EDEM side only on Particles

          MulticomponentLaw(tp);

          copy_tp_to_p(tp, p);
        }
    }

  free_tp_pvars(tp);
  free_tracked_particle_memory(tp);

#endif /* !RP_HOST */
}
