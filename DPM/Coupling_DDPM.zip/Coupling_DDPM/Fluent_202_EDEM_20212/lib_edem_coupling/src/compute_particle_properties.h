#include "udf.h"
#ifndef COMPUTE_PARTICLE_PROPERTIES_H
# define COMPUTE_PARTICLE_PROPERTIES_H 1

void compute_properties_on_particles(EDEM_Coupling edem_coupling, cxboolean fluid_source_terms);

#endif // COMPUTE_PARTICLE_PROPERTIES_H

