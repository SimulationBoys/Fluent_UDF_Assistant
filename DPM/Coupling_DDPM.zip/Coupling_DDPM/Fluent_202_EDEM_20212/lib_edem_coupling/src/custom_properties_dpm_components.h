#ifndef CUSTOM_PROPERTIES_DPM_COMPONENTS_H
# define CUSTOM_PROPERTIES_DPM_COMPONENTS_H 1

void free_edem_coupling_dpm_components();
int get_particle_component_index_from_name(Injection *I, char *name);
int register_dpm_components();

#endif // CUSTOM_PROPERTIES_DPM_COMPONENTS_H
