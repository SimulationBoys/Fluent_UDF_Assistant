#ifndef SCHEME_FUNCTIONS_H
# define SCHEME_FUNCTIONS_H 1

char *strncpy_scm(char *dest, const char *orig, size_t n);

#endif // SCHEME_FUNCTIONS_H
