// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"

/* Coupling method setters */

DEFINE_ON_DEMAND(set_lagrangian)
{
    /* set the type of link we have*/
    g_linkType = LAGRANGIAN;

#if !RP_NODE
    RP_Set_Integer("edem/link_type", g_linkType);

    /* The Ergun drag model is not suitable for Lagrangian style couplings */
    if(g_dragModel != 0)
    {
        Message("\nThe drag scheme that has been selected is not appropriate for a Lagrangian type coupling.\n");
        Message("The freestream drag scheme has been selected.\n");

        g_dragModel = 0;
        RP_Set_Integer("edem/drag-model", g_dragModel);
    }
#endif /* !RP_NODE */

	host_to_node_int_1(g_dragModel);
}

DEFINE_ON_DEMAND(set_eulerian)
{
    /* set the type of link we have*/
    g_linkType = EULERIAN;

#if !RP_NODE
    RP_Set_Integer("edem/link_type",g_linkType);
#endif
}

DEFINE_ON_DEMAND(set_uncoupled)
{
    /* set the type of link we have*/
    g_linkType = NO_COUPLING;
	
#if !RP_NODE
    RP_Set_Integer("edem/link_type",g_linkType);
#endif
}
