// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"
#include "forceCalculations.h"

/** The implemented drag models */

void defaultDragModel(cell_t containingCell, Thread *containingThread, double occupancy, 
				 int linkType, double volume, double pos[ND_ND], double velocity[ND_ND], 
				 double torque[ND_ND], double force[ND_ND])
{
/*
	fluid force on particle comprises drag force + bouyancy force

	Can use either Di Felice model or Ergun + Wen & Yu model

	Ergun + Wen & Yu model (Aibing Yu)

    drag force based on Xu and Yu formula(after DeFelice, 1994)
    fluid drag = fluid drag(free stream)*cell_voidage^(-X)

    fluid drag_X,Y,Z (free stream)= 0.5 * Cd * fluid_density * projected_area * mag_rel_fluid_vel * rel_fluid_vel_X,Y,Z
    For sphere:
      Cd = 24/Re for Re<=0.5
      Cd = 24(1+0.15*Re^0.687)/Re for 0.5<Re<1000
      Cd = 0.44 for Re>1000
	  Re = cell_voidage * (rho/visc) * Vrel * particle_D

      X = 3.7 - 0.65exp[-0.5(1.5 - log10Re)^2]

	fd = 0.5 * Cd * fluid_density * projected_area * e^(-X)

    The Di Felice model is assumed to be applicable over the complete range of solid fraction
    but this predicts a v high drag force for high solid ratio

    Ergun + Wen & Yu model

    drag force_X,Y,Z =  particle_volume * beta / (1 - nVoidage) * (rel fluid vel_X,Y,Z)
    where
    for fluid cell nVoidage (e) >= 0.8  (after Wen and Yu, 1966)
    beta = 3/4 * Cd * fluid_density * e^(1-a) * (1-e) * relative_fluid vel
    where a = 2.65

    for fluid cell nVoidage (e) <0.8  (derived from Ergun equation)
    beta = 150 * (1-e)^2 /e * fluid_viscosity/particle_diameter^2 + 1.75 * (1-e) * fluid_density/particle_diameter * relative_fluid_vel

	fd = particle_vol * beta / (1 - nVoidage)

    bouyancy force = particle_volume * g * (fluid_density - particle_density)
     only has vertical component (z-axis) which is +ve upwards

     =>fluid force vector = fd*relVx + fd*relVy + (fd*relVz + fb)
     where fd is drag force calculated using either Twente of Sydney models
     and  fb = Fbouyancy

	nLinkType = 0		// Uncoupled
	nLinkType = 1		// Lagrangian
	nLinkType = 2		// Eulerian
*/

    double dragVariable = 0.0;
    double dragForce[ND_ND];
    double bouyancyForce[ND_ND];
	double re, cd;
	double reynoldsLength = 0.0;
	double radius, beta;
	double viscosity, density;
	double relVelLength;
    double relativeVelocity[ND_ND];
	double fluidVelocity[ND_ND];
	double projectedArea = 0.0;
	double voidage = 0.0;

	/*need relative velocity*/
	NV_D( fluidVelocity,=,C_U(containingCell,containingThread),C_V(containingCell,containingThread),C_W(containingCell,containingThread) );
	
	NV_VV(relativeVelocity,=,fluidVelocity,-,velocity);

	relVelLength = NV_MAG(relativeVelocity);
	radius = pow(volume * 3.0 / (4.0 * M_PI), 0.33333);
    projectedArea  = M_PI * radius * radius; /* Assume non-spherical particle to a sphere with same radius based on its volume */
	reynoldsLength = 2 * radius;
    viscosity = C_MU_L(containingCell,containingThread);
    density = C_R(containingCell,containingThread);
     
    if(relVelLength > UNDERFLOW_LIMIT)
	{
		/*1. Drag force */
		re =  density * relVelLength* reynoldsLength / viscosity;
            
        /* nVoidage only needed for Ergun Eq.+ Wen Yu and also di Felice 
		  The freestream drag is not available to Lagragian */
       if( g_dragModel == ERGUN || g_dragModel == DIFELICE )
       {          
		   voidage = 1.0 - occupancy;
		   re *= voidage;
	   }
	   
	   if(re < 0.0)		/* should never happen! */
	   {
		   re = -re; 
	   }
	   
	   if(re > UNDERFLOW_LIMIT)	/* otherwise drag is badly defined */
	   {
		   /* now find Cd value based on Reynolds number. 
		   This is for the freestream drag and Ergun + Wen Yu models. */

		   if( g_dragModel == FREESTREAM || g_dragModel == ERGUN )		
		   {
			   if( re <= 0.5 )
			   {
				   cd = 24.0 / re;
			   }			   
			   else if( re > 0.5 && re <= 1000.0)
			   {
				   cd = 24.0 * ( 1.0 + 0.15 * pow(re,0.687) ) / re;
			   }
			   else
			   {
				   cd = 0.44;
			   }
		   }
		   else if( g_dragModel == DIFELICE ) /* di Felice employs a continuous expression for Cd due to Dallavalle*/
		   {				
			   cd = pow( (0.63 + (4.8/pow(re, 0.5))), 2);
		   }
                		
		   if ( g_dragModel == FREESTREAM ) /* The freestream drag equation */				
		   {					
			   dragVariable = 0.5 * cd * density * projectedArea * relVelLength;				
		   }
		   else if( g_dragModel == ERGUN ) /* The Ergun + Wen & Yu models */
		   {                                                           				    
			   /*Ergun + Wen Yu model
			    equivalent particle diameter
				calculated using projected area by assuming equivalent for sphere*/

			   double equivParticleDiameter = sqrt(projectedArea) * 4.0 / M_PI;
			
			   if (voidage < 0.8)
			   {
				   beta = 150.0 * pow((1.0 - voidage),2) * viscosity / (voidage * pow(equivParticleDiameter,2))
				   + 1.75 * (1.0 - voidage) * density * relVelLength / equivParticleDiameter;
			   }
			   else
			   {				
				   beta = 0.75 * cd * (1.0 - voidage) * pow(voidage, -1.65) * density * relVelLength / equivParticleDiameter;
			   }

			   dragVariable = volume * beta / (1.0 - voidage);
		   }
		   else if ( g_dragModel == DIFELICE ) /* The di Felice model */
		   {			
			   double voidageFactor = 3.7 - 0.65 * exp( -0.5 * pow( ( 1.5 - log10(re) ), 2) );			    

			   dragVariable = 0.5 * cd * density * projectedArea * relVelLength;

			   dragVariable *= pow(voidage, -voidageFactor+1); 
		   }
	   }
	   else
	   {		
		   dragVariable = 0.0;
	   }
	} /* relative vel < UNDERFLOW_LIMIT */
	else
	{
		dragVariable = 0.0;
	}

	/*2. Buoyancy force */
	NV_VS(bouyancyForce,=,M_gravity,*, volume * density);
	NV_VS(dragForce,=,relativeVelocity,*,dragVariable);

	/*3. combining forces*/
	NV_VV(force,=,dragForce,-,bouyancyForce); 
}


void userDefinedDragExample(cell_t containingCell, Thread *pContainingThread, double nOccupancy,
					        int nLinkType, double nVolume, double vPosition[ND_ND], double vVelocity[ND_ND],
							double vTorque[ND_ND], double vForce[ND_ND] )
{    
	/* A simple example that calculates drag based on the freestream    
   equation */

    double f_drag = 0;
    double density;
    double relativeVelocity[ND_ND];
	double fluidVelocity[ND_ND];
	double cd = 0.44;
	double projectedArea = 0.1;

    if( containingCell != NULL_CELL && pContainingThread != NULL_THREAD)
    {
		/*need relative velocity*/
		NV_D( fluidVelocity,=,C_U(containingCell,pContainingThread),
			  C_V(containingCell,pContainingThread),
			  C_W(containingCell,pContainingThread) );

		NV_VV(relativeVelocity,=,fluidVelocity,-,vVelocity);
       
		density = C_R(containingCell,pContainingThread);

		/* A simple drag force calulation */
       	f_drag = 0.5 * cd * density * projectedArea * NV_MAG(relativeVelocity);
       
		NV_VS(vForce,=,relativeVelocity,*,f_drag);      
    }
}
