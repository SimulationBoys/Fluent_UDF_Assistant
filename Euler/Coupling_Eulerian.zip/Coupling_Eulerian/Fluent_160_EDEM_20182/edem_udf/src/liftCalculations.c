// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"
#include "forceCalculations.h"

/** The lift models */

void defaultLiftModel(cell_t containingCell, Thread *containingThread, double volume, tDimensionValue velocity, 
				 tDimensionValue angVelocity, tDimensionValue torque, tDimensionValue force, tDimensionValue vorticity)
{
	/* Lift models include the Saffman lift force and the Magnus lift force.
	Saffman lift is due to velocity gradient in the flow itself (with Mei's correlation).
	Magnus lift is due to the rotation of the particle. 
	They are semi-empirical formulations, hence some of the constants are not defined with names.*/
    
	double radius = 0.0;
	double viscosity = 0.0;
	double density = 0.0;
	double relVelLength = 0.0;
    tDimensionValue relativeVelocity;
	double reynoldsLength = 0.0;
	tDimensionValue fluidVelocity;
    tDimensionValue vorticityDummy;
	double nVoidage = 0.0;		
	double re = 0.0;
	double reStrain = 0.0;
	double reOmega = 0.0;
	double epsilon = 0.0;
 
	/*need relative velocity*/

	NV_D( fluidVelocity,=,C_U(containingCell,containingThread),C_V(containingCell,containingThread),C_W(containingCell,containingThread) );

	NV_VV(relativeVelocity,=,fluidVelocity,-,velocity);

	relVelLength = NV_MAG(relativeVelocity);
	radius = pow(volume * 3.0 / (4.0 * M_PI), 0.33333);
	reynoldsLength = 2 * radius;	
	viscosity = C_MU_L(containingCell,containingThread);
	density = C_R(containingCell,containingThread);				

	if(relVelLength > UNDERFLOW_LIMIT && NV_MAG(vorticity) > UNDERFLOW_LIMIT)	
	{					
		/* Particle Reynolds number */			
		re =  density * relVelLength* reynoldsLength / viscosity;

		/* Particle Reynolds number based on strain rate */
		reStrain = density * NV_MAG(vorticity)*pow(reynoldsLength,2) / viscosity;

		/* Particle Reynolds number based on particle rotational speed */
        NV_VS_VS(vorticityDummy,=,vorticity,*,0.5,-,angVelocity,*,1.0);

		reOmega = density * NV_MAG(vorticityDummy)*pow(reynoldsLength,2) / viscosity;

		epsilon = pow(reStrain,0.5)/re;
		
		if(re < 0.0)		/* should never happen! */	   
		{		   
			re = -re; 	  
		}

		if(reStrain < 0.0)
		{		   
			reStrain = -reStrain; 	  
		}

		if(reOmega < 0.0)
		{		   
			reStrain = -reOmega; 	  
		}

		if(epsilon < 0.0)
		{		   
			epsilon = -epsilon; 	  
		}

		if( re > UNDERFLOW_LIMIT && reStrain > UNDERFLOW_LIMIT && reOmega > UNDERFLOW_LIMIT )
		{
			if(g_saffLift)
			{				
				saffmanLiftModel(radius, viscosity, density, vorticity, relativeVelocity, re, reStrain, reOmega, epsilon, force);	
			}			
			
			if (g_magLift) 
			{
				magnusLiftModel(radius, angVelocity, density, vorticity, relativeVelocity, re, reOmega, force);
			}
		}				
	} 
}

/** Saffman Lift model **/
void saffmanLiftModel(double radius, double viscosity, double density, tDimensionValue vorticity, tDimensionValue relativeVelocity,
					  double re, double reStrain, double reOmega, double epsilon, tDimensionValue force)
{
    tDimensionValue liftForce;
	double liftForceVariable = 0.0;
	double dummyVariable = 0.0;
	double alpha = 0.0;

#if RP_2D
    liftForce[0] = 0.0;
    liftForce[1] = 0.0;
#endif

#if RP_3D
    liftForce[0] = 0.0;
    liftForce[1] = 0.0;
    liftForce[2] = 0.0;
#endif 

	if( re < 1.0 && reStrain < 1.0 && reOmega < 1.0 && epsilon > 1.0 ) /* Original Saffman Lift model */
	{
		liftForceVariable = 1.61*pow(2*radius,2)*pow(viscosity*density,0.5)*pow(NV_MAG(vorticity),-0.5);	
	
		NV_CROSS(liftForce,relativeVelocity,vorticity);	

		NV_VS(liftForce,=,liftForce,*,liftForceVariable);
	}
	else if( re >= 1.0 && re <= 40.0 ) /* If particle Re is larger than 1, use Mei's correlation */
	{
		liftForceVariable = 1.61*pow(2*radius,2)*pow(viscosity*density,0.5)*pow(NV_MAG(vorticity),-0.5);	
	
		NV_CROSS(liftForce,relativeVelocity,vorticity);	

		NV_VS(liftForce,=,liftForce,*,liftForceVariable);

		alpha = 0.5*re*pow(epsilon,2);
					
		if( alpha <= 0.4 && alpha >= 0.005) /* alpha is constrained */
		{
			dummyVariable = ( 1.0 - 0.3314 * pow(alpha,0.5) )*exp(-re*0.1) + 0.3314 * pow(alpha,0.5);						
		}
		else
		{
			dummyVariable = 0.0;
		}
		
		NV_VS(liftForce,=,liftForce,*,dummyVariable);	
	}				
	else if( re > 40.0 && re <= 100.0 )				
	{				
		liftForceVariable = 1.61*pow(2*radius,2)*pow(viscosity*density,0.5)*pow(NV_MAG(vorticity),-0.5);	
	
		NV_CROSS(liftForce,relativeVelocity,vorticity);	

		NV_VS(liftForce,=,liftForce,*,liftForceVariable);

		alpha = 0.5*re*pow(epsilon,2);
		
		if( alpha <= 0.4 && alpha >= 0.005 ) /* alpha is constrained */
		{							
			dummyVariable = 0.0524 * pow(alpha*re,0.5);
		}
		else
		{
			dummyVariable = 0.0;
		}
		
		NV_VS(liftForce,=,liftForce,*,dummyVariable);	
	}	
    else
    {
        NV_VS(liftForce,=,liftForce,*,0.0);
    }

    /* combining forces*/
	NV_V(force,+=,liftForce);
}


/** Magnus Lift model **/
void magnusLiftModel(double radius, tDimensionValue angVelocity, double density, tDimensionValue vorticity, 
					 tDimensionValue relativeVelocity, double re, double reOmega, tDimensionValue force)
{
    /* A correlated model from Lain and Sommerfeld (Powder Technology, 2007) */
    tDimensionValue liftForce;
	double liftForceVariable = 0.0;	
	tDimensionValue vorticityDummy;
    double liftCoefficient = 0.0;

#if RP_2D
    liftForce[0] = 0.0;
    liftForce[1] = 0.0;
#endif

#if RP_3D
    liftForce[0] = 0.0;
    liftForce[1] = 0.0;
    liftForce[2] = 0.0;
#endif

    if( NV_MAG(angVelocity) > UNDERFLOW_LIMIT )
    {
        if(re <= 2000)
        {    
            liftCoefficient = 0.45 + ( (reOmega/re)-0.45 )*exp(-0.05684 * pow(reOmega,0.4) * pow(re,0.3));
        }
        /*else if( re <= 10 )
        {
            liftCoefficient = reOmega/re;
        }*/
        else
        {     
            liftCoefficient = 0.0;
        }
    	
	    liftForceVariable = 0.125*M_PI*pow(2*radius,3)*density*liftCoefficient*(re/reOmega);

	    NV_VS_VS(vorticityDummy,=,vorticity,*,0.5,-,angVelocity,*,1.0);

	    NV_CROSS(liftForce,vorticityDummy,relativeVelocity);

	    NV_VS(liftForce,=,liftForce,*,liftForceVariable);	

        /* combining forces*/
  	    NV_V(force,+=,liftForce);
    }
}

/** The fluid-induced torque model **/

void defaultTorqueModel(cell_t containingCell, Thread *containingThread, double volume, tDimensionValue velocity, 
						tDimensionValue angVelocity, tDimensionValue torque, tDimensionValue vorticity)
{
	double dummyVariable = 0.0;
	double radius = 0.0;
	double density = 0.0;
	double relVelLength = 0.0;
	double viscosity = 0.0;
	double re = 0.0;
    double reOmega = 0.0;
	double reynoldsLength = 0.0;
    tDimensionValue relativeVelocity;
	tDimensionValue fluidVelocity;	
    double coefficient = 0.0;
    tDimensionValue dummyTorque;

#if RP_2D
    dummyTorque[0] = 0.0;
    dummyTorque[1] = 0.0;
#endif

#if RP_3D
    dummyTorque[0] = 0.0;
    dummyTorque[1] = 0.0;
    dummyTorque[2] = 0.0;
#endif

    /* A correlated model from Lain and Sommerfeld (Powder Technology, 2007) */

	/* need relative velocity*/
	NV_D( fluidVelocity,=,C_U(containingCell,containingThread),C_V(containingCell,containingThread),C_W(containingCell,containingThread) );
        
	NV_VV(relativeVelocity,=,fluidVelocity,-,velocity);
    
	relVelLength = NV_MAG(relativeVelocity);
	radius = pow(volume * 3.0 / (4.0 * M_PI), 0.33333); 
	reynoldsLength = 2 * radius;
	density = C_R(containingCell,containingThread);
	viscosity = C_MU_L(containingCell,containingThread);

	re = density * relVelLength * reynoldsLength / viscosity;

    NV_VS_VS(dummyTorque,=,vorticity,*,0.5,-,angVelocity,*,1.0);

	reOmega = density * NV_MAG(dummyTorque)*pow(reynoldsLength,2) / viscosity;

	if(relVelLength > UNDERFLOW_LIMIT)	
	{
		if( reOmega <= 32.0)
		{		
            coefficient = (64 * M_PI)/reOmega;
        }
        else if( reOmega > 32.0 && reOmega < 1000.0 )
        {
            coefficient = (12.9/pow(reOmega,0.5))+(128.4/reOmega);
        }
        else 
        {
            coefficient = 0.0;
        }
			
		dummyVariable = 0.5*density*pow( (radius),5 )*coefficient*NV_MAG(dummyTorque);							
		
        /* Fluid-induced torque on the particle */		
		NV_VS(dummyTorque,=,dummyTorque,*,dummyVariable);

        /* combining torques*/
	    NV_V(torque,+=,dummyTorque);
	}        
}
