// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"
#include <string.h>

/** User selected a DEM deck via the panel*/
DEFINE_ON_DEMAND(select_edem_deck)
{
#if !RP_NODE

  cxboolean bSuccess;
  char *sFilename;


  if(!g_DEMCoupled)
	{
      Message("\nEDEM hasn't been initialised and coupled solution is unavailable.\n");
		  return;
	}

	/* Get the selected filename */
  sFilename = RP_Get_String("edem/inputdeck");
 
	
  /* Load the selected deck, calculate sample points and get the particle data */
  ADAPTOR_selectDeck(sFilename, &bSuccess);

  if(bSuccess)
	{
		Message(FILE_OPEN_SUCCESS);
		g_FCMInitialised = FALSE;
  }
	else
  {
		Message(FILE_OPEN_ERROR);
  }   

#endif /* !RP_NODE */

	/* Send all globals got on host to nodes */

	host_to_node_boolean_1(g_FCMInitialised);
}


DEFINE_ON_DEMAND(couple_to_edem)
{
	/* Initialise edem if we haven't already done so */
	if(!g_DEMCoupled)
		InitialiseEdem(); /* Set g_DEMCoupled to True if successful */

#if !RP_NODE

	Message("Coupling to EDEM\n");

	g_FCMInitialised = FALSE;

	/* Get the selected coupling method */
	g_linkType = RP_Get_Integer("edem/link_type");
         
	if(g_DEMCoupled)
	{
		int nNewDeck;
	
		nNewDeck = RP_Get_Integer("edem/newdeck");

		if(nNewDeck != 1)
		{	
			double time;
			cxboolean bSuccess;
			char *sFilename;

			/* Get the last edem timestep stored in the case file*/
			time = RP_Get_Double("edem/ntime");
			sFilename = RP_Get_String("edem/inputdeck");

			Message("Selecting Deck\n");
            ADAPTOR_selectDeck(sFilename, &bSuccess);

			if(bSuccess)
			{
				Message(FILE_OPEN_SUCCESS);

				/* Set previous timestep as new timestep starts on data loading */
				ADAPTOR_setEDEMTime(time, &bSuccess);
                g_numParticleTypes = ADAPTOR_getNumParticleTypes();

				if(bSuccess)
					Message("\n\nCorresponding EDEM timestep %fs loaded.", time);
				else
					Message("\n\nCannot load corresponding EDEM timestep %fs.", time); 
			}
			else
				Message("\n\nNo linked EDEM file exists, or unable to link file automatically.\nPlease link by hand.");         
		}
	}

#endif /* !RP_NODE */

	/* Send all globals got on host to nodes */

	host_to_node_boolean_1(g_FCMInitialised);
	host_to_node_int_2(g_linkType,g_numParticleTypes);
}

/** This was executed when the library is first loaded by fluent.
  Here we initialise EDEM, and load the dem file associated with the case and data file if it exists. 
  Now call couple_to_edem from elerian and lgrangian callbacks in scheme panel */
  
_DEFINE_EXECUTE_ON_LOADING(on_loading_Edem, libname)
{
  Message("\nLoading EDEM Coupling\n"); 
 
  couple_to_edem();
  
  return 0;
} 

 
DEFINE_ON_DEMAND(test_on_demand)
{
  Message("\n Test On Demand %s\n"); 
} 


/** Function to record the current EDEM time */
DEFINE_RW_FILE(read_case,fp)
{
#if !RP_NODE
    double time;
    cxboolean bSuccess;

    time = RP_Get_Real("edem/ntime");

    /* set previous timestep as new timestep starts on data loading */
    ADAPTOR_setEDEMTime(time, &bSuccess);
#endif
}


/** Create a new DEM file and import the current Fluent mesh.*/

/*DEFINE_ON_DEMAND(new_edem_deck)
{
	/* NOTE: WriteMeshOut NOT parallelised _yet_ as file writing more complex and deemed unnecessary for current usage adam.anderson@ansys.com 
    char *meshFilename;
    cxboolean bSuccess;

#if !RP_NODE
    char *sTempFile;
    char *meshFileExt;
    char *sFilename;
    double *dGravity;
#endif /* !RP_NODE 

	bSuccess = TRUE; 

	if(!g_DEMCoupled)
	{
        Message0("\n\nEDEM hasn't been initialised and coupled solution is unavailable.\n");
		return;
	}
	
	meshFilename = NULL;
	
#if !RP_NODE
# ifdef DEMLINUX
    sTempFile = tempnam("/tmp", "out");
# else
    sTempFile = _tempnam( "c:\\tmp", "out" );
# endif 
    meshFileExt = ".msh";
    meshFilename = (char *)malloc( (strlen(sTempFile) + strlen(meshFileExt) + 1) * sizeof(char));
    strcpy(meshFilename, sTempFile);
    strcat(meshFilename, meshFileExt);

	/* get the DEM filename entered by the user 
    sFilename = RP_Get_String("edem/inputdeck");
    
    dGravity = (double *)malloc(ND_ND * sizeof(double));

    /* If first time we should also use the gravity that they have set 
    NV_V(dGravity,=,M_gravity);
#endif /* !RP_NODE */

    /* Convert the Fluent msh to a format readable by EDEM 
    WriteMeshOut(meshFilename, &bSuccess); /* meshFilename is NULL on parallel nodes 

#if !RP_NODE
    if(bSuccess)
    {
        /* New filename so we need to copy in the msh file and gravity
        ADAPTOR_newMeshFile(sFilename, dGravity, meshFilename, &bSuccess);        
                
        if(bSuccess)
        {
            Message(FILE_OPEN_SUCCESS);
            RP_Set_Integer("edem/newdeck", 0);
        }
    }
    else
    {
        Message("\nError creating new file.");
    } 
	
    free(dGravity);
  
    free(meshFilename);
#endif /* !RP_NODE 
} */



