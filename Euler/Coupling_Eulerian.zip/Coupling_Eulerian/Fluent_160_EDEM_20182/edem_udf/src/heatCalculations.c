// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"
#include "heatCalculations.h"

/** Convective heat models */
void convectionModels(cell_t containingCell, Thread *containingThread, tDimensionValue particleVelocity,  double particleVolume,
                      cxboolean g_convectiveHeatModel, double temperature, double *heatFlux)
{
	double porosity = 0.0;
	double radius = 0.0;
	double surfArea = 0.0;
	double thermalConst = 0.0;
	double nusseltNum = 0.0;
	double re = 0.0; /* Particle Reynolds number */
	double pr = 0.0; /* Prandtl number */
	double thermalConduct = 0.0; /* Thermal conductivity of the gas */
	double density = 0.0, viscosity = 0.0, reynoldsLength = 0.0, relVelLength = 0.0; 
	double specificHeat = 0.0;
	tDimensionValue fluidVelocity, relativeVelocity;


	/* Relative velocity */
	NV_D( fluidVelocity,=,C_U(containingCell,containingThread),C_V(containingCell,containingThread),C_W(containingCell,containingThread) );

	NV_VV(relativeVelocity,=,fluidVelocity,-,particleVelocity);

	relVelLength = NV_MAG(relativeVelocity);			
		
	viscosity = C_MU_L(containingCell,containingThread);
	
	density = C_R(containingCell,containingThread);	
			
	/* Thermal conductivity of the gas */ 				

	thermalConduct = C_K_L(containingCell,containingThread); 
	
	specificHeat = C_CP(containingCell,containingThread);
	
	radius = cbrt(particleVolume * 3.0 / (4.0 * M_PI));		
	
	surfArea = 4.0 * M_PI * radius * radius;		
	
	reynoldsLength = 2.0 * radius;
	/*Message("Thread ID %d  %p  Super  %p\n",THREAD_ID(containingThread),containingThread,THREAD_SUPER_THREAD(containingThread));
	Message("phase id %d\n",DOMAIN_ID(THREAD_DOMAIN(containingThread)));
	Message("VOF data %p\n",T_STORAGE_R(containingThread,SV_VOF));*/
	
	/* Crash HERE in the porosity definition*/
	porosity = C_VOF(containingCell,containingThread); 


	re =  density * relVelLength* reynoldsLength / viscosity; /* Reynolds number */	

	pr = viscosity * specificHeat/thermalConduct; /* Prandtl number */

								
	/* Nusselt number. To be calculated from Ranz & Marshall, Gunn or Li & Mason */	
	if(g_convectiveHeatModel == RANZ)
	{		
		/* Ranz & Marshall */
		nusseltNum = 2.0 + 0.6*sqrt(re)*pow(pr,1.0/3.0);	
		
	}
	else if(g_convectiveHeatModel == GUNN)
	{		
		/* Gunn */
		if(re < 10e5)
		{		
			nusseltNum = (7.0 - 10.0*porosity + 5.0*pow(porosity,2))*(1.0 + 0.7*pow(re,0.2)*pow(pr,1.0/3.0)) +
					 (1.33 - 2.4*porosity + 1.2*pow(porosity,2))*pow(re,0.7)*pow(pr,1.0/3.0);	
		}
	}
	else if(g_convectiveHeatModel == LIMASON)
	{		
		/* Li & Mason's correlation for Ranz and Marshall */
		if(re <= 200)
		{			
			nusseltNum = 2.0 + 0.6*pow(porosity,g_heatLiExp)*sqrt(re)*pow(pr,1.0/3.0);	
		}
		else if(re > 200 && re <= 1500 )
		{
			nusseltNum = 2.0 + 0.5*pow(porosity,g_heatLiExp)*sqrt(re)*pow(pr,1.0/3.0) +
						0.02*pow(porosity,g_heatLiExp)*pow(re,0.8)*pow(pr,1.0/3.0);
		}
		else if(re > 1500 )
		{			
			nusseltNum = 2.0 + 4.5e-5*pow(porosity,g_heatLiExp)*pow(re,1.8);	
		}
	}
		
	thermalConst = nusseltNum * thermalConduct / (2.0 * radius);

	/* Heat flux 
	NOTE: Heat flux is volumetric in FLUENT, but not in EDEM */	

	*heatFlux += thermalConst * surfArea * ( C_T(containingCell,containingThread) - temperature);


\
	/* Store the source term in UDM. The equation is a source instead of sink because ..... heatFlux = ....Particle_Temp - Fluid_Temp */				
	C_DEM_HEAT_SRC(containingCell,containingThread) -= *heatFlux/C_VOLUME(containingCell,containingThread);		
	/*Message("Finished Convection calcs  \n");	*/
}


/** Radiative heat models */
void radiationModels(cell_t containingCell, Thread *containingThread,
                     double particleVolume, double temperature, double* heatFlux)
{
	double radius = 0.0;
	double surfArea = 0.0;
	double density = 0.0, viscosity = 0.0, reynoldsLength = 0.0, relVelLength = 0.0; 
	double specificHeat = 0.0;
	double localAverageTemp = 0.0;
	
	radius = cbrt(particleVolume * 3.0 / (4.0 * M_PI));							
	surfArea = 4.0 * M_PI * SQR(radius);	

	if(C_DEM_HEAT_COUNT(containingCell,containingThread) < 1.0)
	{
		C_DEM_HEAT_COUNT(containingCell,containingThread) = 1.0;
	}

    /* Local averaged bulk temperature */
	localAverageTemp = (C_DEM_HEAT(containingCell,containingThread) - temperature)/(C_DEM_HEAT_COUNT(containingCell,containingThread));

	/** The Stefan-Boltzmann Model 
	C_DEM_HEAT is the sum of all the particle temperature in the residing fluid cell **/
	*heatFlux += STEFANBOLTZMANNCONST * g_emissivity * surfArea * (POW4(localAverageTemp) - POW4(temperature));

	/* Transform the heat flux into volumetric */
	/* Store the source term in UDM. The equation is a source instead of sink because ..... heatFlux = ....Particle_Temp - Fluid_Temp */				
	C_DEM_HEAT_SRC(containingCell,containingThread) -= *heatFlux/C_VOLUME(containingCell,containingThread);
}
