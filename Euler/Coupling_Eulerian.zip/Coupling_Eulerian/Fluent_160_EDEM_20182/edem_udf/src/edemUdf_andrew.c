// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"
#include "forceCalculations.h"
#include "heatCalculations.h"
#include "prf.h"


static int DEM_ID = 3;

/* EDEM external global variables */

/* Global vars for Particle details */

const int           MAX_PARTICLE_TYPES;         /* The maximum number of particle types that can be allocated for */
int g_numParticles		    = 0; /* Number of particles. */
int g_numParticleTypes      = 0; /* Number of particle types */
int g_NumDiscreteElements	= 0;
int g_NumParticleSamplePoints = 20;  /* Number of samples taken from each particle*/
cxboolean g_DEMCoupled		= FALSE; /* TRUE if EDEM is started and we have a valid license */
cxboolean g_heatRegistered  = FALSE; /* Indicates if heat properties are registered */
cxboolean g_FCMInitialised  = FALSE; /* Perform checks on the first iteration */
int g_temperatureIndex      = -1;    /* Property index for temperature */
int g_heatFluxIndex         = -1;    /* Property index for heat flux */
FILE *g_debugFile           = 0;


/* Model Settings */
int					g_linkType;					/* selected coupling method */
int			        g_dragModel;				/* Selected drag model */
cxboolean	        g_saffLift;					/* Saffman lift model */
cxboolean			g_magLift;					/* Magnus lift model */
double				g_VolumeURF;				/* Volume under-relaxation factor */
double				g_MomentumURF;				/* Momentum under-relaxation factor */
double				g_heatURF;					/* Heat under-relaxation factor */
cxboolean			g_torque;					/* Option for fluid-induced torque */
cxboolean			g_convectiveHeatOption;		/* Option for convective heat transfer */
int					g_convectiveHeatModel;		/* Convective heat transfer model */
double				g_heatLiExp;				/* Exponential constant for Li & Mason model that require user's input */
cxboolean			g_radiativeHeatOption;		/* Option for radiative heat transfer */
double				g_emissivity;				/* User input for the particle surface emissivity */

int					g_FluidCells;               /* the current number of Fluent cells */
int					g_Threads;					/* the current number of Fluent threads */


#if !RP_NODE
cxboolean registerHeatProperties(int *temperatureIndex, int *heatFluxIndex)
{
  /* Properties to register for the heat transfer: temperature and heat flux */
	
  int tempNumElements = 1;	 /* Define number of elements to the custom property */
  int tempDataType = 0;		 /* Define the data type as a double using EDEMs index system */
  int tempUnitType = 20;     /* Define the unit type as temperature using EDEMs index system */
  double initialTemp = 0.0;	 /* Define the starting temperature */

  /*
   * Heat flux is a special custom property. It has 2 elements:
   * The first element is used by EDEM particle contacts for heat flux.
   * The second element is used by the CFD package for fluid to particle
   * heat flux. Even though the first entry will not be used here we are
   * declaring the property here and therefore must declare both entries for
   * EDEM to work correctly
   */

  int heatFluxNumElements = 2;  /* Define number of elements to the custom property */
  int heatFluxDataType = 0;	    /* Define the data type as a double using EDEMs index system */
  int heatFluxUnitType = 21;    /* Define the unit type as heat flux using EDEMs index system */
  double initialHeatFlux = 0.0; /* Define the starting heat flux */

    
  /* Register temperature AND heat flux */
  if (ADAPTOR_registerCustomProperty("Temperature", tempNumElements, tempDataType, tempUnitType, initialTemp, temperatureIndex) &&
      ADAPTOR_registerCustomProperty("Heat Flux", heatFluxNumElements, heatFluxDataType, heatFluxUnitType, initialHeatFlux, heatFluxIndex))
    return TRUE;

  return FALSE;
}
#endif /* !RP_NODE */


/* When this udf library is first loaded we need to initialise EDEM */
void InitialiseEdem()
{
#if !RP_NODE
    cxboolean success;

    Message("Initialising EDEM-CFD Coupling Module for FLUENT. Please wait...\n");

    /* Start EDEM and check we have a valid license */

   /* ADAPTOR_initialiseEDEMCoupling(&success); */
	
	ADAPTOR_init_connectEDEMCoupling(&success);
   
		if(success)
    {
        Message("EDEM initialised - coupled solution available.\n");
        g_DEMCoupled = TRUE;
    }
    else
    {
        Message("EDEM License Error: Cannot connect EDEM.\n");
        Message("Coupled solution unavailable\n\n");
        g_DEMCoupled = FALSE;
    }
#endif /* !RP_NODE */
    
	host_to_node_boolean_1(g_DEMCoupled);
	
	/* Ensure we perform any necessary checks on the first iteration */
    g_FCMInitialised = FALSE;
}


/* Clear particle data deletes held data and ensures the the correct
 * custom properties are registered */

void clearParticleData()
{
#if !RP_NODE

  ADAPTOR_clearParticleData();
    
  /* If using heat transfer, register new properties */

  /* 
   adam.anderson@ansys.com : Why does it need to register on clearing particles?
   TEST by assuming heat properties already registered via EDEM
  if(g_convectiveHeatOption || g_radiativeHeatOption)
    {
      if(!registerHeatProperties(&g_temperatureIndex, &g_heatFluxIndex))
        {
          Message("\n\nWARNING: Cannot register heat properties in clearParticleData .\n\n");
        }
    }
	*/  

#endif /* !RP_NODE */

  g_heatRegistered = FALSE;
  g_numParticles = 0;
}


/* The solution controls cover the optional relaxation factors and
 * drag model options on the panel */
DEFINE_ON_DEMAND(update_solution_controls)
{
	if(!g_DEMCoupled)
    {
        Message0("\n\nWARNING: EDEM hasn't been initialised and coupled solution is unavailable.\n");
		return;
    }

#if !RP_NODE

    /* update the particle sample points */
	g_NumParticleSamplePoints = RP_Get_Integer("edem/sample-points");

	if(g_NumParticleSamplePoints <= 0) /* need minimum of 1 sample */
    {
		g_NumParticleSamplePoints = 1;
    }

	/* update the momentum, volume and heat transfer under relaxation factors */
	g_MomentumURF = RP_Get_Float("edem/mtm-urf");
	g_VolumeURF = RP_Get_Float("edem/volume-urf");
	g_heatURF = RP_Get_Float("edem/heat-urf");

	/* Get the selected drag model
	   Freestream = 0
	   Ergun + Wen Yu = 1
	   Di Felice = 2*/
	g_dragModel = RP_Get_Integer("edem/drag-model");

	/* Get the Saffman lift model */
	g_saffLift = RP_Get_Boolean("edem/saffman-lift");

	/* Get the Magnus lift model */
	g_magLift = RP_Get_Boolean("edem/magnus-lift");

	/* Include fluid-induced torque? */
	g_torque = RP_Get_Boolean("edem/torque");

	/* Use convective heat transfer ? */
	g_convectiveHeatOption = RP_Get_Boolean("edem/heat-convective");

	/* Get the selected convective heat transfer model
	   Ranz & Marshall = 0
	   Gunn = 1
	   Li & Mason = 2*/
	g_convectiveHeatModel = RP_Get_Integer("edem/convectiveheat-model");

	/* Exponential constant for Li & Mason */
	g_heatLiExp = RP_Get_Float("edem/heatlimason-exp");

	/* Use radiative heat transfer ? */
	g_radiativeHeatOption = RP_Get_Boolean("edem/heat-radiative");

	/* User input for particle surface emissivity */
	g_emissivity = RP_Get_Float("edem/heat-emissivity");

#endif /* !RP_NODE */
	
#if PARALLEL
	/* Send all model parameters from host to the nodes */

	host_to_node_int_3(g_NumParticleSamplePoints, g_dragModel, g_convectiveHeatModel);
	/* Booleans sent as integers */
	host_to_node_int_5(g_saffLift, g_magLift, g_torque, g_convectiveHeatOption, g_radiativeHeatOption);
	host_to_node_double_5(g_heatLiExp, g_MomentumURF, g_VolumeURF, g_heatURF, g_emissivity);

#endif /* PARALLEL */
}

/* This is the main execute at end routine that runs everything */
DEFINE_EXECUTE_AT_END(EDEM)
{
	cxboolean bSuccess = TRUE;
	cxboolean bLaunch = TRUE;

#if !RP_HOST
	cell_t c;
	Thread *ct, *fct, *dct;
	Domain *d;
#endif

	int FLUID_INDEX;
	int DEM_INDEX = 0;
    int i = 0;
	double nTime;

	double flowTime;

	/* Heat transfer declaration */
	double heatSource;


	/* the license check failed so return here */
	if(!g_DEMCoupled)
    {
        return;
    }

	/* check whether we are doing coupled simulations! */
	if(g_linkType == NO_COUPLING)
    {
        return;
    }


    /* Quick check that the journal files have been set up correctly */
   if(!g_FCMInitialised)
   {
	   	cxboolean bad_setup;

		bad_setup = FALSE;

#if !RP_NODE
		/* FCM only works in unsteady Fluent sims */
		if(!rp_unsteady)
        {
            Message("\nDEM WARNING: Only valid for unsteady calculations.");
            bad_setup = TRUE;
        }

		/* Check the user defined memory was allocated */
        if(N_UDM < DEM_N_UDM)
        {
            Message("\nDEM WARNING: Need least %d UDMs.", DEM_N_UDM);
            bad_setup = TRUE;
        }

		/* Must be a multiphase simulation for the Eulerian coupling */
        if(g_linkType == EULERIAN && (!sg_mphase || !mp_mfluid))
        {
            Message("\nDEM WARNING: Only valid for Mixture Multiphase calculations.");
            bad_setup = TRUE;
        }


        /* If using heat transfer, register new properties */

        if(!g_heatRegistered && (g_convectiveHeatOption || g_radiativeHeatOption))
        {
          g_heatRegistered = registerHeatProperties(&g_temperatureIndex, &g_heatFluxIndex);

          if(!g_heatRegistered)
            {
                Message("Cannot register heat properties ...\n");
				bad_setup = TRUE;
			}
		  else
		     Message("\n Heat Properties Registered. (temperature index %d heat flux index %d)\n", g_temperatureIndex, g_heatFluxIndex);
        }

#endif /* !RP_NODE */

        host_to_node_boolean_1(g_heatRegistered);
		host_to_node_boolean_1(bad_setup);
		
		/* Abort if the sim is badly setup */
        if(bad_setup)
        {
#if !RP_NODE
            Message("\nAborting DEM Setup\n\n");
#endif /* !RP_NODE */
            return;
        }
	}

    g_FCMInitialised = TRUE;

	/* Here we need to get the current flow time up to which EDEM must simulate. */
#if !RP_NODE
	flowTime = CURRENT_TIME;
#endif /* !RP_NODE */

	host_to_node_double_1(flowTime);

#if !RP_HOST
	d = Get_Domain(ROOT_DOMAIN_ID);

    if(g_linkType == EULERIAN)
    {
      FLUID_INDEX = PHASE_DOMAIN_INDEX(Get_Domain(FLUID_ID));
      DEM_INDEX   = PHASE_DOMAIN_INDEX(Get_Domain(DEM_ID));
    }

    /* Initialise all cell DE values */
    thread_loop_c(ct,d)
	{
	    begin_c_loop(c,ct)
	    {
		  C_DEM_HEAT(c,ct) = 0.0; /* Heat transfer */
		  C_DEM_HEAT_SRC(c,ct) = 0.0;
		  C_DEM_HEAT_COUNT(c,ct) = 0.0;
	      C_DEM_X_FORCE(c,ct) = 0.0; /* drag force */
	      C_DEM_Y_FORCE(c,ct) = 0.0;
	      C_DEM_Z_FORCE(c,ct) = 0.0;
	    }
	    end_c_loop(c,ct)
    }
#endif /* !RP_HOST */


	/* Launch the simulator window if its not already open */
#if !RP_NODE
	Message("Showing simulator...\n");

    ADAPTOR_showSimulator(&bSuccess);

    /* If, for any reason the number of particles differs, get
     * the new particle data */
/*    if(g_numParticles != ADAPTOR_getTotalNumParticles())
    {  ADAM TEST  Force particle data update */

	g_numParticles = ADAPTOR_getTotalNumParticles();
    if(!ADAPTOR_getParticleData())
      {
         Message("\n\nWARNING: Particle updating failed.\n\n");
         bSuccess = FALSE;
      }
 /*   }  ADAM TEST */
#endif /* !RP_NODE */

	host_to_node_int_1(g_numParticles);
	host_to_node_boolean_1(bSuccess);

	if(!bSuccess) return;

    /* The cell occupancy has already been updated after the previous DEM run.
	 * So we don't need to update the cell occupancy on the particles.
     * So just do drag and heat transfer calculations */

	Message("\nSource term calculations... ");

    sourceTermsCalculation();

	PRF_GSYNC_WITH_HOST();

    Message("Done.\n");

	Message0("Entering EDEM simulator processing... ");

#if !RP_NODE
    ADAPTOR_performAnalysisToTime(flowTime, &bSuccess);
#endif /* !RP_NODE */

	host_to_node_boolean_1(bSuccess);

    if(!bSuccess)
    {
        Message0("FAILED.\n");
        return;
    }

    Message0("Done.\n");


    Message0("Retrieving particle data... ");

#if !RP_NODE    
    /* Update the particle numbers for each type */
    g_numParticles = ADAPTOR_getTotalNumParticles();
    g_numParticleTypes = ADAPTOR_getNumParticleTypes();
    
    /* Retrive the particle data from the simulation time-step with which to
     * calculate the fluid source terms */
	bSuccess = ADAPTOR_getParticleData();

#endif /* !RP_NODE */

	host_to_node_boolean_1(bSuccess);
	host_to_node_int_2(g_numParticles,g_numParticleTypes);

	if(!bSuccess)
    {
        Message0("FAILED.\n");
        return;
    }

    Message0("Done.\n");


    /* VOF & Velocities are only the values at the end of the DEM runs. So
	 * we now update the cell values */
	Message0("Calculating volume fraction... ");

    getFluidCellDetails();

	Message0("Done.\n");

    /* Main looping through all the fluid threads and cells for calculation on
     * momentum source terms */

#if !RP_HOST
	Message0("Set the source terms in the fluid cells...\n");

    thread_loop_c(ct,d)
	{
	    double norm_fac;
		double nXForce;
		double nYForce;
		double nZForce;

	    begin_c_loop(c,ct)
	    {
			/* VOF is total volume of particles / Cell Volume */
			norm_fac = C_VOLUME(c,ct);

			/* Momentum source is volumetric */
			C_DEM_X_FORCE(c,ct) /= norm_fac; /* drag force becomes */
			C_DEM_Y_FORCE(c,ct) /= norm_fac; /* momentum source */
			C_DEM_Z_FORCE(c,ct) /= norm_fac;

			nXForce = C_DEM_X_FORCE(c,ct);
			nYForce = C_DEM_Y_FORCE(c,ct);
			nZForce = C_DEM_Z_FORCE(c,ct);

			/* Account for any under relaxation factor in momentum */
			C_DEM_X_FORCE(c,ct) = nXForce * g_MomentumURF + (1-g_MomentumURF)*C_DEM_X_FORCE_OLD(c,ct);
			C_DEM_Y_FORCE(c,ct) = nYForce * g_MomentumURF + (1-g_MomentumURF)*C_DEM_Y_FORCE_OLD(c,ct);
			C_DEM_Z_FORCE(c,ct) = nZForce * g_MomentumURF + (1-g_MomentumURF)*C_DEM_Z_FORCE_OLD(c,ct);

			C_DEM_X_FORCE_OLD(c,ct) = nXForce;
			C_DEM_Y_FORCE_OLD(c,ct) = nYForce;
			C_DEM_Z_FORCE_OLD(c,ct) = nZForce;

            /* Update heat source as well */
            if(g_convectiveHeatOption || g_radiativeHeatOption)
            {
                heatSource = C_DEM_HEAT_SRC(c,ct);

				/* Account for any under relaxation factor in heat */
				C_DEM_HEAT_SRC(c,ct) = heatSource * g_heatURF + (1 - g_heatURF)*C_DEM_HEAT_OLD_SRC(c,ct);

				C_DEM_HEAT_OLD_SRC(c,ct) = heatSource;
            }

             /*  Patch the volume fraction into FLUENT */
            if(g_linkType == EULERIAN)
            {
				double underRelaxedVOF;

                fct = THREAD_SUB_THREAD(ct, FLUID_INDEX);
                dct = THREAD_SUB_THREAD(ct, DEM_INDEX);

				/* Account for any under relaxation factor in the volume fraction */
				underRelaxedVOF = C_DEM_VOF(c,ct)*g_VolumeURF + (1-g_VolumeURF)*C_VOF(c,dct);

				C_VOF(c,dct)= underRelaxedVOF; /* dem-phase */
				C_VOF(c,fct)= 1.0 - underRelaxedVOF; /* fluid-phase */
            }
	    }
	    end_c_loop(c,ct)
    }

    Message0("Done.\n");
#endif /* !RP_HOST */

#if !RP_NODE
	/* Update the time stored in the case file */
	ADAPTOR_getEDEMTime(&nTime, &bSuccess);

	if(bSuccess)
    {
		RP_Set_Real("edem/ntime",nTime);
    }

    Message("Leaving EDEM\n");
#endif /* !RP_NODE */
}

DEFINE_INIT(time_init, domain)
{
	int particleDataSuccess;

#if !RP_NODE
    double nTime;
    cxboolean bSuccess;
#endif /* !RP_NODE */

    if(!g_DEMCoupled) return;

#if !RP_NODE

    /* Sync the EDEM and Fluent times to 0.0 */
	nTime = 0.0;
    RP_Set_Real("edem/ntime", nTime);
    ADAPTOR_setEDEMTime(nTime, &bSuccess);
    g_numParticleTypes = ADAPTOR_getNumParticleTypes();
    
    /* Reset the particle data map if the number of particle types is zero */
    if(g_numParticleTypes > 0)
    {
        /* Update the particle numbers for each type */
        g_numParticles = ADAPTOR_getTotalNumParticles();
		particleDataSuccess = ADAPTOR_getParticleData();
			
		if(!particleDataSuccess)
           Message("\n\nWARNING: Particle updating failed.\n\n");
    }
	else
	{
		g_numParticles = 0;
		particleDataSuccess = 0;
		Message("\n\nNo Particles Found.\n\n");
	}


#endif /* !RP_NODE */

	host_to_node_int_3(particleDataSuccess, g_numParticleTypes, g_numParticles);

	if(!particleDataSuccess)
	{
			clearParticleData();
			return;
	}

	/*  Particle data is now updated on host but will be accessed 
        by other ADAPTOR_ functions like ADAPTOR_getParticle.     */

}

/* The DEFINE_SOURCE methods are getters used for automating the
 * zone settings - listed under boundary conditions. These are called
 * by the panel once the 'ok' button is clicked */

DEFINE_SOURCE(EDEM_fluid_mass_source, c, ct, ds, eq)
{
    return 0.0;
}

DEFINE_SOURCE(EDEM_solid_mass_source, c, ct, ds, eq)
{
    return 0.0;
}

DEFINE_SOURCE(EDEM_x_mom_src, c, ct, ds, eq)
{
    ds[eq]=0.0;
    return C_DEM_X_FORCE(c,ct);
}

DEFINE_SOURCE(EDEM_y_mom_src, c, ct, ds, eq)
{
    ds[eq]=0.0;
    return C_DEM_Y_FORCE(c,ct);
}

DEFINE_SOURCE(EDEM_z_mom_src, c, ct, ds, eq)
{
    ds[eq]=0.0;
    return C_DEM_Z_FORCE(c,ct);
}

DEFINE_SOURCE(EDEM_heat_src, c, ct, ds, eq)
{
    ds[eq]=0.0;
    return C_DEM_HEAT_SRC(c,ct);
}

