// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "udf.h"
#include "cxndsearch.h"
#include "edemUdf.h"

/** Fluent has problems when the occpancy of its cells is above 95% */
#ifndef MAX_OCCUPANCY
# define MAX_OCCUPANCY 0.95
#endif


/** The main purpose of this function is to update the volume fraction of particles in the fluent cells.
  * It will be called in main function of DEFINE_EXECUTE_AT_END only */
void getFluidCellDetails()
{
    double particlePos[ND_ND];
	double particleVolume;
    double particleTemp;

    int i, s;

#if !RP_NODE	
    tDimensionValue** sampleTable;
    tDimensionValue* samples;
	DiscreteElement particle;
	int type;
#endif /* !RP_NODE */
			
#if !RP_HOST
    static ND_Search *search_table = NULL; /* search_table takes time to build so keep it from call to call */

    cell_t c;
	Thread *ct;
	Domain *domain;
	
	cell_t nContainingCell;
	int nContainingThreadID;
    Thread *pContainingThread;

    CX_Cell_Id *ccp_id;
    cell_t ccp_cell;
    Thread *ccp_thread;
	
    double volume;
    double occupancy;
#endif /* !RP_HOST */


	if(g_numParticleTypes == 0)
      {
        Message0("\n\nWARNING: No particles types in %s (%s).\n\n",__FUNCTION__,__FILE__);
        return;
      }

#if !RP_NODE

    /* Allocate the memory for sample points */
    sampleTable = (tDimensionValue**)calloc(g_numParticleTypes, sizeof(double));
        
    for( type = 0; type < g_numParticleTypes; ++type)
      {
        sampleTable[type] = (tDimensionValue *)calloc((g_NumParticleSamplePoints), sizeof(tDimensionValue));
      }


    for(type = 0; type < g_numParticleTypes; ++type)
      {
        if(!ADAPTOR_getParticleTypeSamplePoints(sampleTable[type], g_NumParticleSamplePoints, type))
          {
            Message("\n\nWARNING: Unable to retrieve particle sample points\n\n");
          }
      }


    /* if the radiative heat option is set, get particle temperature data */
    if(g_radiativeHeatOption)
    {
        if(!ADAPTOR_updateValuesForProperty(g_numParticles, g_temperatureIndex))
        {
            Message("\n\nWARNING: Unable to retrieve particle temperature\n\n");
        }
    }
#endif /* !RP_NODE */


#if !RP_HOST

/* Initialise C_DEM_VOF */

    domain = Get_Domain(DEM_FLUID_DOMAIN_ID);

	thread_loop_c(ct, domain)
      {
	    begin_c_loop(c, ct)
          {
            C_DEM_VOF(c, ct) = 0.0;
          }
	    end_c_loop(c, ct)
      }

/* Initialise search tree for whole domain */

    /* if the mesh has changed or deformed since the last time search_table was made, then do this first:
    search_table = CX_End_ND_Point_Search(search_table);
    */

    if(NULLP(search_table))
      search_table = CX_Start_ND_Point_Search(search_table, TRUE, -1);  

#endif /* !RP_HOST */


    /* Go through each particle and update the value of volume fraction */ 
    for(i = 0; i < g_numParticles; ++i)
    {
#if !RP_NODE
        ADAPTOR_getParticle(i, &particle);
		NV_V(particlePos,=,particle.vPos);
		particleVolume = particle.nVolume;
		
		if(g_radiativeHeatOption)
        {
          /* Sum up the temperature of the particles residing at the same fluid cell for the radiation model */
            particleTemp = ADAPTOR_getScalarProperty(g_temperatureIndex, i);
		}
#endif /* !RP_NODE */

        host_to_node_double(particlePos,ND_ND);
		host_to_node_double_1(particleVolume);
		
		if(g_radiativeHeatOption)
			host_to_node_double_1(particleTemp);


#if !RP_HOST

		if(g_radiativeHeatOption)
		{
			ccp_id = CX_Find_Cell_With_Point(search_table, particlePos, 0.0); /* Fluent 14 version has a time parameter */

			if(NNULLP(ccp_id))
			{
				/* Particle has been found in the Fluent mesh and will be accounted for */
				ccp_cell = RP_CELL(ccp_id);
				ccp_thread = RP_THREAD(ccp_id);
				
				nContainingCell = ccp_cell; /* Definitive centre of particle in this cell */
				nContainingThreadID = THREAD_ID(ccp_thread);
				pContainingThread = (void*)Lookup_Thread(domain,nContainingThreadID); /* Store Fluid thread if eulerian */

				/* Sum up the temperature of the particles residing at the same fluid cell for the radiation model */

				C_DEM_HEAT(ccp_cell, ccp_thread) += particleTemp;
				C_DEM_HEAT_COUNT(ccp_cell, ccp_thread) += 1.0;
			}
		}
#endif /* !RP_HOST */

        /* Find all cells that contain sample points */

#if !RP_NODE
        samples = sampleTable[particle.typeIndex];
#endif /* !RP_NODE */

        for(s = 0; s < g_NumParticleSamplePoints; ++s)
        {
            tDimensionValue sample;

#if !RP_NODE
            /* Calculate the sample point from offset vector */              

            NV_VS(sample,=,samples[s],*,particle.nScale);

            /* Rotate to the particles current orientation */
            ADAPTOR_rotateVector(sample, particle.vOrientation);

            NV_V(sample,+=,particle.vPos);
			
#endif /* !RP_NODE */

            host_to_node_double(sample,ND_ND);

#if !RP_HOST
            ccp_id = CX_Find_Cell_With_Point(search_table, sample, 0.0); /* Fluent 14 version has a time parameter */

            if(NNULLP(ccp_id))
            {
				/* particle has been found in the Fluent mesh and will be accounted for */
				ccp_cell = RP_CELL(ccp_id);
				ccp_thread = RP_THREAD(ccp_id);

				occupancy = C_DEM_VOF(ccp_cell, ccp_thread);
				volume = C_VOLUME(ccp_cell, ccp_thread);

				/* Increment its occupancy */ 
				occupancy += particleVolume / (g_NumParticleSamplePoints * volume);

				occupancy = MIN(occupancy,MAX_OCCUPANCY);

				/* Store the new value back in Fluent and the particle data manager */ 
				C_DEM_VOF(ccp_cell, ccp_thread) = occupancy;
			}
#endif /* !RP_HOST */

#if !RP_NODE
/* This function updates the EDEM particle map which might not be necessary if we do all cell finding on Fluent side 
         ADAPTOR_updateCellAndThread(i, nContainingThreadID, pContainingThread);  NOTE: Thread pointer will be different on nodes and host so use ID instead */
#endif /* !RP_NODE */
        }
    }
	

#if !RP_NODE
    for( type = 0; type < g_numParticleTypes; type++)
      {
        free(sampleTable[type]);
      }
    free(sampleTable);
#endif /* !RP_NODE */
}
