// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#ifndef _DRAG_CALCULATION_H_
#define _DRAG_CALCULATION_H_

#include "udf.h"

/** Drag and lift function declarations */
void sourceTermsCalculation();

void defaultDragModel(cell_t containingCell, Thread *containingThread, double occupancy, 
				         int linkType, double volume, double pos[ND_ND], double velocity[ND_ND], 
				         double torque[ND_ND], double force[ND_ND]);

void userDefinedDragExample(cell_t containingCell, Thread *pContainingThread, double nOccupancy,
					        int nLinkType, double nVolume, double vPosition[ND_ND], double vVelocity[ND_ND],
							double vTorque[ND_ND], double vForce[ND_ND] );

void defaultLiftModel(cell_t containingCell, Thread *containingThread, double volume, tDimensionValue velocity, 
				      tDimensionValue angVelocity, tDimensionValue torque, tDimensionValue force, tDimensionValue vorticity);

void defaultTorqueModel(cell_t containingCell, Thread *containingThread, double volume, tDimensionValue velocity, 
					    tDimensionValue angVelocity, tDimensionValue torque, tDimensionValue vorticity);

void saffmanLiftModel(double radius, double viscosity, double density, tDimensionValue vorticity, tDimensionValue relativeVelocity,
					  double re, double reStrain, double reOmega, double epsilon, tDimensionValue force);

void magnusLiftModel(double radius, tDimensionValue angVelocity, double density, tDimensionValue vorticity, 
					 tDimensionValue relativeVelocity, double re, double reOmega, tDimensionValue force);


#endif /* _DRAG_CALCULATION_H_ */
