// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "edemUdf.h"
#include "cxndsearch.h"
#include "forceCalculations.h"
#include "heatCalculations.h"

/* Two heat Flux Mechanisms, Particle to Particle and CFD to Particle */
/* Fluent only sets the the CFD to particle component */
#define PART2PART_HEAT_FLUX 0
#define CFD2PART_HEAT_FLUX 1
#define N_HEAT_FLUX_ELEMENTS 2

/* 
 * Calculate the fluid drag force exerted on each of the particles and also heat transfer 
 * They are combined together such that we don't have to loop over all the particles again
 */ 

void sourceTermsCalculation()
{
  int iParticle;
  int dataValid;

  double particlePos[ND_ND];
  double particleVelocity[ND_ND];
  double particleAngVelocity[ND_ND];
  double particleVolume;
  double particleTemperature;

  double particleForce[ND_ND];
  double particleTorque[ND_ND];
  double temp_double_vec[ND_ND];

  double particleHeatFlux[N_HEAT_FLUX_ELEMENTS];
  double temp_double_heat[N_HEAT_FLUX_ELEMENTS];


#if !RP_NODE

  DiscreteElement particle;

  double* force;
  double* torque;
  double* heatFlux;
  double* base_vec;

#endif /* !RP_NODE */

#if !RP_HOST

  /* search_table takes time to build so keep it from call to call */
  static ND_Search *search_table = NULL;
  CX_Cell_Id *ccp_id;
  cell_t containingCell;
  Thread *containingThread;

#endif /* !RP_HOST */


  if(g_numParticles < 1)
    return;


#if !RP_NODE

  dataValid = 1;

  if(g_convectiveHeatOption || g_radiativeHeatOption)
    {
      /* Check if heat conduction is being used and allocate memory appropriately
       * If heat transfer is used then ensure the heat flux contributed by the FCM
       * is zero at the begining of each fluent timestep
       */

      /* Retrieve the updated particle temperatures from EDEM */
      dataValid = ADAPTOR_updateValuesForProperty(g_numParticles, g_temperatureIndex);
    
      if(dataValid)
        heatFlux = (double *)calloc(N_HEAT_FLUX_ELEMENTS * g_numParticles, sizeof(double));
      else
        Message("WARNING: Unable to retrieve particle temperature in sourceTermsCalculation");
    }

#endif /* !RP_NODE */

  host_to_node_int_1(dataValid);

  if(!dataValid)
    return;
    

#if !RP_NODE
  force = (double *)calloc(ND_ND * g_numParticles, sizeof(double));
  torque = (double *)calloc(ND_ND * g_numParticles, sizeof(double));
#endif /* !RP_NODE */

#if !RP_HOST	
  if(NULLP(search_table))
    search_table = CX_Start_ND_Point_Search(search_table, TRUE, -1);  
#endif /* !RP_HOST */


  /* Calculate forces on each particle */

  for (iParticle=0;iParticle<g_numParticles;++iParticle)
    {
      /* Get particle data needed by Fluent */

#if !RP_NODE

      ADAPTOR_getParticle(iParticle, &particle);
			
      NV_V(particlePos,=,particle.vPos);
      NV_V(particleVelocity,=,particle.vVelocity);
      NV_V(particleAngVelocity,=,particle.vAngVelocity);
      particleVolume = particle.nVolume;

      if(g_convectiveHeatOption || g_radiativeHeatOption)
        {
          double *temp;

          temp = ADAPTOR_getProperty(g_temperatureIndex, iParticle);

          particleTemperature = *temp;
        }
      else
          particleTemperature = 293.15;


#endif /* !RP_NODE */

      host_to_node_double(particlePos,ND_ND);
      host_to_node_double(particleVelocity,ND_ND);
      host_to_node_double(particleAngVelocity,ND_ND);
      host_to_node_double_2(particleVolume, particleTemperature);

#if !RP_HOST

      ccp_id = CX_Find_Cell_With_Point(search_table, particlePos, 0.0);

      if(NNULLP(ccp_id))
        {
          /* Particle has been found in the Fluent mesh and will be accounted for */
          containingCell = RP_CELL(ccp_id); /* Could still be set NULL_CELL here */
          containingThread = Lookup_Thread(Get_Domain(DEM_FLUID_DOMAIN_ID),THREAD_ID(RP_THREAD(ccp_id))); /* Store Fluid thread if eulerian */
        }
      else
        containingCell = NULL_CELL;

      /* Calculate force and torque on particle */

      /* Initialise them in case they are not set in this partition */
      NV_S(particleForce,=,0.0);
      NV_S(particleTorque,=,0.0);

      /* Initialise heat fluxes */
      particleHeatFlux[PART2PART_HEAT_FLUX] = 0.0;
      particleHeatFlux[CFD2PART_HEAT_FLUX] = 0.0;

      if(containingCell != NULL_CELL) /* Particle is found in this partition */
        {
          double occupancy;

          occupancy = 1.0; /* Different Drag laws may alter this */

          if( g_dragModel == ERGUN || g_dragModel == DIFELICE )
            {
              /* The voidage is from the previous timestep because the current flow field is calculated
               * for with the previously calculated solid fractions
               */
              occupancy = 1.0 - C_VOF(containingCell, containingThread);

              /* At the very 1st time a particle is created, C_VOF or the voidage is initialised at 1.0 */
              if (occupancy <= 0.0)
                occupancy = 0.05; /* So limit occupancy */
            }

          defaultDragModel(containingCell, containingThread, occupancy, g_linkType, 
                           particleVolume, particlePos, particleVelocity, 
                           particleTorque, particleForce);

          if( g_saffLift || g_magLift || g_torque )
            {
              double vorticity[ND_ND];

              vorticity[0] = (double)(C_DWDY(containingCell,containingThread)-C_DVDZ(containingCell,containingThread));
              vorticity[1] = (double)(C_DUDZ(containingCell,containingThread)-C_DWDX(containingCell,containingThread));
              vorticity[2] = (double)(C_DVDX(containingCell,containingThread)-C_DUDY(containingCell,containingThread));				
              if(g_torque)
                {
                  defaultTorqueModel(containingCell, containingThread, particleVolume, particleVelocity, 
                                     particleAngVelocity, particleTorque, vorticity);
                }

              if( g_saffLift || g_magLift )
                {
                  defaultLiftModel(containingCell, containingThread, particleVolume, particleVelocity, 
                                   particleAngVelocity, particleTorque, particleForce, vorticity);
                }                    
            }

          /* -ve reaction force on fluid */
          C_DEM_X_FORCE(containingCell, containingThread) -= particleForce[0];
          C_DEM_Y_FORCE(containingCell, containingThread) -= particleForce[1];
          C_DEM_Z_FORCE(containingCell, containingThread) -= particleForce[2];

          /* Convective heat transfer */
          if(g_convectiveHeatOption)
            {   
              /* The second entry in the heat flux custom property is added to,
                  hence the CFD2PART_HEAT_FLUX offset  */
              convectionModels(containingCell, containingThread,
                               particleVelocity, particleVolume,
                               g_convectiveHeatModel, particleTemperature,
                               particleHeatFlux + CFD2PART_HEAT_FLUX);
            }

              /* Radiative heat transfer */
          if(g_radiativeHeatOption)
            {
              radiationModels(containingCell, containingThread,
                              particleVolume, particleTemperature,
                              particleHeatFlux + CFD2PART_HEAT_FLUX);
            }
        }


# if RP_NODE
      /* Force torque and heatFlux will be 0.0 on partitions where the particle isn't so summing is valid way to find force */
      PRF_GDSUM(particleForce,ND_ND,temp_double_vec);
      PRF_GDSUM(particleTorque,ND_ND,temp_double_vec);
      PRF_GDSUM(particleHeatFlux,N_HEAT_FLUX_ELEMENTS,temp_double_heat);

# endif /* RP_NODE */

#endif /* !RP_HOST */

      node_to_host_double(particleForce, ND_ND);
      node_to_host_double(particleTorque, ND_ND);
      node_to_host_double(particleHeatFlux, N_HEAT_FLUX_ELEMENTS);

#if !RP_NODE	
      /* Copy the particle force and torque to the allocated array ready to update EDEM */

      base_vec = force + (iParticle*ND_ND);
      NV_V(base_vec,=,particleForce);

      base_vec = torque + (iParticle*ND_ND);
      NV_V(base_vec,=,particleTorque);

      if(g_convectiveHeatOption || g_radiativeHeatOption)
        {
          base_vec = heatFlux + (iParticle*N_HEAT_FLUX_ELEMENTS);
          base_vec[PART2PART_HEAT_FLUX] = particleHeatFlux[PART2PART_HEAT_FLUX]; /* This line is unnecessary as values should all be 0.0 */
          base_vec[CFD2PART_HEAT_FLUX]  = particleHeatFlux[CFD2PART_HEAT_FLUX];
        }

#endif /* !RP_NODE */
    }

#if !RP_NODE

  ADAPTOR_setDragForceAndTorque(g_numParticles, force, torque);

  free(force);
  free(torque); 


  if(g_convectiveHeatOption || g_radiativeHeatOption)
    {
      if(!ADAPTOR_setValuesForProperty(g_numParticles, g_heatFluxIndex, heatFlux))
          Message("\nWARNING: Unable to update particle heat fluxes in sourceTermsCalculation.\n");
	  else
		  Message("\nParticle heat fluxes updated (g_heatFluxIndex = %d).\n", g_heatFluxIndex);


      free(heatFlux);
    }
 
#endif /* !RP_NODE */

}
