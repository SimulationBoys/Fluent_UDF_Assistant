// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#include "udf.h"
#include "grid.h"
#include "poly.h"
#include "xfile.h"
#include "sg_s2s.h" /* For Remove_Shell_Threads & Restore_Shell_Threads */
#include "sg_vfr.h" /* Write_Thread_View_Factors, is this actually needed by Edem */
#include "sectio.h"
#include "para.h"

#define NO_OF_SECTIONS  13
#define UNKNOWN_SECTION 14


#define WRITE_SECTION(func) (&func)
#define ERROR_CHECK(thunk) (PRF_ANYONE(((thunk) < 0),TRUE))

/* Extra includes for Label_Nodes and Label_Faces */
#include "reorder.h" /* Reorder_Domain_Threads */
#include "grid_par.h" /* For define Global_Max_Interface_Face_List_Size(d) */
#include "arrays.h" /* For define Global_Max_Interface_Face_List_Size(d) */
#include "hang.h" /* For parent_thread_p */
#include "shell_conduction.h"

extern int label_face_id, label_node_id;                      

#if 0 /* NOTE Was RP_NODE  but only_collect_flag cannot be found in standard Fluent libraries when compiled as UDF ????? */
extern int only_collect_flag;
#endif /* RP_NODE */

/* #defines from id.c */

#if RP_NODE

#define OLD_ID(_v) (NODE_TMP_0(_v).asIndex)
#define V_FLAGS_INT (1u << 14)
#define SET_V_INT(v) SET_V_FLAGS(v,V_FLAGS_INT)
#define CLEAR_V_INT(v) CLEAR_V_FLAGS(v,V_FLAGS_INT)
#define V_IS_INT(v) NODE_FLAG(v,V_FLAGS_INT)

#define V_FLAGS_VST (1u << 17)
#define SET_V_VST(v) SET_V_FLAGS(v,V_FLAGS_VST)
#define CLEAR_V_VST(v) CLEAR_V_FLAGS(v,V_FLAGS_VST)
#define V_IS_VST(v) NODE_FLAG(v,V_FLAGS_VST)

#define V_FLAGS_CNR (1u << 23)
#define SET_V_CNR(v) SET_V_FLAGS(v,V_FLAGS_CNR)
#define CLEAR_V_CNR(v) CLEAR_V_FLAGS(v,V_FLAGS_CNR)
#define V_IS_CNR(v) NODE_FLAG(v,V_FLAGS_CNR)

static int
compare_node_old_id (void *p0, void *p1)
{
  cxindex id =  (OLD_ID((Node *) *((Node **)p0)) -
                 OLD_ID((Node *) *((Node **)p1)));
  return INDEX_CAST(id);
}
#endif /* RP_NODE */


#if USE_INT64  
static void
get_id_offset(cxindex *c, cxindex *f, cxindex *n, int set)
{
  static cxindex cell = 0;
  static cxindex face = 0;
  static cxindex node = 0;
  if(set)
    {
      if(c)cell = *c;
      if(f)face = *f;
      if(n)node = *n;
    }
  else
    {
      if(c)*c = cell;
      if(f)*f = face;
      if(n)*n = node;
    }
}
#endif


void WriteMeshOut(char *sFilename, cxboolean *bSuccess)
{
  /* This function is derived from Write_Grid_Sections() in case.c */
  /* It writes out the grid without cells, so the removed "all" parameter is replaced by FALSE */
  /* The "binary" parameter is also hardwired as FALSE */

  int do_parallel_case_write;

  FILE *fd;
  int nvert, nface;
  Domain *domain;

  cxboolean failed = FALSE;
  cxboolean binary = FALSE;

#if PARALLEL
  cxboolean allow_parallel_case_write = RP_Get_Boolean("parallel/allow-parallel-case-write?");
#endif

#if RP_HOST
  int io_buf_size;
#endif


  if (!Grid_Valid_P())
    {
      *bSuccess = 0;
      return;
    }

  if ((fd=fopen(sFilename,"w"))==NULL)
    {
       Message("\nWARNING: Unable to open file %s (%s:%s:%d)",sFilename,__FILE__,__FUNCTION__,__LINE__);
       *bSuccess = 0;
       return;
    }
 
#if 0 /* NOTE Was PARALLEL  but buffered_case_write_settings cannot be found in standard Fluent libraries when compiled as UDF ????? */
  if (buffered_case_write_settings.io_buf_size==0)
    set_default_buffered_case_write_settings(); 
#endif

  do_parallel_case_write = 0;
  

#if 0   /* NOTE Was RP_HOST  but buffered_case_write_settings cannot be found in standard Fluent libraries when compiled as UDF ????? */
  io_buf_size = buffered_case_write_settings.io_buf_size;
#endif


  /*  Someone is stomping on TMP space without updating the marker
   *  when a case is written...
   */

  domain = Get_Domain(ROOT_DOMAIN_ID);

  Mark_Storage(domain, SM_TMP, "unknown");
  Mark_Storage(domain, SM_FTMP, "unknown");
  

#if RP_POLYHEDRA
  Clear_Dual_Threads(domain);
#endif
#if PARALLEL
# if RP_HOST
  Free_Host_Domain(domain);
# endif
  Reorder_Domain_Threads(domain, FALSE);
#endif

#if RP_SHELL && RP_3D
  /* set thread_n_elements of shell threads to
     zero so they are skipped during write */
  Remove_Shell_Threads (domain);
#endif
  

  if (Count_Unequal_Pitch_Interfaces(domain) > 0)
    Thread_Sliding_Boundary_Copies(domain, TRUE, TRUE);

#if !(RP_NODE || RP_HOST || DEBUG)
  Alloc_Thread_Storage_Vars (node_thread, SV_N_TMP_0, SV_NULL);
#endif

#if PARALLEL
  {
    int max_n_type_in_io_buffer = n_type_in_io_buffer;

    /* Synchronize the io buffer sizes. Some functions, e.g, Label_Node
       might have changed buffer size only on compute nodes.
       Data write functions assumes that n_type_in_io_buffer is same on
       all compute nodes and host CR 39857 */
#if RP_NODE
    max_n_type_in_io_buffer = PRF_GIHIGH1(n_type_in_io_buffer);
#endif
    node_to_host_int_1(max_n_type_in_io_buffer);
    max_n_type_in_io_buffer=MAX(n_type_in_io_buffer,max_n_type_in_io_buffer);
    host_to_node_int_1(max_n_type_in_io_buffer);
    Alloc_Parallel_IO_Buffers(max_n_type_in_io_buffer,FALSE,
                              __FILE__,__LINE__);

    nvert = global_count_v(domain,TRUE);
    nface = global_count_f_once(domain,TRUE) +
      global_count_nosolve_f_once(domain,TRUE);

  }
#else

  Alloc_Thread_Storage_Vars (node_thread, SV_ID, SV_NULL);
  Alloc_Storage_Vars (domain, SV_ID, SV_NULL);

  nvert = Label_Nodes(domain,FALSE);
  nface = Label_Faces(domain,TRUE);

#endif

#if !RP_NODE

  fprintf(fd, "(%d (%x %x %lx %x))\n", XF_FACE, 0, 1, (long)nface, 0);
  fprintf(fd, "(%d (%x %x %lx %x %x))\n", XF_NODE, 0, 1, (long)nvert, 0, ND_ND);

#endif /* !RP_NODE */

#if PARALLEL

  do_parallel_case_write = get_parallel_case_write_flag();

  do_parallel_case_write = allow_parallel_case_write?do_parallel_case_write:0;
#endif


#if 0  /* NOTE Was RP_NODE  but only_collect_flag cannot be found in standard Fluent libraries when compiled as UDF ????? */
  only_collect_flag = get_collect_flag();
#endif


  /* NODE_MARK */
  Alloc_Thread_Storage_Vars (node_thread, SV_N_TMP_1, SV_NULL);

    
  if (ERROR_CHECK(WRITE_SECTION(Write_Face_Section)(domain,fd,binary,FALSE)))
    {
      Message0("Failed while writing face section.\n");
      goto write_error;
    }

#if RP_HANG
  if (ERROR_CHECK(WRITE_SECTION(Write_Face_Tree_Section)(domain,fd,binary)))
    {
      Message0("Failed while writing face tree section.\n");
      goto write_error;
    }
#endif

  if (ERROR_CHECK(WRITE_SECTION(Write_Face_Parent_Section)(domain,fd,binary)))
    {
      Message0("Failed while writing face parent section.\n");
      goto write_error;
    }

  /* Not needed by Edem 
  if (ERROR_CHECK(WRITE_SECTION(Write_Ghost_Cell_Link_Section)(domain,fd,binary)))
    {
      Message0("Failed while writing ghost cell link section.\n");
      goto write_error;
    }
  */

  if (ERROR_CHECK(WRITE_SECTION(Write_NC_Metric_Section)(domain,fd,binary)))
    {
      Message0("Failed while writing non-conformal metric section. \n");
      goto write_error;
    }

  if (ERROR_CHECK(WRITE_SECTION(Write_Periodic_Face_Section)(domain,fd,binary)))
    {
      Message0("Failed while writing periodic/shadow face section.\n");
      goto write_error;
    }

  if (ERROR_CHECK(WRITE_SECTION(Write_Node_Section)(domain,fd,binary,FALSE,nvert)))
    {
      Message0("Failed while writing node section.\n");
      goto write_error;
    }
    

  if (PRF_ANYONE((0!= Write_Thread_View_Factors(domain, fd, binary)),TRUE))
    {
      Message0("Failed while writing view factor section.\n");
      goto write_error;
    }

#if RP_NETWORK
  if (PRF_ANYONE((0!= Write_Network_Section(domain, fd, binary)),TRUE))
    {
      Message0("Failed while writing network section.\n");
      goto write_error;
    }

  if (PRF_ANYONE((0!= Write_Network_Vars(domain, fd)),TRUE))
    {
      Message0("Failed while writing network variables section.\n");
      goto write_error;
    }
#endif  /* RP_NETWORK */

#if !RP_NODE
  if (fprintf(fd, "\n") < 0)
    failed = TRUE;
#endif

  if (PRF_ANYONE(failed,TRUE))
    goto write_error;

  Save_Grid_Id();

  /* deactivate cell threads that are activated for output */
  CX_Flush();

  if (Count_Unequal_Pitch_Interfaces(domain) > 0)
    Thread_Sliding_Boundary_Copies(domain, FALSE, TRUE);

#if RP_SHELL && RP_3D
  /* restore shell threads attributes
     thread_n_elements */
  Restore_Shell_Threads (domain);
#endif

#if !(PARALLEL || DEBUG)
  Free_Thread_Storage_Vars (node_thread, SV_N_TMP_0, SV_ID ,SV_NULL);
  Free_Storage_Vars (domain, SV_ID ,SV_NULL);
#endif

  /* NODE_MARK */
  Free_Thread_Storage_Vars (node_thread, SV_N_TMP_1, SV_NULL);

  *bSuccess = 1;
  return;


 write_error:

#if !(PARALLEL || DEBUG)
  Free_Thread_Storage_Vars (node_thread, SV_N_TMP_0, SV_ID ,SV_NULL);
  Free_Storage_Vars (domain, SV_ID ,SV_NULL);
#endif

  /* NODE_MARK */
  Free_Thread_Storage_Vars (node_thread, SV_N_TMP_1, SV_NULL);

#if RP_SHELL && RP_3D
  /* restore shell threads attributes
     thread_n_elements */
  Restore_Shell_Threads (domain);
#endif

  Primitive_Error("Write_Grid_Sections: Error encountered while writing to file.\n There may not be enough space for the case file on this disk.");

  *bSuccess = 0;
  return;
}
