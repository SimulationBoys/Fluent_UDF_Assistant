/* This file generated automatically. */ 
/* Do not modify. */ 
#include "udf.h" 
#include "prop.h" 
#include "dpm.h" 
extern DEFINE_ON_DEMAND(update_solution_controls);
extern DEFINE_ADJUST(EDEM,d_notuse);
extern DEFINE_INIT(time_init, domain);
extern DEFINE_SOURCE(EDEM_x_mom_src, c, ct, ds, eq);
extern DEFINE_SOURCE(EDEM_y_mom_src, c, ct, ds, eq);
extern DEFINE_SOURCE(EDEM_z_mom_src, c, ct, ds, eq);
extern DEFINE_PROFILE(MP_EDEM_POROSITY, ct, i);
extern DEFINE_ON_DEMAND(select_edem_deck);
extern DEFINE_ON_DEMAND(couple_to_edem);
extern DEFINE_ON_DEMAND(test_on_demand);
extern DEFINE_RW_FILE(read_case,fp);
extern DEFINE_ON_DEMAND(set_lagrangian);
extern DEFINE_ON_DEMAND(set_eulerian);
extern DEFINE_ON_DEMAND(set_uncoupled);
extern DEFINE_ON_DEMAND(Creat_nearCellTable);
__declspec(dllexport) UDF_Data udf_data[] = { 
{"update_solution_controls", (void (*)())update_solution_controls, UDF_TYPE_ON_DEMAND},
{"EDEM", (void (*)())EDEM, UDF_TYPE_ADJUST},
{"time_init", (void (*)())time_init, UDF_TYPE_INIT},
{"EDEM_x_mom_src", (void (*)())EDEM_x_mom_src, UDF_TYPE_SOURCE},
{"EDEM_y_mom_src", (void (*)())EDEM_y_mom_src, UDF_TYPE_SOURCE},
{"EDEM_z_mom_src", (void (*)())EDEM_z_mom_src, UDF_TYPE_SOURCE},
{"MP_EDEM_POROSITY", (void (*)())MP_EDEM_POROSITY, UDF_TYPE_PROFILE},
{"select_edem_deck", (void (*)())select_edem_deck, UDF_TYPE_ON_DEMAND},
{"couple_to_edem", (void (*)())couple_to_edem, UDF_TYPE_ON_DEMAND},
{"test_on_demand", (void (*)())test_on_demand, UDF_TYPE_ON_DEMAND},
{"read_case", (void (*)())read_case, UDF_TYPE_RW_FILE},
{"set_lagrangian", (void (*)())set_lagrangian, UDF_TYPE_ON_DEMAND},
{"set_eulerian", (void (*)())set_eulerian, UDF_TYPE_ON_DEMAND},
{"set_uncoupled", (void (*)())set_uncoupled, UDF_TYPE_ON_DEMAND},
{"Creat_nearCellTable", (void (*)())Creat_nearCellTable, UDF_TYPE_ON_DEMAND},
}; 
__declspec(dllexport) int n_udf_data = sizeof(udf_data)/sizeof(UDF_Data); 
#include "version.h" 
__declspec(dllexport) void UDF_Inquire_Release(int *major, int *minor, int *revision) 
{ 
*major = RampantReleaseMajor; 
*minor = RampantReleaseMinor; 
*revision = RampantReleaseRevision; 
} 
