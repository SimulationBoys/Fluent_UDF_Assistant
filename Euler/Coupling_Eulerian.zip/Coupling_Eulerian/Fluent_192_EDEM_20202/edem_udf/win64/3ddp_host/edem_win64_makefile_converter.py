#!/usr/bin/env python

from __future__ import print_function

import os, sys


try:
    edem_version = sys.argv[-1][-3:]
except:
    edem_version = "2.6"

edem_library_name = "EDEMCouplingClient4.lib"

if edem_version == "2.7":
    edem_library_name = "EDEMCouplingClient4.lib"


try:
    edem_library_path = os.environ["EDEM_LIBRARY_PATH"]
except KeyError as e:
    print("\nMust set environment variable EDEM_LIBRARY_PATH to location of EDEM Lib file {0}.\n".format(edem_library_name))
    raise e


try:
    edem_adaptor_object_dir = os.environ["EDEM_ADAPTOR_OBJECT_DIR"]
except KeyError as e:
    print("\nMust set environment variable EDEM_ADAPTOR_OBJECT_DIR to location of EDEM Object files.\n")
    raise e


makefile = open("makefile","r")
edem_makefile = open("makefile_edem","w")

edem_objects = os.listdir(edem_adaptor_object_dir)

edem_objects = ['"'+edem_adaptor_object_dir+"\\"+obj+'"' for obj in edem_objects if obj.endswith(".obj")]

if not edem_objects:
    print("\nNo EDEM Object files found in {0}\n".format(edem_adaptor_object_dir))
    sys.exit(1)

for line in makefile:

        
    if line.startswith("LIBS = "):
# Add EDEM library 
        line = line.rstrip()+ ' /Libpath:"' + edem_library_path+'" '+edem_library_name+"\n"

        
    if line.startswith("OBJECTS = "):
# Now add EDEM objects 

        edem_line = "EDEM_OBJECTS = " + " ".join(edem_objects) + "\n"
        edem_makefile.write(edem_line)

        line = line.rstrip()+ " $(EDEM_OBJECTS)" + "\n"


    if line.startswith("$(UDFDATA):"):
# Stop udf_names.c being remade because makefile has changed

        mpos = line.find("makefile")
        if mpos > 0:
            line = line[:mpos] + line[mpos+len("makefile"):]


    edem_makefile.write(line)


makefile.close()
edem_makefile.close()

