// Parallel EDEM CFD Coupling for ANSYS FLUENT - Version 1.0
// Copyright 2013 ANSYS, Inc.     
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Portions of this software were developed in a collaboration between 
// Adam Anderson of ANSYS, Inc. and Andrew Hobbs of Astec Inc. A user 
// community forum for sharing experiences and code improvements is 
// maintained at 
//
//	 http://www.dem-solutions.com/forum

#ifndef _EDEM_H_
#define _EDEM_H_

#include "udf.h"
#include "AdaptorInterface.h"

#ifndef SQR
# define SQR(P)((P)*(P))
#endif
#ifndef POW3
# define POW3(P)(SQR(P)*(P))
#endif
#ifndef POW4
# define POW4(P)(POW3(P)*(P))
#endif

/** UDMs used by EDEM for storage on Fluent side */
enum
{
    DEM_VOF,
	DEM_HEAT,
	DEM_HEAT_COUNT,
    DEM_X_FORCE,
    DEM_Y_FORCE,
    DEM_Z_FORCE,
    DEM_X_FORCE_OLD,
    DEM_Y_FORCE_OLD,
    DEM_Z_FORCE_OLD,
	DEM_HEAT_SRC,
    DEM_HEAT_SRC_OLD,
    DEM_N_UDM       /* Number of UDMs needed by DEModel */
};

/** Coupling methods */
enum
{
	NO_COUPLING = 0,
	LAGRANGIAN,
	EULERIAN
};

#define DEM_FLUID_DOMAIN_ID ((g_linkType == EULERIAN)?FLUID_ID:ROOT_DOMAIN_ID)

/** Drag model options
  * Freestream model = 0
  * Ergun + Wen Yu = 1
  * Di Felice = 2*/
enum
{
    FREESTREAM = 0,
    ERGUN,
    DIFELICE
};

/** Convective heat model options
  * Ranz & Marshall = 0
  * Gunn = 1
  * Li & Mason = 2 */
enum
{
    RANZ = 0,
    GUNN,
    LIMASON
};


/** UDM getters
  * It should be noted it is decided to store the old forces and heat from the previous timestep
  * in the UDM instead of using local structure such that it will be stored in the case
  * straightaway without other memory managment from us */
#define C_DEM_VOF(c,ct)				C_UDMI(c,ct,DEM_VOF)
#define	C_DEM_HEAT(c,ct)			C_UDMI(c,ct,DEM_HEAT)
#define	C_DEM_HEAT_COUNT(c,ct)		C_UDMI(c,ct,DEM_HEAT_COUNT)
#define C_DEM_X_FORCE(c,ct)			C_UDMI(c,ct,DEM_X_FORCE)
#define C_DEM_Y_FORCE(c,ct)			C_UDMI(c,ct,DEM_Y_FORCE)
#define C_DEM_Z_FORCE(c,ct)			C_UDMI(c,ct,DEM_Z_FORCE)
#define C_DEM_X_FORCE_OLD(c,ct)		C_UDMI(c,ct,DEM_X_FORCE_OLD)
#define C_DEM_Y_FORCE_OLD(c,ct)		C_UDMI(c,ct,DEM_Y_FORCE_OLD)
#define C_DEM_Z_FORCE_OLD(c,ct)		C_UDMI(c,ct,DEM_Z_FORCE_OLD)
#define C_DEM_HEAT_SRC(c,ct)		C_UDMI(c,ct,DEM_HEAT_SRC)
#define C_DEM_HEAT_OLD_SRC(c,ct)	C_UDMI(c,ct,DEM_HEAT_SRC_OLD)

/** Macros for property data types */
#define CM_PROP_DATA_TYPE_DOUBLE 0

/** macros for property unit types */
#define CM_PROP_UNIT_TYPE_OTHER                0
#define CM_PROP_UNIT_TYPE_NONE                 1
#define CM_PROP_UNIT_TYPE_ACCELERATION         2
#define CM_PROP_UNIT_TYPE_ANGLE                3
#define CM_PROP_UNIT_TYPE_ANGULAR_ACELERATION  4
#define CM_PROP_UNIT_TYPE_ANGULAR_VELOCITY     5
#define CM_PROP_UNIT_TYPE_DENSITY              6
#define CM_PROP_UNIT_TYPE_ENERGY               7
#define CM_PROP_UNIT_TYPE_WORK_FUNCTION        8
#define CM_PROP_UNIT_TYPE_FORCE                9
#define CM_PROP_UNIT_TYPE_CHARGE              10
#define CM_PROP_UNIT_TYPE_LENGTH              11
#define CM_PROP_UNIT_TYPE_MASS                12
#define CM_PROP_UNIT_TYPE_MOI                 13
#define CM_PROP_UNIT_TYPE_SHEAR_MOD           14
#define CM_PROP_UNIT_TYPE_TIME                15
#define CM_PROP_UNIT_TYPE_TORQUE              16
#define CM_PROP_UNIT_TYPE_VELOCITY            17
#define CM_PROP_UNIT_TYPE_VOLUME              18
#define CM_PROP_UNIT_TYPE_FREQUENCY           19
#define CM_PROP_UNIT_TYPE_TEMPERATURE         20
#define CM_PROP_UNIT_TYPE_HEAT_FLUX           21

/** Define string for custom properties registration */
#define TEMPERATURE "Temperature"
#define HEAT_FLUX "Heat Flux"
#define MY_VolumeURF 0.7


/** Define string messages */
#define FILE_OPEN_SUCCESS "File opened successfully.\n"
#define FILE_OPEN_ERROR "Error opening file.\n"
#define EDEM_LIC_ERROR "EDEM License Error: Cannot launch"
#define HEAT_LIC_ERROR "Heat transfer feature license is missing.\n"

/** Function declarations */
void	    InitialiseEdem();
void	    WriteMeshOut(char *sFilename, cxboolean *bSuccess);
cxboolean   registerHeatProperties();
void        clearParticleData();

void	    getFluidCellDetails();

static int FLUID_ID = 2;

/** EDEM external global variables */

/** Particle details */
extern const int            MAX_PARTICLE_TYPES;         /* The maximum number of particle types that can be allocated for */
extern int					g_numParticles;				/* number of particles. */
extern int					g_NumDiscreteElements;
extern int                  g_numParticleTypes;         /* number of particle types */
extern int					g_NumParticleSamplePoints;	/* number of sample vectors */

/** Panel details */
extern int					g_linkType;					/* selected coupling method */
extern int			        g_dragModel;				/* Selected drag model */
extern cxboolean	        g_saffLift;					/* Saffman lift model */
extern cxboolean			g_magLift;					/* Magnus lift model */
extern double				g_VolumeURF;				/* Volume under-relaxation factor */
extern double				g_MomentumURF;				/* Momentum under-relaxation factor */
extern double				g_heatURF;					/* Heat under-relaxation factor */
extern cxboolean			g_torque;					/* Option for fluid-induced torque */
extern cxboolean			g_convectiveHeatOption;		/* Option for convective heat transfer */
extern int					g_convectiveHeatModel;		/* Convective heat transfer model */
extern double				g_heatLiExp;				/* Exponential constant for Li & Mason model that require user's input */
extern cxboolean			g_radiativeHeatOption;		/* Option for radiative heat transfer */
extern double				g_emissivity;				/* User input for the particle surface emissivity */

extern cxboolean	        g_DEMCoupled;				/* check that EDEM is started and we have a valid license */
extern cxboolean			g_FCMInitialised;			/* perform checks on the first iteration */
extern cxboolean            g_heatRegisterd;            /* indicates if heat properties are registered */

extern int					g_FluidCells;               /* the current number of Fluent cells */
extern int					g_Threads;					/* the current number of Fluent threads */

extern int                  g_temperatureIndex;          /* Offset for temperature */
extern int                  g_heatFluxIndex;             /* Offset for heat flux */

#define	UNDERFLOW_LIMIT 1e-8			  /* Very small number to be used as a cutoff value */
#define STEFANBOLTZMANNCONST 5.6704e-8  /* Stefan-Boltzmann constant for the radiation model */



#endif /* _EDEM_H_ */
